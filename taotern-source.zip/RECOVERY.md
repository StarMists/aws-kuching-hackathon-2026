# Taotern Sites recovery and verification

## Authoritative scope and observed checkpoint

Latest owner completion scope is **upload → persistent Project association → selected-source Workspace LLM consultation**. The authoritative product is https://taotern-kuching-2026.liuyz8715.chatgpt.site/ . Sites Worker/Vinext, D1 `DB`, private R2 `BUCKET`, and trusted ChatGPT identity are the runtime. The optional local/Docker handoff was cancelled; this source does not start the original Supabase/Flutter/Python stack. Original source attribution and contract adaptation are documented in `docs/PROVENANCE.md`.

At **2026-10-07 06:42 UTC**, the restored cloud baseline was `9092867e48d23961c83c7a0ae2c4ab6a74985cf4`, environment18; the quote-reference chat repair was captured as `758276db0db66bba74bb934b664b8d2b73d95dd9`. The publisher checked an actual repaired three-document comparison at06:39:47: launch12→19 November2026, planning ceilingRM240,000→RM210,000,3→2counters, neither circular constitutes procurement approval. Two source buttons identify v1page1/v2page1. Clicking that fresh answer's citation was approval-blocked. Separately, the frontend worker verified original PDF page/fit/zoom and an existing saved citation's exact page3 highlight and Back navigation.

A fresh hosted TXT upload was ready with exact roomB-17,21November2026 and lack of procurement approval. Project rename and source dates persisted. Native PDF/TXT storage, source bytes, keyword/project scope, notes/Project CAS, version lineage, supported task stop/restore, cross-owner IDs and actual Worker restart passed earlier local HTTP checks. Current native-only Markdown/partial/unsupported regressions are a separate pending checkpoint. OCR is paused by owner instruction. Later native-only intake retains original photo/scanned bytes, marks unsupported pages explicitly, excludes those pages from evidence and disables futile extraction retries.

This is not an all-feature quality certification. Earlier real timeline/conflict/impact retries saved artifacts; timeline date/coverage/qualifier issues and conflict mismatched-attribute evidence were found. Brief/gap/replay attempts failed. No additional six-workflow batch is required under the owner's latest scope. See `docs/ACCEPTANCE.md` for the full honest inventory.

## Clean source verification commands

Prerequisites: Node>=22.13.0, npm and access to the declared registry/exact seeded dependency cache. The source archive excludes credentials, installed dependencies, build outputs, execution state and user data.

1. Extract into a fresh writable directory. Check `package.json`, `package-lock.json`, `.openai/hosting.json`, `app/`, `lib/`, `db/`, `drizzle/` and license notices.
2. Run `npm run install:ci`. Do not overlap installers.
3. Run `npx tsc --noEmit`.
4. Run `node --loader ./tests/typescript-loader.mjs --test tests/*.test.mjs`. Default API skip and MOCK-labelled provider tests do not establish live model quality.
5. Run `node --import tsx --test lib/ingest/ingestion.test.ts lib/ingest/native-support.test.ts` when the native-support file exists.
6. Run `npm run build`. This builds locally; it does not publish.
7. For an **empty local database only**, apply each migration in order with:

   `node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/<migration>.sql`

   Current cloud history is0000,0001,0002. Never edit or replay applied migrations. Production migrations are a separately authorized Sites operation.
8. Run `node tests/run-worker-integration.mjs`. It owns a loopback-only built Worker on5174, uses clearly synthetic local identities/records, runs HTTP checks, restarts the Worker to prove persistence, and stops it. Stop an existing preview on5174 first. No provider keys are needed; no canned model answer counts as a pass.

For ordinary development use `npm run dev` and the local mock `/signin-with-chatgpt?return_to=/`. Built preview is `npm start -- --port 5174`. Local test identity headers must never impersonate a hosted user.

## Source, configuration and data are separate

- `.openai/hosting.json` pins the existing authorized Site and its D1/R2 bindings. Reuse that Site identity.
- Source restore does not restore Projects, chats, originals or artifacts. Existing D1 and R2 must be preserved together; no full cloud-data disaster restore has been verified.
- Provider credentials stay in approved server-side secret configuration. Never paste them into browser UI, source, commits or reports. `AI_ENABLED` defaults false without approved setup; `/api/config` exposes readiness only.
- Free-provider requests require explicit public/synthetic-data acknowledgement and configured usage limits. Unknown/interrupted attempts remain charged conservatively. Health success does not guarantee capacity or complex output quality.
- Unsupported originals are retained for viewing/download and external conversion. Their missing text cannot establish that a fact did not happen. Supported task retries preserve their original source, IDs and immutable selected evidence; polling/reload must not duplicate outputs.

## Independently verified backups

- Exact9e7e542 base clean restore:701 locked dependencies, TypeScript/build exit0,41 deterministic/mock passes and1 API skip; no ambient checkout symlink/import fallback. Disposable dependency tree was removed afterwards.
- Native GitHub checkpoint02 whole archive matched all408 base file hashes,0 missing/mismatched files, clean ZIP CRC. Root owns final remote readback.
- Cloud909 ZIP:448files,3,489,873bytes,SHA256 `37e1230e1b9a11580d7d73edb91cb145415165f64371c7cb51ccbbb0451c422a`, clean CRC; every file independently matched immutable Git archive. The native delta from base02 has116changed files in90/26-file batches, with no deletions; only `.gitignore` changed among hidden files.
- Supplemental captured758 chat repair contains2files: `lib/chat/service.ts` and `tests/quote-references.test.mjs`. Later source changes require their own capture/readback.
