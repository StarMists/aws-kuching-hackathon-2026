import { requireOwner,assertSameOrigin } from '@/lib/auth';
import { all,db,ownedProject,parseJson } from '@/lib/db';
import { ApiError,apiData,apiError,readJson,requiredString } from '@/lib/http';
import type { Document,Chat,Note,Artifact } from '@/lib/contracts';
export const dynamic='force-dynamic';
type Context={params:Promise<{id:string}>};
export async function GET(request:Request,context:Context){try{const owner=await requireOwner(request);const {id}=await context.params;const project=await ownedProject(owner,id);const [documents,chats,notes,artifacts]=await Promise.all([all<Document>('SELECT d.* FROM documents d JOIN project_documents pd ON pd.document_id=d.id WHERE pd.project_id=? AND d.owner_id=? ORDER BY d.created_at DESC',id,owner),all<Chat>('SELECT * FROM chats WHERE project_id=? AND owner_id=? ORDER BY updated_at DESC',id,owner),all<Note>('SELECT * FROM notes WHERE project_id=? AND owner_id=? ORDER BY updated_at DESC',id,owner),all<Artifact>('SELECT * FROM artifacts WHERE project_id=? AND owner_id=? ORDER BY updated_at DESC',id,owner)]);return apiData({project,documents,chats,notes:notes.map(note=>({...note,citations:parseJson(note.citations_json,[])})),artifacts:artifacts.map(artifact=>({...artifact,content:parseJson(artifact.content_json,{}),document_ids:parseJson(artifact.document_ids_json,[])}))})}catch(e){return apiError(e)}}
export async function PATCH(request:Request,context:Context){
  try{
    assertSameOrigin(request);
    const owner=await requireOwner(request),{id}=await context.params;
    const project=await ownedProject(owner,id),input=await readJson(request);
    const name=input.name===undefined?project.name:requiredString(input.name,'Project name',120);
    const description=input.description===undefined?project.description:typeof input.description==='string'?input.description.trim().slice(0,4000):project.description;
    if(input.expected_updated_at!==undefined&&typeof input.expected_updated_at!=='string')throw new ApiError(400,'INVALID_INPUT','Use the project timestamp shown by the workspace.');
    const expected=input.expected_updated_at as string|undefined;
    const previousStamp=Date.parse(project.updated_at);
    const stamp=new Date(Math.max(Date.now(),Number.isFinite(previousStamp)?previousStamp+1:0)).toISOString();
    const values:(string|number|null)[]=[input.name===undefined?0:1,name,input.description===undefined?0:1,description,stamp,id,owner];
    let sql='UPDATE projects SET name=CASE WHEN ?=1 THEN ? ELSE name END,description=CASE WHEN ?=1 THEN ? ELSE description END,updated_at=? WHERE id=? AND owner_id=?';
    if(expected!==undefined){sql+=' AND updated_at=?';values.push(expected);}
    const result=await db().prepare(sql).bind(...values).run();
    if(!result.meta.changes)throw new ApiError(409,'PROJECT_CHANGED','This project changed while you were editing. Refresh it and try again.');
    return apiData(await ownedProject(owner,id));
  }catch(e){return apiError(e)}
}
