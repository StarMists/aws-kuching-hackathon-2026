import { requireOwner } from '@/lib/auth';
import { apiData,apiError } from '@/lib/http';
import { usageBudget } from '@/lib/intelligence/usage';
export const dynamic='force-dynamic';
export async function GET(request:Request){try{return apiData(await usageBudget(await requireOwner(request)));}catch(error){return apiError(error);}}
