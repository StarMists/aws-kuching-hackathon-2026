import { requireOwner,assertSameOrigin } from '@/lib/auth';
import { background } from '@/lib/background';
import { ApiError,apiData,apiError,readJson } from '@/lib/http';
import { createAnalysisJob,parseAnalysisInput,processAnalysisJob } from '@/lib/intelligence/jobs';
import { all,ownedProject } from '@/lib/db';
import type { AnalysisJob } from '@/lib/intelligence/jobs';
export const dynamic='force-dynamic';
export async function GET(request:Request){try{const owner=await requireOwner(request),query=new URL(request.url).searchParams,project=query.get('project_id'),kind=query.get('kind');if(!project)throw new ApiError(400,'PROJECT_REQUIRED','Select a project to load its saved analyses.');await ownedProject(owner,project);if(kind&&!['brief','timeline','conflict','gap','impact','replay','graph'].includes(kind))throw new ApiError(400,'INVALID_ANALYSIS_KIND','Choose a supported analysis type.');return apiData(kind?await all<AnalysisJob>('SELECT * FROM analysis_jobs WHERE owner_id=? AND project_id=? AND kind=? ORDER BY created_at DESC LIMIT 50',owner,project,kind):await all<AnalysisJob>('SELECT * FROM analysis_jobs WHERE owner_id=? AND project_id=? ORDER BY created_at DESC LIMIT 50',owner,project));}catch(error){return apiError(error);}}
export async function POST(request:Request){try{assertSameOrigin(request);const owner=await requireOwner(request),input=parseAnalysisInput(await readJson(request)),result=await createAnalysisJob(owner,input);if(result.job.status==='queued')background(processAnalysisJob(owner,result.job.id));return apiData(result,202);}catch(error){return apiError(error);}}
