import { assertSameOrigin, requireOwner } from '@/lib/auth';
import { ApiError, apiData, apiError, readJson, requiredString } from '@/lib/http';
import { createEmbeddingTask, embeddingTaskView, processEmbeddingTask } from '@/lib/retrieval/embedding-jobs';

export const dynamic = 'force-dynamic';

export async function GET(request: Request): Promise<Response> {
  try {
    const owner = await requireOwner(request);
    const id = requiredString(new URL(request.url).searchParams.get('task_id'), 'Index task ID', 200);
    return apiData(await embeddingTaskView(owner, id));
  } catch (error) { return apiError(error); }
}

export async function POST(request: Request): Promise<Response> {
  try {
    assertSameOrigin(request);
    const owner = await requireOwner(request);
    const body = await readJson<Record<string, unknown>>(request);
    if (body.task_id !== undefined) return apiData(await processEmbeddingTask(owner, requiredString(body.task_id, 'Index task ID', 200)));
    const projectId = requiredString(body.project_id, 'Project ID', 200);
    if (body.document_ids !== undefined && !Array.isArray(body.document_ids)) throw new ApiError(400, 'INVALID_SCOPE', 'Selected source document IDs must be an array.');
    const created = await createEmbeddingTask(owner, { project_id: projectId, document_ids: body.document_ids as string[] | undefined, public_data_acknowledged: body.public_data_acknowledged === true });
    if (!created.task) return apiData(created);
    return apiData(await processEmbeddingTask(owner, created.task.id), 202);
  } catch (error) { return apiError(error); }
}
