import { env } from 'cloudflare:workers';
import { notFound } from 'next/navigation';
import { getChatGPTUser } from '@/app/chatgpt-auth';
import { AcceptanceHarness } from '@/components/qa/acceptance-harness';
import fixture from '@/tests/fixtures/synthetic-civic/truth.json';
export const dynamic = 'force-dynamic';
export default async function QaPage() {
  const allowed = (env as unknown as Record<string, unknown>).QA_ALLOWED_OWNER_ID;
  const user = await getChatGPTUser();
  if (typeof allowed !== 'string' || !allowed.trim() || !user || user.userId !== allowed.trim()) notFound();
  const allowedSources = fixture.documents.flatMap(doc => ['pdf', 'txt'].map(extension => ({
    sha256: fixture.sha256[`${doc.id}.${extension}` as keyof typeof fixture.sha256],
    label: `${doc.title} · fixture v${doc.version}`,
    fixture_id: doc.id,
  }))).filter(source => typeof source.sha256 === 'string');
  return <AcceptanceHarness allowedSources={allowedSources} />;
}
