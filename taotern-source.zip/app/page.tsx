import Image from 'next/image';
import { AitlauApp } from '@/components/aitlau/app';
import { getChatGPTUser,chatGPTSignInPath } from './chatgpt-auth';

export const dynamic='force-dynamic';

export default async function Home() {
  const user=await getChatGPTUser();
  if(user)return <AitlauApp />;
  return <main style={{minHeight:'100dvh',display:'grid',placeItems:'center',background:'#f5f5f4',color:'#181818',padding:'2rem',fontFamily:'Arial, sans-serif'}}>
    <section style={{width:'100%',maxWidth:'42rem',border:'1px solid #c8c8c5',background:'#fff',padding:'clamp(1.5rem, 5vw, 3rem)'}}>
      <div style={{display:'flex',alignItems:'center',gap:'1rem',borderBottom:'1px solid #d4d4d1',paddingBottom:'1.5rem'}}><Image src='/favicon.svg' width={40} height={40} alt='' unoptimized /><strong style={{fontSize:'1.5rem',letterSpacing:'-.03em'}}>Taotern</strong></div>
      <h1 style={{fontSize:'clamp(1.8rem, 5vw, 2.7rem)',lineHeight:1.15,fontWeight:500,letterSpacing:'-.04em',margin:'2rem 0 1rem'}}>Sign in to your workspace</h1>
      <p style={{fontSize:'1rem',lineHeight:1.65,color:'#535353',maxWidth:'33rem'}}>Use your ChatGPT account to keep your projects, documents, chats and notes in your own private workspace.</p>
      <a href={chatGPTSignInPath('/')} target='_top' style={{display:'inline-block',margin:'1rem 0 1.5rem',background:'#202020',color:'#fff',padding:'1rem 1.25rem',fontSize:'1rem',textDecoration:'none'}}>Sign in with ChatGPT</a>
      <p style={{borderTop:'1px solid #d4d4d1',paddingTop:'1.25rem',fontSize:'.875rem',lineHeight:1.6,color:'#666'}}>AI processing requires confirmation that your sources and prompts are public or synthetic. Shared demo limits apply to AI requests.</p>
    </section>
  </main>;
}
