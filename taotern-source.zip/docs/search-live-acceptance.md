# Bounded hosted retrieval acceptance

Observed on 2026-10-07, approximately 04:32–04:36 UTC.

- Private Taotern release: source `5920c1fcb2e5ecce1f60ced0cc5e99d4b1d0e0d3`, environment revision 7
- Sources: three ready, original synthetic PDFs, totaling eight stored chunks
- Live execution: the authenticated owner browser
- Independent storage review: read-only Sites database tools; no additional provider request

## Real semantic index

The hosted UI reached eight of eight indexed chunks. The durable embedding task `7650fe98-0cba-4f3f-b76c-2a5c66c9b4d2` was completed after four two-chunk processing slices, with no error or remaining claim/lease.

Read-only storage review found eight unique chunk rows with `gemini-embedding-2` model metadata. Each chunk's text occurred literally in its corresponding stored page. The usage ledger contained exactly eight unique completed embedding-call records for that task, totaling 1,942 estimated input tokens. The complete source-selection array visible in the task preview matched all eight chunk/document IDs; each source hash and version matched the actual ready document.

The connector clipped large vector JSON values and the remainder of the task manifest. Full raw vector values were not independently parsed through that connector. The observed completed index count uses the runtime's actual valid-JSON, matching-model, 768-dimension guard; the provider adapter also validates finite values and nonzero magnitude before saving.

## Semantic-only retrieval

The owner selected Semantic retrieval and acknowledged that the selected material was public/synthetic, then submitted:

“Why was opening the resident service desk postponed?”

The hosted UI returned three documents and displayed “semantic retrieval”. The top Circular v2 result included page 2's explicit seven-day delay due to the accessible-ramp inspection on 3 November. Meeting-minutes page 2 returned relevant dissent. This establishes one actual model-backed paraphrase retrieval over the eight-chunk fixture; it does not establish exhaustive recall or production-scale search quality.

## Keyword and acknowledgement observation

An earlier keyword search without model acknowledgement returned two documents in clearly labelled lexical mode. This is the observed no-acknowledgement keyword path. A separate live semantic/hybrid-without-acknowledgement request and before/after provider-call-counter comparison are not asserted by this report.

## Source scope and persistence

The prior actual local Worker/D1/R2 integration suite verified newly uploaded keyword retrieval, exclusion from a separate project, invalid selected-source rejection, cross-owner denials, actual project/empty-project graphs, verified note citations, stale-note conflict rejection, and source/note/graph persistence across a Worker restart. Those local checks are distinct from this hosted semantic fixture run.

## Remaining acceptance boundaries

- This report covers the observed synthetic fixture, not arbitrary private or sensitive source material.
- The hosted run did not exercise the 400-vector capacity boundary. That bound and its coverage warning are implementation safeguards, not a measured hosted throughput claim.
- No additional model call, sign-in, credential read, environment change, or deployment was performed during the independent review.
