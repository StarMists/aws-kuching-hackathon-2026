# Retrieval and relationship behavior

## Spotlight

Search uses actual stored document chunks in D1. Every corpus query starts with the trusted authenticated owner. A project search additionally requires membership in that project. Explicit selected document IDs are verified before retrieval and before any model request. Searching outside a supplied project requires `allow_outside_project: true`; the response records this scope change.

Lexical relevance combines a BM25-style passage score, document-title matches, exact phrase boosts, and coverage of the original query terms. English tokenization and overlapping Chinese bigrams support bilingual material. A small published-in-code terminology bridge is deterministic lexical expansion. It does not represent an embedding model.

Document-balanced ranking returns one relevant passage per document before filling additional passages, with a default limit of three passages per document. The response includes both the compatible flat `results` array and ranked document groups with page passages, source dates, types, departments, versions, hashes, and preview/file links.

Filters cover source-date ranges, document type, department, exact version, and known successor status. Latest means that no owned successor document points to that document through explicit predecessor metadata. It is not a claim that every possible revision has been uploaded.

## Model-assisted search

The shared server-only AI provider is the only model boundary. With an enabled model and explicit public/synthetic-data acknowledgement, search can expand a natural-language query into bounded retrieval terms. The actual returned mode is `query-expanded`, and vector availability stays false when no vector index is present.

Vector retrieval requires a configured embedding model and stored finite chunk vectors with the same model provenance. Only then is a query embedding requested. Mismatched-model, malformed, or missing vectors never receive a fabricated semantic score. Partial vector coverage falls back to hybrid lexical ranking and is disclosed. Search never silently embeds the entire corpus or claims that configuration alone is a working index.

`POST /api/search/index` explicitly creates a semantic-index task for an owned project and optional selected document IDs. It requires public/synthetic-data acknowledgement and an actual configured embedding service. Each durable task freezes chunk IDs, document hashes, versions, and the model, then uses the same authoritative per-owner queue as ingestion and analysis. A process request embeds at most two chunks. A fenced lease prevents concurrent processors or a stopped task from saving stale vectors. Actual provider results are saved as 768-dimensional D1 vectors with model provenance; subsequent process requests skip already saved vectors.

`GET /api/search/index?task_id=...` reports durable task and index progress. Duplicate pending selections reuse their task. A task manifest holds at most 1,000 missing chunks and reports the total source-scope counts plus `partial_manifest`; when that manifest finishes, another explicit index request can cover the remaining scope. Keyword search and existing vectors remain available after a failed, stopped, or partially completed index task. Free-token reservations are made before real model calls; unknown usage after a network failure remains conservatively reserved.

If keys, consent, vectors, or a provider request are unavailable, deterministic lexical search remains usable and the response explains the actual mode. No model key is accepted in a browser request.

## Capacity and coverage

Lexical requests rank at most 6,000 stored candidate passages and never load vector JSON blobs. Above that size, lexical search uses parameterized SQL candidate filtering. Scoring retains only query-term frequencies rather than every token array. Semantic/hybrid requests separately load at most 400 matching-model stored vectors, prioritizing recently updated sources, and merge those candidates into the broader lexical pool. This avoids loading thousands of 768-dimensional serialized vectors into a 128 MiB Worker isolate. Separate lexical/vector coverage counts and a truncation warning disclose partial vector evaluation. Overview retains a bounded text-only recent slice. Source selections use `json_each` rather than an unbounded SQL parameter list.

The relationship graph displays at most 200 recently updated documents, with the full document library still available through search and project collections. Its text processing is cached per chunk, and relationship evidence is extracted only for retained edges.

## Overview and graph

All graph nodes are derived from verified corpus documents, their metadata, or actual chunk terms. Topic groups favor readable domain concepts; generic words, document metadata noise, and morphological stems are not presented as topic labels. If the corpus already has useful known concepts, the graph does not pad the topic list with arbitrary recurring words. Fallback labels preserve the actual original word form. Source-named entity phrases with an action cue are displayed as heuristic entities with actual mentioning passages.

Topic groups, named-phrase entity classification, and shared-term document links are explicitly `inferred`; they are discovery suggestions rather than official relationships. Recorded department metadata is marked explicit metadata.

An explicit `references` link requires an exact target title or filename with nearby reference language in a real source chunk. A `supersedes` link requires a recorded predecessor ID. Each text-derived relationship carries page/chunk quotes and source hashes. The graph reports `method: deterministic` and does not fabricate model findings when AI is unavailable.

## Saved notes

Notes are persisted under an owned project in D1. Structured citations are checked against an actual ready document chunk and corresponding stored page in that project. Document identity, page number, title, source hash, and quote identity are canonicalized; fabricated quotes or foreign/out-of-project chunks are rejected. Matching may collapse whitespace, but the saved quote is always an exact original chunk/page substring. Unicode character substitutions, including fullwidth/ASCII and ligature replacements, are rejected rather than saved as quotations.

Note edits retain existing citations unless explicitly replaced. Optional `expected_updated_at` protects edits opened against an older version, and the update itself uses a compare-and-swap timestamp to prevent overlapping saves from silently overwriting one another.

## Verification

`tests/retrieval-ranking.test.mjs` covers actual relevance, English/Chinese matching, document balancing, model-expanded lexical behavior, vector provenance, explicit versus inferred graph links, ambiguous titles, scope-filtered graph input, and empty collections. `tests/retrieval-sql.test.mjs` executes candidate SQL against an actual SQLite database, checking title/body retrieval, owner predicates, escaped wildcards, SQL-looking text, bounded parameters, and JSON source selections. `tests/embedding-manifest.test.mjs` checks source identity, hashes, versions, consent, duplicates, and progress bounds. HTTP/D1/R2 integration is verified separately by the delivery test harness; no-key behavior and mock tests do not establish live semantic-index acceptance.
