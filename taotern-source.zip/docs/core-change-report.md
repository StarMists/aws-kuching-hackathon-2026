# AITLAU Sites core integration change report

Initial verified private deployment: 7 October 2026, 03:46:22 UTC.

Source commit: `9e7e5421c27ad286e1c296506e7a630aff23a949`.

Production URL: https://aitlau-kuching-2026.liuyz8715.chatgpt.site

Access remains owner-private. No public demo audience, invitation, external collaborator, AWS resource, self-hosted service, or paid model adapter was enabled.

## Core-owned files

- `.openai/hosting.json`: registers the existing private Site identity and declares only logical D1 `DB` and private R2 `BUCKET` bindings. It contains no runtime values or credentials.
- `db/schema.ts`: defines Projects, document families/versions/metadata, page/chunk evidence, serial durable tasks, independent chat envelopes and ordered typed parts, immutable chat-job source rows, analysis jobs/artifacts, cited notes, and usage receipts.
- `drizzle/0000_remarkable_makkari.sql`: generated initial schema-only migration for the 15 product tables, foreign keys, and uniqueness/index rules.
- `drizzle/meta/0000_snapshot.json`: generated initial schema snapshot.
- `drizzle/0001_enforce_domain_invariants.sql`: append-only schema-only SQLite triggers enforce canonical statuses, immutable owner IDs, cross-record owner consistency, source-page/chunk/citation identities, immutable accepted chat sources, and one processing source task per owner.
- `drizzle/meta/0001_snapshot.json` and `drizzle/meta/_journal.json`: generated custom-migration metadata; already-applied migration history remains unchanged.
- `lib/contracts.ts`: shared snake_case API/domain types retain AITLAU's task status, envelope, part, page, citation, and source-selection contracts.
- `CONTRACTS.md`: cross-module file ownership, endpoint payloads, source-scope rules, durability limits and integration contracts.
- `lib/db.ts`: D1/R2 binding access plus prepared-query, ownership and scoped corpus helpers. JSON array selection avoids D1 parameter-count overflow. Runtime schema creation is prohibited.
- `lib/auth.ts`: checks only trusted platform identity headers and enforces same-origin mutations. The anonymous development-owner fallback was removed.
- `lib/http.ts`: consistent no-store response envelopes and sanitized typed application/provider errors.
- `lib/background.ts`: request-scoped execution context wraps acknowledged bounded background work without introducing a global scheduler.
- `build/sites-worker.ts`: preserves the Sites/Vinext/connector wrapper and adds the request execution context needed for `waitUntil`.
- `lib/config.ts`: exposes non-secret real storage/model readiness from the shared AI configuration and product upload limits.
- `cloudflare-env.d.ts`: typed logical storage and server-only model settings, with no credential values.
- `app/api/projects/route.ts`: owner-scoped list/create with durable canonical IDs and timestamps.
- `app/api/projects/[id]/route.ts`: owner-scoped Project detail/update, including scoped documents, chats, notes with parsed citations and artifacts with parsed structured content.
- `app/api/projects/[id]/documents/route.ts`: transactional attach/detach of owned source documents without deleting their original records or files.
- `app/api/config/route.ts`: authenticated safe readiness and capability metadata.
- `app/api/health/route.ts`: authenticated actual database health plus safe runtime configuration.
- `app/api/health/model/route.ts`: authenticated fixed public/synthetic model probe, actual provider/usage/latency receipt and sanitized failure. It accepts no key, source file, custom prompt, or owner ID.
- `package.json` and `package-lock.json`: retain Sites starter dependencies and add pinned Worker-compatible `unpdf@1.8.1` and browser `pdfjs-dist@5.4.624`.
- `.gitignore`: excludes dependencies, local environment/runtime state, generated build outputs and TypeScript build metadata.
- `README.md`: product purpose, actual source pins, Sites-only runtime, restore/build/migration workflow, privacy/model setup and honest bounded execution behavior.
- `docs/sites-migration-architecture.md`: exact retained AITLAU concepts, runtime replacements, source/ownership invariants and platform limits.
- `docs/core-change-report.md`: this file-level report.

The remaining module file changes and precise source adaptation are recorded in `docs/PROVENANCE.md`, `docs/document-ingestion-provenance.md`, `docs/retrieval-and-relationships.md`, `docs/ACCEPTANCE.md` and `RECOVERY.md`. Original input snapshots were not edited and are not part of the application source package.

## Practical effects

Users work in a private document-first React workspace. D1 replaces Supabase as the source of truth, R2 replaces original-file storage, and server-only API adapters replace the private local model services. Original document/page/citation and task/chat invariants continue to govern accepted work. New Projects and evidence investigations extend that domain rather than providing an unrelated mockup.

There is no always-running Docker/PGMQ daemon. Worker post-response work is bounded to 30 seconds; model requests are bounded, job/claim/progress state is persisted and queued slices resume through authorized polling. Missing key, actual provider failure, missing semantic index or incomplete OCR remains visible. A configured key is not labelled a verified connection before the real probe succeeds.

## Verified at the first private deployment

- Whole application TypeScript check passes.
- Full Sites/Vinext Worker build passes with 35 API route families.
- Local D1 initial migration: 36 commands succeed.
- Local D1 invariant migration: 60 commands succeed.
- Actual built Worker HTTP acceptance: 10 pass, including source/project scope, notes/citation forgery protection, private source file retrieval and missing-key behavior.
- Real local Worker restart preserves D1 records and original R2 bytes.
- Pure schema acceptance: 7 positive/negative guard tests pass.
- Native Mandarin two-page PDF extraction and page identity pass using bundled official CMaps.
- Focused provider/evidence, ingestion and retrieval tests pass; provider mocks do not establish live API quality.
- The source package excludes runtime state and secret values; package audit reports no findings.
- Source checkpoint 02 contains 408 files, CRC verified, SHA256 `a4bed501360fe499df95dc620d05ae00c1478647cae06975bf59e7d786ec4cf2`.
- Worker JavaScript is approximately 4.57 MB raw / 1.94 MB summed gzip, including native CJK CMaps.
- Native private deployment succeeds using environment revision 5.

## Still being verified

Actual free-provider model/OCR/semantic quality, long multi-page resume/stop paths, all intelligence workflows on fresh sources, responsive browser usability, and final clean source restore are acceptance work in progress after the first deployed checkpoint. See the continuously updated acceptance and recovery documents for later evidence; this first checkpoint does not claim those results.

## Taotern release update (7 October 2026)

The owner renamed the visible product to **Taotern**. The same Site now uses https://taotern-kuching-2026.liuyz8715.chatgpt.site; its project identity, auth client, private access and DB/R2 bindings are unchanged. Original source names remain only in historical provenance, internal identifiers and license attribution.

The actual hosted synthetic model probe passed at 04:06:14.333 UTC with Gemini 3.8 Flash via `gemini-generate-content`: 23 input tokens, 3 output tokens, 26 total tokens, and `probe_valid=true`. Its earlier Interactions attempt timed out; no fake provider result was substituted. The next release defaults to the verified generateContent transport with a 22-second per-attempt and 24-second total bound, and intentionally enables the documented free Gemini Embedding 2 model for actual semantic-index acceptance.

Additional core changes:
- `lib/contracts.ts`: optional stable `Citation.quote_id` shared with saved-note lookup.
- `cloudflare-env.d.ts`: typed transport/deadline/token-bound environment names, without runtime values.
- `drizzle/0002_enforce_citation_grounding.sql`: four forward-only triggers require future typed chat citations to reference the accepted response-job sources and to occur literally in both stored chunk and page. Historical rows and prior migrations remain untouched.
- `drizzle/meta/0002_snapshot.json` and `drizzle/meta/_journal.json`: generated custom migration metadata.

Local migration 0002 applied four commands successfully. Positive/negative guard tests verify raw CRLF, Mandarin and emoji quotes, reject owned-but-unselected sources and fabricated/flattened quotes, and preserve valid existing parts. The underlying exact canonical quote transformation is tested separately.

Expanded actual local Worker acceptance now passes 14 checks, including Mandarin native extraction, version lineage, hash deduplication, immutable metadata, ten-page stop/restore/idempotent completion, private R2 and restart persistence. An independent exact-source restoration installed all 701 locked packages and passed typecheck, tests and build without authoring-workspace symlinks or fallback imports. Live OCR, semantic vectors and all reasoning outputs remain acceptance work until their actual receipts and source comparisons are recorded.
