'use client';

import { useEffect, useRef, useState } from 'react';
import { FileText, Loader2 } from 'lucide-react';
import type { PDFDocumentProxy, PDFPageProxy, RenderTask, TextLayer } from 'pdfjs-dist';
import { ErrorNotice } from '@/components/aitlau/ui';
import { sourcePageNumber } from './api';

export type PdfFit = 'page' | 'width' | 'custom';
export interface PdfInformation { pages: number; scale: number; width: number; height: number; quote_found: boolean }

export function PdfPage({ documentId, pageNumber, fit, zoom, quote, onInformation }: { documentId: string; pageNumber: number; fit: PdfFit; zoom: number; quote?: string; onInformation: (info: PdfInformation) => void }) {
  const host = useRef<HTMLDivElement>(null); const canvas = useRef<HTMLCanvasElement>(null); const textLayerHost = useRef<HTMLDivElement>(null); const callbacks = useRef(onInformation);
  const [pdf, setPdf] = useState<PDFDocumentProxy | null>(null); const [size, setSize] = useState({ width: 900, height: 700 }); const [loading, setLoading] = useState(true); const [error, setError] = useState(''); const [rendering, setRendering] = useState(false);
  useEffect(() => { callbacks.current = onInformation; }, [onInformation]);
  useEffect(() => { const element = host.current; if (!element) return; const observer = new ResizeObserver(entries => { const entry = entries[0]; if (entry) setSize({ width: Math.max(200, element.clientWidth), height: Math.max(200, element.clientHeight) }); }); observer.observe(element); return () => observer.disconnect(); }, []);
  useEffect(() => {
    const controller = new AbortController(); let alive = true; let loaded: PDFDocumentProxy | null = null;
    queueMicrotask(() => { if (alive) { setLoading(true); setError(''); setPdf(null); } });
    async function open() {
      try {
        const response = await fetch(`/api/documents/${encodeURIComponent(documentId)}/file`, { credentials: 'same-origin', signal: controller.signal });
        if (!response.ok) throw new Error(`The original PDF could not be opened (${response.status}).`);
        const bytes = new Uint8Array(await response.arrayBuffer());
        const pdfjs = await import('pdfjs-dist'); const { default: workerUrl } = await import('pdfjs-dist/build/pdf.worker.min.mjs?url');
        pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;
        loaded = await pdfjs.getDocument({ data: bytes, isEvalSupported: false, useSystemFonts: true, cMapUrl: '/pdfjs/cmaps/', cMapPacked: true }).promise;
        if (!alive) { await loaded.destroy(); return; } setPdf(loaded); setLoading(false);
      } catch (failure) { if (alive && !controller.signal.aborted) { setError(failure instanceof Error ? failure.message : 'The original PDF could not be rendered.'); setLoading(false); } }
    }
    void open(); return () => { alive = false; controller.abort(); void loaded?.destroy(); };
  }, [documentId]);
  useEffect(() => {
    if (!pdf || !canvas.current || !textLayerHost.current) return; let alive = true; let renderTask: RenderTask | null = null; let layer: TextLayer | null = null; let page: PDFPageProxy | null = null;
    queueMicrotask(() => { if (alive) { setRendering(true); setError(''); } });
    async function render() {
      try {
        page = await pdf!.getPage(sourcePageNumber(pageNumber, pdf!.numPages)); if (!alive) return;
        const original = page.getViewport({ scale: 1 }); const styles = window.getComputedStyle(host.current!); const availableWidth = Math.max(200, size.width - parseFloat(styles.paddingLeft) - parseFloat(styles.paddingRight) - 2); const availableHeight = Math.max(200, size.height - parseFloat(styles.paddingTop) - parseFloat(styles.paddingBottom) - 2);
        const scale = Math.max(0.25, Math.min(4, fit === 'custom' ? zoom : fit === 'width' ? availableWidth / original.width : Math.min(availableWidth / original.width, availableHeight / original.height)));
        const viewport = page.getViewport({ scale }); const pixelRatio = Math.min(window.devicePixelRatio || 1, 2, 4096 / viewport.width, 8192 / viewport.height, Math.sqrt(16_000_000 / (viewport.width * viewport.height))); const element = canvas.current!; const container = textLayerHost.current!;
        const context = element.getContext('2d'); if (!context) throw new Error('This browser could not create a PDF canvas.');
        element.width = Math.ceil(viewport.width * pixelRatio); element.height = Math.ceil(viewport.height * pixelRatio); element.style.width = `${viewport.width}px`; element.style.height = `${viewport.height}px`;
        container.replaceChildren(); container.style.width = `${viewport.width}px`; container.style.height = `${viewport.height}px`; container.style.setProperty('--total-scale-factor', String(scale));
        renderTask = page.render({ canvas: element, canvasContext: context, viewport, transform: pixelRatio !== 1 ? [pixelRatio, 0, 0, pixelRatio, 0, 0] : undefined, background: '#ffffff' }); await renderTask.promise;
        if (!alive) return; const text = await page.getTextContent(); if (!alive) return; const pdfjs = await import('pdfjs-dist'); if (!alive) return;
        // A fit/resize can cancel while native text or the module is loading.
        // Only the latest render may create a selectable layer in this host.
        container.replaceChildren();
        layer = new pdfjs.TextLayer({ textContentSource: text, container, viewport }); await layer.render(); if (!alive) return;
        const found = quote ? highlightQuote(layer.textContentItemsStr, layer.textDivs, quote) : false;
        callbacks.current({ pages: pdf!.numPages, scale, width: original.width, height: original.height, quote_found: found }); setRendering(false);
        if (found) container.querySelector('.pdf-citation-mark')?.scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });
      } catch (failure) { if (alive && !(failure instanceof Error && failure.name === 'RenderingCancelledException')) { setError(failure instanceof Error ? failure.message : 'This PDF page could not be rendered.'); setRendering(false); } }
    }
    void render(); return () => { alive = false; renderTask?.cancel(); layer?.cancel(); page?.cleanup(); };
  }, [pdf, pageNumber, fit, zoom, size.width, size.height, quote]);
  return <div className="pdf-render-host" ref={host}>{(loading || rendering) && <div className="pdf-render-status" role="status"><Loader2 size={16} className="spin" /><span>{loading ? 'Opening the original PDF…' : 'Rendering original page…'}</span></div>}{error && <div className="pdf-render-error"><ErrorNotice message={error} /><p>The original file is preserved. Open it in a separate tab, or use the extracted-text view.</p></div>}<div className={`pdf-original-page ${loading || error ? 'pdf-page-hidden' : ''}`}><canvas ref={canvas} aria-label={`Original PDF, page ${pageNumber}`} /><div ref={textLayerHost} className="pdf-text-layer" aria-label={`Selectable original PDF text, page ${pageNumber}`} /></div>{!loading && !pdf && !error && <div className="pdf-render-empty"><FileText size={25} /><p>No original PDF available.</p></div>}</div>;
}

function highlightQuote(items: string[], divs: HTMLElement[], quote: string): boolean {
  const needle = quote.replace(/\s+/g, ' ').trim(); if (!needle) return false;
  for (const separator of [' ', '']) {
    let combined = ''; const mapping: { item: number; offset: number }[] = []; let space = false;
    for (let index = 0; index < items.length; index++) {
      const value = (index ? separator : '') + items[index];
      for (let offset = 0; offset < value.length; offset++) {
        const character = value[offset]; const local = Math.max(0, offset - (index ? separator.length : 0));
        if (/\s/.test(character)) { if (!space) { combined += ' '; mapping.push({ item: index, offset: local }); } space = true; }
        else { combined += character; mapping.push({ item: index, offset: local }); space = false; }
      }
    }
    const start = combined.indexOf(needle); if (start < 0) continue;
    const ranges = new Map<number, { start: number; end: number }>();
    for (let index = start; index < start + needle.length; index++) { const point = mapping[index]; if (!point) continue; const range = ranges.get(point.item); if (range) range.end = Math.max(range.end, point.offset + 1); else ranges.set(point.item, { start: point.offset, end: point.offset + 1 }); }
    for (const [index, range] of ranges) { const element = divs[index]; const text = items[index]; if (!element || !text) continue; const mark = document.createElement('span'); mark.className = 'pdf-citation-mark'; mark.textContent = text.slice(range.start, range.end); element.replaceChildren(document.createTextNode(text.slice(0, range.start)), mark, document.createTextNode(text.slice(range.end))); }
    return ranges.size > 0;
  }
  return false;
}
