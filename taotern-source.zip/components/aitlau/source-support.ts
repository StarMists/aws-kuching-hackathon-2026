import type { Document } from '@/lib/contracts';

export interface IngestionSupport {
  status: 'supported' | 'not_supported' | 'partial';
  unsupported_pages: number[];
  native_pages: number[];
  total_pages: number;
  message: string;
  retry_allowed: boolean;
}
export interface SupportEnvelope { ingestion_support?: IngestionSupport }

/** Only authoritative support flags or extraction markers classify a source as unsupported. */
export function sourceSupport(document?: Document | null, explicit?: IngestionSupport): IngestionSupport | null {
  const value = explicit || (document as (Document & SupportEnvelope) | null | undefined)?.ingestion_support;
  if (value && ['supported', 'not_supported', 'partial'].includes(value.status)) return value;
  const method = document?.extraction_method;
  const status = method === 'partial_native_text' ? 'partial' : method === 'unsupported' || document?.error_message?.startsWith('NOT SUPPORTED:') ? 'not_supported' : null;
  return status ? { status, unsupported_pages: [], native_pages: [], total_pages: document?.page_count || 0, message: document?.error_message || '', retry_allowed: false } : null;
}
export function unsupportedExtraction(document?: Document | null, explicit?: IngestionSupport): boolean {
  const support = sourceSupport(document, explicit);
  return support?.status === 'not_supported' || support?.status === 'partial';
}
export function supportSummary(value: IngestionSupport): string {
  if (value.status === 'supported') return 'Native text extraction is available.';
  if (value.status === 'partial') return `Native text is available${value.native_pages.length ? ` on pages ${value.native_pages.join(', ')}` : ' on supported pages'}.${value.unsupported_pages.length ? ` Text extraction: NOT SUPPORTED on pages ${value.unsupported_pages.join(', ')}.` : ' Some pages have unsupported text extraction.'} The complete original is preserved.`;
  return 'Text extraction: NOT SUPPORTED. The original is preserved and can still be read.';
}
export const conversionAdvice = 'Use an external OCR tool to convert unsupported pages to a searchable PDF or text file, then upload the converted source as a new version.';
