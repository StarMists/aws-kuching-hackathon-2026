'use client';
import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import type { Artifact, ArtifactKind, Citation, Document, Page, Project, ProjectDetail } from '@/lib/contracts';
interface AllowedSource { sha256: string; label: string; fixture_id: string }
interface Job { id: string; status: string; project_id: string; kind: ArtifactKind; request_json: string; source_snapshot_json: string; error_message?: string | null }
interface JobDetail { job: Job; artifact?: Artifact | null; lease_expired?: boolean }
interface Check { document_id: string; page_number: number; chunk_id: string; quote: string; literal_page_match: boolean; literal_chunk_match: boolean; selected_source: boolean; source_hash_match: boolean; quote_id?: string }
interface Step { kind: ArtifactKind; name: string; idempotency_key: string; status: string; job_id?: string; error?: string; artifact?: Artifact; checks?: Check[]; reviewed?: boolean }
const PLAN: Array<{kind:ArtifactKind;name:string;prompt?:string}> = [
  {kind:'timeline',name:'Decision timeline',prompt:'Trace the recorded proposal, rationale, dissent, decision, later revisions, and unresolved future actions. Preserve source dates and distinguish proposed events from completed events.'},
  {kind:'brief',name:'Editable briefing',prompt:'Summarize recorded facts, decisions, unresolved actions, conflicts, evidence still needed, and next questions. Do not invent procurement approval.'},
  {kind:'conflict',name:'Conflicting guidance',prompt:'Compare source statements on launch dates, counters, planning ceilings and readiness. Distinguish documented supersession from an unresolved contradiction.'},
  {kind:'gap',name:'Knowledge gaps',prompt:'Identify unresolved actions and evidence needed to determine procurement and accessibility clearance. Missing evidence is not proof that approval never happened.'},
  {kind:'impact',name:'New-version impact',prompt:'Compare the selected old and new circulars, retaining quoted old/new values and conditional implications for the existing planning decision and actions.'},
  {kind:'replay',name:'Old/new case replay'},
];
const CASE='SYNTHETIC HYPOTHETICAL CASE: A service team plans to launch the Serai pilot on the date in the older circular, with the older counter count. A revised circular changes the planning date, ceiling and counters after accessibility inspection timing changes. No signed procurement clearance or accessibility assessment is supplied for this hypothetical case. Compare this same case against the explicitly selected old and new guidance. Do not invent a historical case or approval.';
const terminal = (status:string) => ['completed','failed','stopped'].includes(status);
class RequestError extends Error { constructor(public code:string,message:string){super(message);} }
async function api<T>(url:string,body?:unknown):Promise<T>{
 const response=await fetch(url,{method:body===undefined?'GET':'POST',headers:body===undefined?undefined:{'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(30000),cache:'no-store'});
 const value=await response.json() as { data:T; error?:{code?:string;message?:string} };if(!response.ok)throw new RequestError(value.error?.code||'HTTP_'+response.status,value.error?.message||'The request failed.');return value.data as T;
}
function content(artifact:Artifact):Record<string,unknown>{try{return typeof artifact.content_json==='string'?JSON.parse(artifact.content_json):artifact.content as Record<string,unknown>||{};}catch{return {};}}
function citations(artifact:Artifact):Array<Citation&{quote_id?:string}>{const value=content(artifact);return ((value.claims||[]) as Array<{evidence?:Array<Citation&{quote_id?:string}>}>).flatMap(claim=>claim.evidence||[]);}
const sleep=(ms:number)=>new Promise(resolve=>setTimeout(resolve,ms));
export function AcceptanceHarness({allowedSources}:{allowedSources:AllowedSource[]}){
 const [projects,setProjects]=useState<Project[]>([]),[projectId,setProjectId]=useState(''),[documents,setDocuments]=useState<Document[]>([]),[selected,setSelected]=useState<string[]>([]),[oldId,setOldId]=useState(''),[newId,setNewId]=useState(''),[ack,setAck]=useState(false),[steps,setSteps]=useState<Step[]>([]),[busy,setBusy]=useState(false),[error,setError]=useState(''),[startedAt,setStartedAt]=useState('');
 const stopped=useRef(false),activeJob=useRef<string|null>(null);
 const allowed = documents.filter(doc=>doc.status==='ready'&&allowedSources.some(source=>source.sha256===doc.source_sha256));
 const selectedDocs=allowed.filter(doc=>selected.includes(doc.id));
 useEffect(()=>{api<Project[]>('/api/projects').then(setProjects).catch(e=>setError(String(e.message||e)));},[]);
 async function chooseProject(id:string){setProjectId(id);setDocuments([]);setSelected([]);setOldId('');setNewId('');setAck(false);setSteps([]);setError('');if(!id)return;try{const detail=await api<ProjectDetail>('/api/projects/'+encodeURIComponent(id));setDocuments(detail.documents);}catch(e){setError(String((e as Error).message));}}
 function patch(index:number,value:Partial<Step>){setSteps(previous=>previous.map((step,i)=>i===index?{...step,...value}:step));}
 async function inspect(artifact:Artifact,sourceIds:string[]):Promise<Check[]>{
  const loaded=new Map<string,{document:Document;pages:Page[]}>(),matchedChunks=new Map<string,string>();const checks:Check[]=[];
  for(const citation of citations(artifact)){
   if(!sourceIds.includes(citation.document_id)){checks.push({...citation,literal_page_match:false,literal_chunk_match:false,selected_source:false,source_hash_match:false});continue;}
   let source=loaded.get(citation.document_id);if(!source){source=await api('/api/documents/'+encodeURIComponent(citation.document_id));loaded.set(citation.document_id,source!);}
   const key=citation.document_id+'\u001f'+citation.quote;let chunk=matchedChunks.get(key);
   if(chunk===undefined){const search=await api<{results:Array<{chunk_id:string;text:string}>}>('/api/search',{query:citation.quote,project_id:projectId,document_ids:[citation.document_id],mode:'keyword',limit:50});chunk=search.results.find(hit=>hit.chunk_id===citation.chunk_id)?.text||'';matchedChunks.set(key,chunk);}
   checks.push({...citation,literal_page_match:!!source?.pages.find(page=>page.page_number===citation.page_number)?.text.includes(citation.quote),literal_chunk_match:chunk.includes(citation.quote),selected_source:sourceIds.includes(citation.document_id),source_hash_match:!!source?.document.source_sha256&&source.document.source_sha256===citation.source_sha256});
  }return checks;
 }
 async function readback(index:number,value:JobDetail){
  if(value.artifact){if(value.artifact.project_id!==projectId)throw new RequestError('QA_SCOPE_MISMATCH','The saved result is outside the explicitly selected project.');const actual=await api<Artifact>('/api/artifacts/'+value.artifact.id);const checks=await inspect(actual,selected);patch(index,{status:value.job.status,job_id:value.job.id,artifact:actual,checks,error:value.job.error_message||undefined});}
  else patch(index,{status:value.job.status,job_id:value.job.id,error:value.job.error_message||undefined});
 }
 function matchesSelection(job:Job,index:number){
  if(job.project_id!==projectId||job.kind!==PLAN[index].kind)return false;
  try {const request=JSON.parse(job.request_json) as Record<string,unknown>,snapshot=JSON.parse(job.source_snapshot_json) as Array<{document_id:string;source_sha256:string;version:string}>;
   const ids=request.document_ids;if(!Array.isArray(ids)||ids.length!==selected.length||!ids.every(id=>typeof id==='string'&&selected.includes(id)))return false;
   if(snapshot.length!==selectedDocs.length||!snapshot.every(source=>selectedDocs.some(doc=>doc.id===source.document_id&&doc.source_sha256===source.source_sha256&&doc.version===source.version)))return false;
   if(PLAN[index].prompt&&request.prompt!==PLAN[index].prompt)return false;
   if(['impact','replay'].includes(job.kind)&&(request.previous_document_id!==oldId||request.new_document_id!==newId))return false;
   if(job.kind==='replay'&&request.case_text!==CASE)return false;return request.public_data_acknowledged===true;
  }catch{return false;}
 }
 async function loadSaved(){
  if(busy||!selected.length||!oldId||!newId||oldId===newId)return;setBusy(true);setError('');
  try {const saved=await api<Job[]>('/api/analysis?project_id='+encodeURIComponent(projectId));const plan:Step[]=PLAN.map((item,index)=>{const job=saved.find(candidate=>matchesSelection(candidate,index));return {kind:item.kind,name:item.name,idempotency_key:job?.id||crypto.randomUUID(),job_id:job?.id,status:job?.status||'not started'};});
   setSteps(plan);for(let index=0;index<plan.length;index++){if(!plan[index].job_id)continue;const value=await api<JobDetail>('/api/analysis/'+plan[index].job_id);if(!matchesSelection(value.job,index))throw new RequestError('QA_SCOPE_MISMATCH','A saved job no longer matches the selected original sources.');await readback(index,value);}
   if(!plan.some(step=>step.job_id))setError('No saved original synthetic runs match this explicit source selection. Loading never starts a provider request.');
  }catch(e){setError((e as Error).message);}finally{setBusy(false);setAck(false);}
 }
 async function settle(index:number,jobId:string):Promise<JobDetail>{
  let value=await api<JobDetail>('/api/analysis/'+jobId);const deadline=AbortSignal.timeout(180000);
  while(!terminal(value.job.status)){
   if(deadline.aborted){setError('Readback paused after three minutes. The same durable backend job remains available; load saved results to inspect it.');break;}
   patch(index,{status:value.job.status,job_id:jobId});
   if(stopped.current){await api('/api/analysis/'+jobId+'/stop',{});value=await api('/api/analysis/'+jobId);break;}
   if(value.job.status==='queued'||value.lease_expired)value=await api('/api/analysis/'+jobId+'/process',{});
   else {await sleep(1500);value=await api('/api/analysis/'+jobId);}
  }
  await readback(index,value);
  return value;
 }
 async function runAll(){
  if(busy||!ack||selectedDocs.length!==selected.length||!selected.length||!oldId||!newId||oldId===newId)return;
  setBusy(true);setError('');stopped.current=false;const start=new Date().toISOString();setStartedAt(start);
  const plan=PLAN.map(item=>({kind:item.kind,name:item.name,idempotency_key:crypto.randomUUID(),status:'not started'}));setSteps(plan);
  try{
   for(let index=0;index<plan.length;index++){
    if(stopped.current)break;const step=plan[index];patch(index,{status:'submitting',job_id:step.idempotency_key});activeJob.current=step.idempotency_key;
    try{
     const body={project_id:projectId,kind:step.kind,document_ids:selected,public_data_acknowledged:true,idempotency_key:step.idempotency_key,...(PLAN[index].prompt?{prompt:PLAN[index].prompt}:{}),...(['impact','replay'].includes(step.kind)?{previous_document_id:oldId,new_document_id:newId}:{}),...(step.kind==='replay'?{case_text:CASE}:{})};
     const created=await api<JobDetail>('/api/analysis',body);activeJob.current=created.job.id;patch(index,{job_id:created.job.id,status:created.job.status});const finished=await settle(index,created.job.id);
     if(finished.job.status!=='completed'){setError('Batch paused after a real failed, stopped or unfinished job. Remaining steps were not run. Review this result before any explicit retry.');break;}
     activeJob.current=null;if(index<plan.length-1)await pace(index);
    }catch(e){const failure=e as RequestError;patch(index,{status:'request failed',error:(failure.code?failure.code+': ':'')+failure.message});setError('Batch paused on a real request failure. Review the failure before retrying.');break;}
   }
  }finally{activeJob.current=null;setBusy(false);setAck(false);}
 }
 async function pace(index:number){for(let remaining=65;remaining>0&&!stopped.current;remaining--){patch(index,{status:'completed · next call in '+remaining+'s'});await sleep(1000);}patch(index,{status:'completed'});}
 async function retryFailed(){
  if(busy||!ack)return;setBusy(true);setError('');stopped.current=false;
  try {for(let index=0;index<steps.length;index++){const step=steps[index];if(stopped.current)break;if(step.status!=='failed'||!step.job_id)continue;
   const existing=await api<JobDetail>('/api/analysis/'+step.job_id);if(!matchesSelection(existing.job,index))throw new RequestError('QA_SCOPE_MISMATCH','The saved retry job does not match this project, exact original source hashes, prompt and old/new pair.');
   if(existing.job.status!=='failed'){await readback(index,existing);continue;}
   activeJob.current=step.job_id;await api('/api/analysis/'+step.job_id+'/retry',{});const result=await settle(index,step.job_id);activeJob.current=null;
   if(result.job.status!=='completed'){setError('Retry batch paused after this real failure or unfinished job. No later job was retried; provider limits and errors require explicit review.');break;}
   if(steps.slice(index+1).some(later=>later.status==='failed'&&later.job_id))await pace(index);
  }}catch(e){setError((e as Error).message);}finally{activeJob.current=null;setBusy(false);setAck(false);}
 }
 async function stop(){stopped.current=true;if(activeJob.current){try{await api('/api/analysis/'+activeJob.current+'/stop',{});}catch(e){setError('Stop request: '+(e as Error).message);}}}
 async function retry(index:number){const step=steps[index];if(!step.job_id||busy||!ack)return;setBusy(true);stopped.current=false;activeJob.current=step.job_id;try{const existing=await api<JobDetail>('/api/analysis/'+step.job_id);if(!matchesSelection(existing.job,index))throw new RequestError('QA_SCOPE_MISMATCH','This retry must match the exact selected original sources and stored request.');await api('/api/analysis/'+step.job_id+'/retry',{});await settle(index,step.job_id);}catch(e){setError((e as Error).message);}finally{setBusy(false);activeJob.current=null;setAck(false);}}
 function download(){const report={project_id:projectId,source_document_ids:selected,source_sha256:selectedDocs.map(doc=>({document_id:doc.id,sha256:doc.source_sha256})),old_document_id:oldId,new_document_id:newId,started_at:startedAt,exported_at:new Date().toISOString(),case_text:CASE,steps,notice:'Actual existing APIs and saved artifacts. Citation readback is a literal-source check, not a general model accuracy certification.'};const blob=new Blob([JSON.stringify(report,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='taotern-live-acceptance-report.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 return <main className="qa-shell"><style>{styles}</style><header><p>TAOTERN / OWNER ACCEPTANCE</p><h1>Run the synthetic evidence checks.</h1><p>This explicit-run harness calls the real analysis APIs, then reads saved artifacts and exact source pages/chunks. It supplements the normal product UI.</p><Link href="/">Return to workspace</Link></header>{error&&<div role="alert" className="qa-error">{error}</div>}<section><label>Choose the existing synthetic project<select value={projectId} disabled={busy} onChange={e=>void chooseProject(e.target.value)}><option value="">Choose a project</option>{projects.map(project=><option key={project.id} value={project.id}>{project.name}</option>)}</select></label><p>Only ready sources whose original-byte hash matches the original synthetic corpus are offered. No other document is selected or sent automatically.</p><button disabled={busy||!allowed.length} onClick={()=>setSelected(allowed.map(doc=>doc.id))}>Select all allowed synthetic sources</button><div className="qa-sources">{allowed.map(doc=><label key={doc.id}><input type="checkbox" disabled={busy} checked={selected.includes(doc.id)} onChange={e=>{setSelected(previous=>e.target.checked?[...previous,doc.id]:previous.filter(id=>id!==doc.id));setOldId('');setNewId('');}}/><span><strong>{doc.title}</strong><small>{doc.page_count} pages · stored version {doc.version} · {allowedSources.find(source=>source.sha256===doc.source_sha256)?.label}</small></span></label>)}{projectId&&!allowed.length&&<p>No ready original synthetic corpus sources in this project.</p>}</div><div className="qa-pair"><label>Old guidance<select disabled={busy} value={oldId} onChange={e=>setOldId(e.target.value)}><option value="">Choose the old circular</option>{selectedDocs.map(doc=><option key={doc.id} value={doc.id}>{doc.title} · {doc.version}</option>)}</select></label><label>New guidance<select disabled={busy} value={newId} onChange={e=>setNewId(e.target.value)}><option value="">Choose the new circular</option>{selectedDocs.filter(doc=>doc.id!==oldId).map(doc=><option key={doc.id} value={doc.id}>{doc.title} · {doc.version}</option>)}</select></label></div><details><summary>Read the fixed synthetic replay case</summary><p>{CASE}</p></details><label className="qa-ack"><input type="checkbox" disabled={busy} checked={ack} onChange={e=>setAck(e.target.checked)}/>I confirm these selected sources and the fixed case are synthetic, and authorize these six real free-provider analysis requests. Gemini free-tier input may be used to improve Google products.</label><div className="qa-actions"><button disabled={busy||!ack||!selected.length||!oldId||!newId||oldId===newId} onClick={()=>void runAll()}>Run all six checks</button><button disabled={busy||!selected.length||!oldId||!newId||oldId===newId} onClick={()=>void loadSaved()}>Load matching saved jobs (read only)</button><button disabled={busy||!ack||!steps.some(step=>step.status==='failed'&&step.job_id)} onClick={()=>void retryFailed()}>Retry failed saved jobs, paced</button><button disabled={!busy} onClick={()=>void stop()}>Stop current job and batch</button><button disabled={!steps.length} onClick={download}>Download actual run report</button></div></section><p>Retries preserve the saved job IDs, sources and case. Successful calls are separated by 65 seconds. The batch pauses on the first failure, including 429; it never automatically retries a provider error.</p><section aria-live="polite"><h2>Actual job and evidence readback</h2><p>Completed is the saved backend status. Literal citation checks do not establish whether every conclusion is correct. Inspect the outputs and compare them with the source truth before marking reviewed.</p>{steps.map((step,index)=>{const verified=step.checks?.filter(check=>check.literal_page_match&&check.literal_chunk_match&&check.selected_source&&check.source_hash_match).length||0;const value=step.artifact?content(step.artifact):{};return <article key={step.idempotency_key}><div className="qa-step-title"><h3>{index+1}. {step.name}</h3><strong>{step.status}</strong></div>{step.job_id&&<p className="qa-id">Job: {step.job_id}</p>}{step.error&&<p role="alert" className="qa-error">{step.error}</p>}{step.artifact&&<><p>Saved artifact: {step.artifact.id} · literal source checks: {verified}/{step.checks?.length||0}</p><details open><summary>Read actual saved output</summary><pre>{step.artifact.markdown}</pre></details><details><summary>Actual provider receipt and coverage</summary><pre>{JSON.stringify({receipt:value.receipt,coverage:value.coverage},null,2)}</pre></details><details><summary>Inspect citations and exact-source checks</summary>{step.checks?.map((check,n)=><div className="qa-citation" key={n}><a href={`/?document=${encodeURIComponent(check.document_id)}&page=${check.page_number}&chunk=${encodeURIComponent(check.chunk_id)}${check.quote_id?'&quote='+encodeURIComponent(check.quote_id):''}`} target="_blank" rel="noreferrer">Open source page {check.page_number}</a><pre>{check.quote}</pre><small>Page {String(check.literal_page_match)} · chunk {String(check.literal_chunk_match)} · selected {String(check.selected_source)} · hash {String(check.source_hash_match)}</small></div>)}</details><a href={`/api/artifacts/${step.artifact.id}/export?format=md`} download>Download actual editable Markdown</a><label className="qa-review"><input type="checkbox" checked={!!step.reviewed} onChange={e=>patch(index,{reviewed:e.target.checked})}/>I reviewed this actual output against its source evidence</label></>}{['failed','stopped'].includes(step.status)&&<button disabled={busy||!ack} onClick={()=>void retry(index)}>Retry this same durable job</button>}</article>;})}</section></main>;
}
const styles=`.qa-shell{max-width:1080px;margin:auto;padding:28px;color:#1c2321;font:15px/1.55 system-ui;background:#f7f8f5;min-height:100vh}.qa-shell h1{font-size:32px;line-height:1.2}.qa-shell h2{font-size:22px}.qa-shell h3{font-size:18px;margin:0}.qa-shell header>p:first-child{font-size:12px;letter-spacing:.14em}.qa-shell section,.qa-shell article{background:white;border:1px solid #d5dcd6;padding:20px;margin:22px 0}.qa-shell label{display:block}.qa-shell select{display:block;width:100%;padding:10px;border:1px solid #aab7ad;background:white;color:#152b20;margin:6px 0}.qa-shell button{padding:10px 14px;background:#123e2a;color:white;border:1px solid #123e2a;cursor:pointer;margin:8px 8px 8px 0;font-size:14px}.qa-shell button:disabled{opacity:.4;cursor:not-allowed}.qa-shell input[type=checkbox]{width:18px;height:18px;flex-shrink:0;margin:4px 8px 0 0}.qa-sources label,.qa-ack,.qa-review{display:flex!important;gap:8px;padding:12px 0}.qa-sources small{display:block;color:#4d5b51}.qa-pair{display:grid;grid-template-columns:1fr 1fr;gap:20px}.qa-error{padding:12px;border:1px solid #b44428;background:#fff3ed;color:#803219}.qa-shell pre{white-space:pre-wrap;overflow-wrap:anywhere;font:13px/1.6 ui-monospace,monospace;background:#f6f7f5;padding:14px}.qa-step-title{display:flex;justify-content:space-between;gap:12px}.qa-id{font-size:12px;color:#536257;overflow-wrap:anywhere}.qa-citation{border-top:1px solid #d9e0da;padding:10px 0}.qa-shell details{margin:12px 0}.qa-shell a{color:#174b32;text-decoration:underline}@media(max-width:600px){.qa-shell{padding:12px}.qa-pair{grid-template-columns:1fr}.qa-shell section,.qa-shell article{padding:14px}.qa-step-title{display:block}.qa-shell h1{font-size:27px}}`;
