#!/usr/bin/env node
// Actual local Wrangler/D1 engine test. Isolated temporary ledger, no provider calls.
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {readFile,writeFile,mkdtemp} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {readQuotaPolicy,quotaReservationStatement,quotaTotalsStatement} from '../lib/intelligence/quota.ts';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const temp=await mkdtemp(path.join(tmpdir(),'taotern-native-d1-quota-'));
const policy=readQuotaPolicy({QA_ALLOWED_OWNER_ID:'synthetic-verified-owner',AI_VISITOR_ENABLED:'true',AI_GLOBAL_DAILY_TOKEN_BUDGET:150000,AI_DAILY_TOKEN_BUDGET:150000});
assert.equal(policy.global_daily_tokens,150000);assert.equal(policy.visitor_daily_tokens,10000);assert.equal(policy.visitor_pool_daily_tokens,20000);assert.equal(policy.visitor_requests_per_minute,2);assert.equal(policy.global_active,2);assert.equal(policy.visitor_active,1);assert.equal(policy.lease_seconds,45);
const migration=await readFile(path.join(root,'drizzle/0000_remarkable_makkari.sql'),'utf8');
const ddl=migration.slice(0,migration.indexOf('--> statement-breakpoint'));
assert.match(ddl,/CREATE TABLE `ai_usage`/);
const source=await readFile(path.join(root,'lib/intelligence/quota.ts'));
const statements=[],checks=[];let count=0;
function add(sql,check,args=[]){const index=statements.length;statements.push({sql,args,mode:check?.fields?'all':'run'});if(check)checks.push({index,...check});}
add(ddl);
function literal(value){if(value===null)return 'NULL';if(typeof value==='number'){assert.ok(Number.isFinite(value));return String(value);}return "'"+String(value).replaceAll("'","''")+"'";}
function reset(){add('DELETE FROM ai_usage');}
const stamp='2026-10-07T12:00:00.000Z';
function reserve(label,expected,owner='synthetic-visitor-a',input=1000,output=1000,time=stamp,parent_id){const id='synthetic-reservation-'+(++count);const statement=quotaReservationStatement(policy,{id,owner,job_id:'synthetic-local-test',provider:'mock-only-no-network',model:'synthetic-quota',input,output,timestamp:time,parent_id});add(statement.sql,{label,changes:expected},statement.args);return id;}
function finish(id){add(`UPDATE ai_usage SET status='completed' WHERE id=${literal(id)}`);}
function totals(label,fields,owner='synthetic-visitor-a',time=stamp){const statement=quotaTotalsStatement(policy,owner,time);add(statement.sql,{label,fields},statement.args);}
// Global150k must apply across identities even when each viewer still has room.
reset();let id=reserve('owner143k reservation',1,'synthetic-verified-owner',143000,0);finish(id);id=reserve('visitor7k reaches shared150k',1,'synthetic-visitor-a',5000,2000);finish(id);reserve('global cap rejects otherwise eligible owner',0,'synthetic-verified-owner',1,0);totals('shared150k total',{global_tokens:150000,owner_tokens:7000});
// Individual visitor cap.
reset();id=reserve('visitor9k fits day',1,'synthetic-visitor-a',7000,2000);finish(id);reserve('visitor above10k denied',0,'synthetic-visitor-a',1001,0);totals('visitor9k preserved',{owner_tokens:9000});
// Combined visitor pool cannot multiply by different visitor IDs.
reset();id=reserve('visitorA10k',1,'synthetic-visitor-a',8000,2000);finish(id);id=reserve('visitorB10k',1,'synthetic-visitor-b',8000,2000);finish(id);reserve('visitorC exceeds20k pool',0,'synthetic-visitor-c',1,0);totals('visitor pool total',{visitor_tokens:20000});
// Every retry consumes a reservation/minute count but shares its parent active slot.
reset();id=reserve('first visitor minute call',1);reserve('second minute retry',1,'synthetic-visitor-a',1000,1000,stamp,id);reserve('third minute retry denied',0,'synthetic-visitor-a',1000,1000,stamp,id);reserve('owner reserved slot independent',1,'synthetic-verified-owner');totals('minute and active counts',{minute_calls:2,global_active:2,visitor_active:1});
// Global two active, one combined visitor active.
reset();reserve('first visitor active',1);reserve('second visitor active denied',0,'synthetic-visitor-b');reserve('owner can use second slot',1,'synthetic-verified-owner');reserve('third active global denied',0,'synthetic-verified-owner');totals('active slots bounded',{global_active:2,visitor_active:1});
// Expiry frees concurrency but never refunds unknown/reserved token cost.
reset();reserve('leased visitor',1,'synthetic-visitor-a',5000,2000);totals('45s lease expired but charge retained',{global_active:0,global_tokens:7000},'synthetic-visitor-a','2026-10-07T12:00:46.000Z');reserve('new visitor after expiry',1,'synthetic-visitor-b',1000,1000,'2026-10-07T12:00:46.000Z');
// Parent ownership/status/expiry fences retry calls.
reset();id=reserve('retry parent',1);reserve('foreign parent retry denied',0,'synthetic-visitor-b',1000,1000,stamp,id);reserve('expired parent retry denied',0,'synthetic-visitor-a',1000,1000,'2026-10-07T12:00:46.000Z',id);reserve('invented parent retry denied',0,'synthetic-verified-owner',1000,1000,stamp,'synthetic-absent');
// Daily reset cannot lose an active prior-day lease.
reset();reserve('prior-day active parent',1,'synthetic-visitor-a',1000,1000,'2026-10-06T23:59:50.000Z');totals('midnight resets tokens but retains slot',{global_tokens:0,visitor_active:1},'synthetic-visitor-b','2026-10-07T00:00:05.000Z');reserve('midnight second visitor still denied',0,'synthetic-visitor-b',1000,1000,'2026-10-07T00:00:05.000Z');
reset();totals('empty ledger zero totals',{global_tokens:0,owner_tokens:0,visitor_tokens:0,reserved_tokens:0,unknown_tokens:0,global_active:0,visitor_active:0});
const planFile=path.join(temp,'synthetic-statement-plan.json');await writeFile(planFile,JSON.stringify(statements,null,2));
const workerFile=path.join(temp,'local-qa-worker.mjs');
await writeFile(workerFile,`const statements=${JSON.stringify(statements)};export default {async fetch(request,env){const url=new URL(request.url);if(request.method==='GET')return Response.json({local_synthetic_qa:true});if(request.method!=='POST'||url.pathname!=='/qa-local-quotas')return new Response('No route',{status:404});try{const results=[];for(const item of statements){let prepared=env.DB.prepare(item.sql);if(item.args.length)prepared=prepared.bind(...item.args);results.push(await prepared[item.mode]());}return Response.json(results);}catch(error){return Response.json({error:String(error)},{status:500});}}};`);
const built=JSON.parse(await readFile(path.join(root,'dist/server/wrangler.json'),'utf8'));
const configFile=path.join(temp,'wrangler.json');
await writeFile(configFile,JSON.stringify({name:'taotern-local-quota-qa',main:workerFile,compatibility_date:built.compatibility_date,compatibility_flags:built.compatibility_flags,d1_databases:built.d1_databases}));
const port=5187,base=`http://127.0.0.1:${port}`;let stdout='',stderr='';
const child=spawn(process.execPath,['--import','./scripts/sites-env.mjs','./node_modules/wrangler/bin/wrangler.js','dev','--local','--config',configFile,'--persist-to',path.join(temp,'isolated-state'),'--ip','127.0.0.1','--port',String(port),'--inspector-port','0'],{cwd:root,env:{...process.env,WRANGLER_SEND_METRICS:'false',XDG_CONFIG_HOME:temp},stdio:['ignore','pipe','pipe'],detached:true});
child.stdout.on('data',v=>stdout+=v);child.stderr.on('data',v=>stderr+=v);
let result;
try{
 let ready=false;for(let i=0;i<100;i++){if(child.exitCode!==null)throw Error('Local QA Worker exited: '+stderr);try{const r=await fetch(base,{signal:AbortSignal.timeout(500)});if(r.ok){ready=true;break;}}catch{}await new Promise(resolve=>setTimeout(resolve,300));}assert.equal(ready,true,'Isolated local QA Worker ready');
 const response=await fetch(base+'/qa-local-quotas',{method:'POST',signal:AbortSignal.timeout(20000)});assert.equal(response.status,200,await response.clone().text());result=await response.json();
}finally{try{process.kill(-child.pid,'SIGTERM');}catch{}await writeFile(path.join(temp,'wrangler.log'),stdout+'\n'+stderr);}
await writeFile(path.join(temp,'native-d1-results.json'),JSON.stringify(result,null,2));
assert.equal(result.length,statements.length,'One native D1 result per exact prepared/bound statement');
for(const check of checks){const response=result[check.index];assert.equal(response.success,true,check.label);if('changes'in check)assert.equal(response.meta.changes,check.changes,check.label);if(check.fields)for(const [key,value]of Object.entries(check.fields))assert.equal(response.results[0][key],value,check.label+' '+key);}
const receipt={observed_at:new Date().toISOString(),engine:'actual local Wrangler Worker env.DB prepared/bound D1 statements',quota_source_sha256:createHash('sha256').update(source).digest('hex'),sql_sha256:createHash('sha256').update(JSON.stringify(statements)).digest('hex'),policy,asserted_statements:checks.length,total_statements:statements.length,provider_calls:0,production_mutation:false,isolated_state:temp,checks:checks.map(c=>({label:c.label,passed:true,...('changes'in c?{native_meta_changes:result[c.index].meta.changes}:{totals:c.fields})})),limits:'Native local D1 engine guard evidence; no second production account or concurrent production request test.'};
await writeFile(process.env.QA_REPORT_PATH||path.join(temp,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt,null,2));
