import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {prepareReferencedAnalysis,runAnalysis} from '../lib/intelligence/workflows.ts';
import {estimateTokens} from '../lib/ai/providers.ts';
import {extractPdfPages} from '../lib/ingest/pdf.ts';
import {chunkPageText} from '../lib/ingest/chunks.ts';
const source={chunk_id:'c-a',document_id:'d-a',document_title:'Synthetic source',page_number:1,text:'Action A-17:\r\nMira Tan must obtain procurement clearance.\nThe approval reference is not recorded.',page_text:'Action A-17:\r\nMira Tan must obtain procurement clearance.\nThe approval reference is not recorded.',score:1,source_sha256:'a'.repeat(64),version:'1'};
const coverage={selected_document_count:1,included_document_count:1,total_chunk_count:1,included_chunk_count:1,truncated:false,excluded_document_ids:[]};
const receipt={provider:'groq',model:'mock-only',usage:{input_tokens:1,output_tokens:1,total_tokens:2,estimated:true},latency_ms:1,attempts:1,fallback_used:false,cached:false};
function result(data){return {...receipt,text:JSON.stringify(data)};}
test('brief chooses IDs and saves the unchanged artifact citation/export format',async()=>{
 const input={project_id:'p',kind:'brief',public_data_acknowledged:true},prepared=prepareReferencedAnalysis(input,[source],coverage);
 const ref=prepared.catalogue.references.find(r=>r.quote.includes('Mira'));
 const generated=await runAnalysis(input,[source],coverage,async request=>{assert.deepEqual(request,{...prepared.request,signal:undefined});return result({title:'Synthetic brief',claims:[{id:'c1',text:'The recorded action requires procurement clearance.',citations:[{reference_id:ref.reference_id}]}],sections:[{heading:'Open actions',claim_ids:['c1']}],missing_evidence:['Where is the clearance reference?']});},undefined,prepared);
 assert.equal(generated.content.schema_version,1);assert.equal(generated.content.claims[0].evidence[0].quote,ref.quote);assert.match(generated.content.claims[0].evidence[0].quote_id,/^q_[0-9a-f]{24}$/);assert.match(generated.markdown,/document=d-a&page=1&chunk=c-a&quote=q_/);assert.ok(generated.markdown.includes('Evidence still needed'));
});
test('gap remains an evidence question with only literal source claims',async()=>{
 const input={project_id:'p',kind:'gap'},prepared=prepareReferencedAnalysis(input,[source],coverage),ref=prepared.catalogue.references.find(r=>r.quote.includes('not recorded'));
 const generated=await runAnalysis(input,[source],coverage,async()=>result({title:'Clearance evidence gap',claims:[{id:'c1',text:'The source does not record the approval reference.',citations:[{reference_id:ref.reference_id}]}],findings:[{id:'f1',type:'evidence_gap',title:'Approval record',claim_ids:['c1'],questions:['Where is the signed approval record?']}],missing_evidence:[]}),undefined,prepared);
 assert.equal(generated.content.findings[0].questions[0],'Where is the signed approval record?');assert.equal(generated.content.findings[0].review.status,'unreviewed');assert.equal(generated.content.claims[0].evidence[0].quote,ref.quote);
});
test('analysis protocol refuses rewritten and fabricated reference citations',async()=>{
 const input={project_id:'p',kind:'brief'},prepared=prepareReferencedAnalysis(input,[source],coverage);
 for(const citation of [{reference_id:'r999'},{chunk_id:'c-a',quote:'The approval exists.'}])await assert.rejects(()=>runAnalysis(input,[source],coverage,async()=>result({title:'Bad reference',claims:[{id:'c1',text:'Approved.',citations:[citation]}],sections:[],missing_evidence:[]}),undefined,prepared),e=>['UNSUPPORTED_CITATION','INVALID_CITATION_REFERENCE'].includes(e.code));
});
test('actual three-PDF catalogue preserves all eight chunks inside the configured 5k input budget',async()=>{
 const sources=[];let documentNumber=0,chunkNumber=0;for(const [doc,file] of [['v1','circular-v1.pdf'],['v2','circular-v2.pdf'],['meeting','meeting-minutes.pdf']]){const pages=await extractPdfPages(new Uint8Array(await readFile(new URL('./fixtures/synthetic-civic/'+file,import.meta.url))));pages.forEach((text,index)=>chunkPageText(text).forEach((chunk,c)=>sources.push({...source,document_id:'00000000-0000-4000-8000-'+String(documentNumber+1).padStart(12,'0'),chunk_id:'11111111-1111-4111-8111-'+String(++chunkNumber).padStart(12,'0'),document_title:file,page_number:index+1,text:chunk.text,page_text:text,source_date:doc==='v1'?'2026-09-14':doc==='v2'?'2026-10-05':'2026-10-02',document_type:'circular'})));documentNumber++;}
 for(const kind of ['brief','gap']){const prepared=prepareReferencedAnalysis({project_id:'p',kind},sources,{...coverage,selected_document_count:3,included_document_count:3,total_chunk_count:8,included_chunk_count:8});const budget=estimateTokens(prepared.request.system+prepared.request.prompt+JSON.stringify(prepared.request.schema));assert.ok(budget<5000,`${kind} estimated input ${budget}`);assert.equal(prepared.catalogue.coverage.included_chunk_count,8);assert.equal(prepared.catalogue.coverage.included_document_count,3);assert.equal(prepared.catalogue.coverage.truncated,false);}
});
