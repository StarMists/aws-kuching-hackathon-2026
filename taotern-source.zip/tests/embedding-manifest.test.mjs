import test from 'node:test';
import assert from 'node:assert/strict';
import { EMBEDDING_MANIFEST_CHUNK_LIMIT, validateEmbeddingManifest } from '../lib/retrieval/embedding-manifest.ts';

const manifest = () => ({ schema_version: 1, project_id: 'project-a', model: 'gemini-embedding-2', fingerprint: 'c'.repeat(64), public_data_acknowledged: true, chunks: [{ chunk_id: 'chunk-a', document_id: 'doc-a', source_sha256: 'a'.repeat(64), version: '2' }], source_document_ids: ['doc-a'], scope_total_chunks: 3, scope_initial_indexed_chunks: 2, scope_remaining_at_creation: 1 });
test('semantic manifest retains exact source identities, hash, version and model', () => {
  const source = manifest();
  assert.equal(validateEmbeddingManifest(source), source);
  assert.equal(source.chunks[0].source_sha256, 'a'.repeat(64));
  assert.equal(source.model, 'gemini-embedding-2');
});
test('semantic manifest rejects missing consent, malformed hashes and foreign document references', () => {
  for (const source of [
    { ...manifest(), public_data_acknowledged: false },
    { ...manifest(), fingerprint: 'not-a-hash' },
    { ...manifest(), chunks: [{ ...manifest().chunks[0], source_sha256: 'changed' }] },
    { ...manifest(), chunks: [{ ...manifest().chunks[0], document_id: 'foreign' }] },
  ]) assert.throws(() => validateEmbeddingManifest(source), error => error.code === 'INVALID_INDEX_MANIFEST');
});
test('semantic manifest rejects duplicate chunks and inconsistent progress', () => {
  assert.throws(() => validateEmbeddingManifest({ ...manifest(), chunks: [manifest().chunks[0], manifest().chunks[0]] }), error => error.code === 'INVALID_INDEX_MANIFEST');
  assert.throws(() => validateEmbeddingManifest({ ...manifest(), scope_total_chunks: 10 }), error => error.code === 'INVALID_INDEX_MANIFEST');
  assert.throws(() => validateEmbeddingManifest({ ...manifest(), scope_remaining_at_creation: -1 }), error => error.code === 'INVALID_INDEX_MANIFEST');
});
test('semantic manifest capacity is explicit and bounded', () => {
  const chunks = Array.from({ length: EMBEDDING_MANIFEST_CHUNK_LIMIT + 1 }, (_, index) => ({ ...manifest().chunks[0], chunk_id: `chunk-${index}` }));
  assert.throws(() => validateEmbeddingManifest({ ...manifest(), chunks, scope_total_chunks: chunks.length, scope_initial_indexed_chunks: 0, scope_remaining_at_creation: chunks.length }), error => error.code === 'INVALID_INDEX_MANIFEST');
});
