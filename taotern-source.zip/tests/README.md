# Test boundaries

## Deterministic checks

- `node --test tests/fixture-integrity.test.mjs`: original fixture content and byte integrity.
- `node tests/package-audit.mjs .`: read-only source packaging inventory, exclusions, high-specificity credential indicators, and required recovery/provenance documentation. An indicator scan is not a certification that no secrets exist.
- Additional owner-supplied pure ranking, extraction, lifecycle, diff, graph and citation tests belong in this directory. A pure/mock test does not count as a live AI/OCR pass.

## Actual API integration

`node tests/run-worker-integration.mjs` starts and owns a real built local Worker, runs the API suite, restarts the Worker, verifies persisted envelopes/original R2 bytes, and stops it. Commands with isolated network namespaces must use this single-process-tree runner. Do not launch a second preview on its port5174.

The QA runner exercises the real Vinext Worker with D1/R2 through its local HTTP origin. It creates only clearly synthetic QA records and verifies owner/project boundaries, persistence, exact original bytes, lifecycle, source quote correspondence, and absent-provider behavior.

Run against an isolated local preview database. Test identity headers are local-preview inputs only; they must never be treated as production access credentials. The published Site uses platform authentication for owner-scoped workspace records; public audience does not make document or project APIs anonymous.

Live AI acceptance is opt-in after approved free provider keys are configured. Neither a no-key error nor a mocked response establishes reasoning/OCR correctness. The test report must state which checks were actually run, failed, blocked, or not run.

Latest observed results and exact source/restore limits are recorded in `../RECOVERY.md` and `../docs/ACCEPTANCE.md`. Hosted/live model results are separate from local no-key and mock checks.

## Native local D1 quota guard check

Run `node --loader ./tests/typescript-loader.mjs tests/run-local-d1-quota.mjs` after a build. This creates an isolated temporary ledger and loopback-only Worker on port5187, executes the exact prepared/bound quota statements through `env.DB`, checks native `meta.changes` and totals, then stops its Worker. It uses no provider keys or model calls and never mutates production or the app preview database. Do not overlap another preview on5187.

The configured test limits are150k shared/owner per UTC day,10k per visitor,20k combined visitor pool, two visitor reservations per minute (including retries), two active globally/one combined visitor active and45-second leases. The observed check passed32 asserted statements. This is actual local D1 engine evidence, not a second production-account or concurrent hosted-request test.

Separate provider/quota runtime mocks: `node --loader ./lib/intelligence/quota-runtime-loader.mjs --test lib/intelligence/quota-runtime.test.mjs`. The loader is test-only and must never be imported by the application or used for live quality claims.
