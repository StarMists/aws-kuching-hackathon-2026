import test from 'node:test';
import assert from 'node:assert/strict';
import { canonicalNoteQuote } from '../lib/retrieval/note-quotes.ts';

test('saved notes preserve exact original CRLF, tabs and Unicode whitespace', () => {
  const chunk = 'Approval:\r\nMira\tTan\u00a0must  sign\nby Friday.';
  const page = `Header\n${chunk}\nFooter`;
  const quote = canonicalNoteQuote(chunk, page, 'Mira Tan must sign by Friday.');
  assert.equal(quote, 'Mira\tTan\u00a0must  sign\nby Friday.');
  assert.ok(chunk.includes(quote)); assert.ok(page.includes(quote));
});

test('fullwidth and ligature character substitutions cannot become saved quotations', () => {
  const chunk = 'The code is ＡＢＣ and the printed word is oﬃce.';
  for (const candidate of ['ABC', 'office', 'The code is ABC']) assert.throws(() => canonicalNoteQuote(chunk, chunk, candidate), error => error.code === 'INVALID_CITATION_QUOTE');
  assert.equal(canonicalNoteQuote(chunk, chunk, 'ＡＢＣ'), 'ＡＢＣ');
  assert.equal(canonicalNoteQuote(chunk, chunk, 'oﬃce'), 'oﬃce');
});

test('saved quotes must occur literally in the corresponding stored page', () => {
  const chunk = 'The amount is 500.\r\nApproval remains pending.';
  assert.throws(() => canonicalNoteQuote(chunk, 'The amount is 500. Approval remains pending.', 'The amount is 500. Approval remains pending.'), error => error.code === 'INVALID_CITATION_QUOTE');
  assert.throws(() => canonicalNoteQuote(chunk, chunk, 'The amount is 900.'), error => error.code === 'INVALID_CITATION_QUOTE');
});

test('default excerpt stays an exact source slice without splitting a surrogate pair', () => {
  const chunk = 'A'.repeat(699) + '😀 details';
  const quote = canonicalNoteQuote(chunk, chunk, undefined);
  assert.equal(quote, 'A'.repeat(699));
  assert.ok(chunk.includes(quote));
  assert.throws(() => canonicalNoteQuote('  \n', '  \n', undefined), error => error.code === 'INVALID_CITATION_QUOTE');
  assert.throws(() => canonicalNoteQuote('source', 'source', 'x'.repeat(1501)), error => error.code === 'INVALID_CITATION_QUOTE');
});
