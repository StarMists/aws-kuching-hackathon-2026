import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFile,readdir} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {canonicalQuote} from '../lib/intelligence/evidence.ts';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const files=(await readdir(path.join(root,'drizzle'))).filter(v=>v.endsWith('.sql')).sort();
const sql=(await Promise.all(files.map(v=>readFile(path.join(root,'drizzle',v),'utf8')))).join('\n');
function setup(){
 const d=new DatabaseSync(':memory:');d.exec('PRAGMA foreign_keys=ON;');d.exec(sql);const stamp='2026-10-07T00:00:00Z';
 const raw='Action\tA-17:\r\n坡道112公分😀';
 for(const [id,text]of [['selected',raw],['unselected','Other owned synthetic source text']]){
  d.prepare('INSERT INTO documents(id,owner_id,title,filename,content_type,family_id,status,source_sha256,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)').run(id,'owner','Synthetic '+id,id+'.txt','text/plain',id,'ready','a'.repeat(64),stamp,stamp);
  d.prepare('INSERT INTO pages(id,document_id,page_number,text,markdown,created_at) VALUES(?,?,?,?,?,?)').run('page-'+id,id,1,text,text,stamp);
  d.prepare('INSERT INTO chunks(id,document_id,page_id,page_number,sequence,text,created_at) VALUES(?,?,?,?,?,?,?)').run('chunk-'+id,id,'page-'+id,1,0,text,stamp);
 }
 d.prepare('INSERT INTO chats(id,owner_id,title,created_at,updated_at) VALUES(?,?,?,?,?)').run('chat','owner','Synthetic chat',stamp,stamp);
 for(const [id,role,n]of [['user','user',1],['assistant','assistant',2]])d.prepare('INSERT INTO chat_messages(id,chat_id,role,sequence,created_at) VALUES(?,?,?,?,?)').run(id,'chat',role,n,stamp);
 d.prepare('INSERT INTO chat_jobs(id,owner_id,chat_id,request_message_id,response_message_id,request_text,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)').run('job','owner','chat','user','assistant','Synthetic question',stamp,stamp);
 d.prepare('INSERT INTO chat_job_sources(job_id,document_id,source_sha256) VALUES(?,?,?)').run('job','selected','a'.repeat(64));
 const insert=d.prepare('INSERT INTO chat_message_parts(id,message_id,sequence,type,text,citation_document_id,citation_page_number,citation_chunk_id,citation_quote) VALUES(?,?,?,?,?,?,?,?,?)');
 return {d,raw,insert};
}
test('canonical literal multiline/Mandarin/emoji quote passes actual D1 guard SQL',()=>{
 const {d,raw,insert}=setup();try{const quote=canonicalQuote(raw,'Action A-17: 坡道112公分😀',raw);assert.equal(quote,raw);insert.run('part','assistant',1,'citation','','selected',1,'chunk-selected',quote);assert.equal(d.prepare("SELECT citation_quote FROM chat_message_parts WHERE id='part'").get().citation_quote,raw);}finally{d.close();}
});
test('an owned but unselected source cannot be cited by the response job',()=>{
 const {d,insert}=setup();try{assert.throws(()=>insert.run('outside','assistant',1,'citation','','unselected',1,'chunk-unselected','Other owned synthetic source text'),/response job selected source/);assert.equal(d.prepare('SELECT COUNT(*) AS n FROM chat_message_parts').get().n,0);}finally{d.close();}
});
test('flattened or fabricated quotes and forged update fail while preserving valid source part',()=>{
 const {d,raw,insert}=setup();try{assert.throws(()=>insert.run('flat','assistant',1,'citation','','selected',1,'chunk-selected','Action A-17: 坡道112公分😀'),/literally in its chunk and page/);assert.throws(()=>insert.run('invented','assistant',1,'citation','','selected',1,'chunk-selected','Fabricated approval'),/literally in its chunk and page/);insert.run('valid','assistant',1,'citation','','selected',1,'chunk-selected',raw);assert.throws(()=>d.prepare("UPDATE chat_message_parts SET citation_quote='Fabricated approval' WHERE id='valid'").run(),/literally in its chunk and page/);assert.equal(d.prepare("SELECT citation_quote FROM chat_message_parts WHERE id='valid'").get().citation_quote,raw);}finally{d.close();}
});
