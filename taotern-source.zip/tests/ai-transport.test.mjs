import test from 'node:test';
import assert from 'node:assert/strict';
import {readAIConfig} from '../lib/ai/config.ts';
import {generateWithConfig} from '../lib/ai/providers.ts';
const request={system:'Transcribe only the synthetic source.',prompt:'Synthetic test input.',public_data_acknowledged:true};
const config=extra=>readAIConfig({AI_ENABLED:'true',GEMINI_API_KEY:'test-placeholder-not-real',AI_MAX_RETRIES:'0',GEMINI_API_MODE:'auto',...extra});
const ok=()=>Response.json({candidates:[{finishReason:'STOP',content:{role:'model',parts:[{thought:true,text:'private thought must be excluded'},{text:'SYNTHETIC VISIBLE RESULT'},{functionCall:{name:'untrusted_tool'}}]}}],modelVersion:'gemini-3.8-flash',responseId:'synthetic-mock-receipt',usageMetadata:{promptTokenCount:9,candidatesTokenCount:3,thoughtsTokenCount:2,totalTokenCount:14}});
test('MOCK ONLY: transient interactions503 switches to same-provider generateContent',async()=>{
 const calls=[];
 const result=await generateWithConfig(request,config({}),async(url,init)=>{calls.push({url,body:JSON.parse(init.body),headers:init.headers});return calls.length===1?Response.json({error:{code:'service_unavailable',message:'upstream echo excluded'}},{status:503}):ok();});
 assert.equal(calls.length,2);assert.match(calls[0].url,/interactions$/);assert.match(calls[1].url,/generateContent$/);assert.equal(result.provider,'gemini');assert.equal(result.api_transport,'gemini-generate-content');assert.equal(result.attempts,2);assert.equal(result.text,'SYNTHETIC VISIBLE RESULT');assert.equal(result.usage.thought_tokens,2);assert.equal(result.usage.total_tokens,14);assert.equal(result.request_id,'synthetic-mock-receipt');assert.deepEqual(result.failed_attempts,[{provider:'gemini',model:'gemini-3.8-flash',code:'AI_PROVIDER_UNAVAILABLE',api_transport:'gemini-interactions'}]);
});
test('MOCK ONLY: auth, rate-limit and daily quota never probe an alternate Gemini transport',async()=>{
 for(const [status,body,code]of [[401,{error:{}},'AI_CREDENTIALS_REJECTED'],[429,{error:{code:'rate_limit_exceeded'}},'AI_RATE_LIMIT'],[429,{error:{code:'quota_exceeded'}},'AI_DAILY_PROVIDER_QUOTA']]){
  const calls=[];await assert.rejects(()=>generateWithConfig(request,config({}),async url=>{calls.push(url);return Response.json(body,{status});}),e=>e.code===code);assert.equal(calls.length,1);assert.match(calls[0],/interactions$/);
 }
});
test('MOCK ONLY: forced generateContent uses actual schema/text/vision payload and filters thoughts',async()=>{
 const schema={type:'object',properties:{text:{type:'string'}},required:['text']};let actual;
 const result=await generateWithConfig({...request,schema,image:{mime_type:'image/jpeg',base64:'eA=='}},config({GEMINI_API_MODE:'generate-content'}),async(url,init)=>{actual={url,body:JSON.parse(init.body)};return ok();});
 assert.match(actual.url,/models\/gemini-3.8-flash:generateContent$/);assert.equal(actual.body.systemInstruction.parts[0].text,request.system);assert.equal(actual.body.contents[0].role,'user');assert.equal(actual.body.contents[0].parts[0].text,request.prompt);assert.deepEqual(actual.body.contents[0].parts[1],{inlineData:{mimeType:'image/jpeg',data:'eA=='}});assert.deepEqual(actual.body.generationConfig.responseFormat.text.schema,schema);assert.equal(actual.body.generationConfig.responseFormat.text.mimeType,'APPLICATION_JSON');assert.equal(actual.body.generationConfig.thinkingConfig.thinkingLevel,'LOW');assert.equal(result.attempts,1);assert.equal(result.text,'SYNTHETIC VISIBLE RESULT');
});
test('invalid API transport setting is rejected before a model call',()=>{
 assert.throws(()=>config({GEMINI_API_MODE:'unrecognized-mode'}),e=>e.code==='AI_API_MODE_UNSUPPORTED');
});
test('default Gemini mode is the verified generateContent transport with a22-second bound',()=>{
 const active=readAIConfig({AI_ENABLED:'true',GEMINI_API_KEY:'test-placeholder-not-real'});assert.equal(active.primary.api_mode,'generate-content');assert.equal(active.timeout_ms,22000);
});
