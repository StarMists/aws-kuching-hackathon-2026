import test from 'node:test';
import assert from 'node:assert/strict';
import {sanitizedProviderError,boundedErrorPayload} from '../lib/ai/errors.ts';
const privateEcho='synthetic-credential-and-prompt-echo-must-never-appear';
test('generic HTTP400 diagnoses request format, not automatically an invalid key',()=>{
 const error=sanitizedProviderError({error:{message:privateEcho}},400,'Gemini');assert.equal(error.code,'AI_INVALID_REQUEST');assert.ok(!error.message.includes(privateEcho));assert.equal(error.retryable,false);
});
test('machine API_KEY_INVALID identifies credential rejection without echoing metadata',()=>{
 const error=sanitizedProviderError({error:{message:privateEcho,details:[{'@type':'type.googleapis.com/google.rpc.ErrorInfo',domain:'googleapis.com',reason:'API_KEY_INVALID',metadata:{secret:privateEcho}}]}},400,'Gemini');assert.equal(error.code,'AI_CREDENTIALS_REJECTED');assert.match(error.message,/API_KEY_INVALID/);assert.ok(!error.message.includes(privateEcho));
});
test('unsupported parameter, blocked service and quota are distinct actionable failures',()=>{
 assert.equal(sanitizedProviderError({error:{code:'parameter_unknown',message:privateEcho}},400,'Gemini').code,'AI_UNSUPPORTED_PARAMETER');
 assert.equal(sanitizedProviderError({error:{details:[{'@type':'type.googleapis.com/google.rpc.ErrorInfo',domain:'googleapis.com',reason:'API_KEY_SERVICE_BLOCKED'}]}},400,'Gemini').code,'AI_ACCESS_DENIED');
 const limited=sanitizedProviderError({error:{code:'rate_limit_exceeded'}},429,'Gemini',5000);assert.equal(limited.code,'AI_RATE_LIMIT');assert.equal(limited.retryable,true);assert.equal(limited.retry_after_ms,5000);
 const payment=sanitizedProviderError({error:{code:'payment_required'}},402,'Gemini');assert.equal(payment.code,'AI_PAYMENT_REQUIRED');assert.equal(payment.retryable,false);
});
test('prototype keys never become allowlisted diagnoses',()=>{
 for(const key of ['__proto__','constructor','toString']){const error=sanitizedProviderError({error:{code:key,message:privateEcho}},400,'Gemini');assert.equal(error.code,'AI_INVALID_REQUEST');assert.ok(!error.message.includes(privateEcho));}
});
test('upstream error bodies are capped and malformed data fails safely',async()=>{
 assert.equal(await boundedErrorPayload(new Response('x'.repeat(70000))),null);
 assert.equal(await boundedErrorPayload(new Response('malformed')),null);
 assert.equal(await boundedErrorPayload(new Response('{}',{headers:{'content-length':'70000'}})),null);
 assert.deepEqual(await boundedErrorPayload(Response.json({error:{code:'parameter_unknown'}})),{error:{code:'parameter_unknown'}});
});
