import test from 'node:test';import assert from 'node:assert/strict';
import {withPageSupport,pageSupportWarning} from '../lib/intelligence/page-coverage.ts';
import {buildQuoteCatalogue,validateReferenceClaims} from '../lib/intelligence/quote-references.ts';
const coverage={selected_document_count:1,included_document_count:1,total_chunk_count:8,included_chunk_count:8,truncated:false,excluded_document_ids:[]};
const document={id:'d',title:'Synthetic mixed PDF',page_count:3,extraction_method:'partial_native_text'};
const pages=[{document_id:'d',page_number:1,text:'A supported native statement.',extraction_method:'pdf_text',extraction_metadata_json:'{"native_text_only":true,"supported":true}'},{document_id:'d',page_number:2,text:'Damaged formula text retained for preview only.',extraction_method:'unsupported',extraction_metadata_json:'{"supported":false,"support_status":"not_supported","reason_code":"damaged_text_layer"}'},{document_id:'d',page_number:3,text:'',extraction_method:'pdf_text',extraction_metadata_json:'{"supported":true,"reason":"blank_page"}'}];
test('all retained chunks can fit while PDF page coverage remains explicitly partial',()=>{
 const result=withPageSupport(coverage,[document],pages);assert.equal(result.included_chunk_count,8);assert.equal(result.total_chunk_count,8);assert.equal(result.truncated,true);assert.equal(result.total_page_count,3);assert.equal(result.supported_page_count,2);assert.deepEqual(result.unsupported_pages,[{document_id:'d',document_title:document.title,page_number:2,reason_code:'damaged_text_layer'}]);assert.match(pageSupportWarning(result),/NOT SUPPORTED: Synthetic mixed PDF, page 2/);assert.match(pageSupportWarning(result),/missing text cannot establish that a fact is false/);
});
test('fully supported native/blank pages preserve the existing coverage shape',()=>{
 const native=pages.filter(p=>p.page_number!==2).map((p,i)=>({...p,page_number:i+1}));assert.equal(withPageSupport(coverage,[{...document,page_count:2,extraction_method:'pdf_text'}],native),coverage);assert.equal(pageSupportWarning(coverage),null);
});
test('missing retained page in a declared partial document is disclosed without invented text',()=>{
 const result=withPageSupport(coverage,[{...document,page_count:2}],[pages[0],{...pages[1],document_id:'foreign'}]);assert.equal(result.unsupported_pages[0].page_number,2);assert.equal(result.unsupported_pages[0].reason_code,'page_evidence_unavailable');assert.equal(result.supported_page_count,1);
});
test('partial-page warnings leave exact native citation/hash validation intact',async()=>{
 const result=withPageSupport(coverage,[document],pages),source={chunk_id:'c',document_id:'d',document_title:document.title,page_number:1,text:pages[0].text,page_text:pages[0].text,score:1,source_sha256:'a'.repeat(64)};
 const catalogue=buildQuoteCatalogue([source],result),claims=await validateReferenceClaims([{id:'c1',text:'The native source records a statement.',citations:[{reference_id:'r1'}]}],[source],catalogue);
 assert.equal(catalogue.coverage.truncated,true);assert.equal(claims[0].evidence[0].quote,pages[0].text);assert.equal(claims[0].evidence[0].source_sha256,source.source_sha256);assert.equal(claims[0].evidence[0].page_number,1);
});
