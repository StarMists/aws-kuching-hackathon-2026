import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizeUnambiguousDate,quotedSourceDates,dateSupportedByQuote} from '../lib/intelligence/dates.ts';
test('full ISO, English month and Mandarin calendar dates normalize to the exact day',()=>{
 for(const [input,expected]of [['2026-11-19','2026-11-19'],['2026-1-2','2026-01-02'],['19 November 2026','2026-11-19'],['November 19, 2026','2026-11-19'],['2nd Oct. 2026','2026-10-02'],['2026年11月19日','2026-11-19'],['2026 年 10 月 2 号','2026-10-02'],['29 February 2024','2024-02-29']])assert.equal(normalizeUnambiguousDate(input),expected,input);
});
test('rollovers, invalid leap days, missing years and ambiguous/relative values stay unspecified',()=>{
 for(const input of ['2026-02-29','2026-02-30','31 April 2026','2026-13-01','2026-00-01','2026-01-00','11/12/2026','12 November','next Friday','tomorrow','12-19 November 2026','not a date',null,undefined])assert.equal(normalizeUnambiguousDate(input),null,String(input));
});
test('only complete valid quoted source dates can support a finding',()=>{
 const quote='Issued19 November2026 is not space-separated. Valid event: 19 November 2026. 中文期限：2026年10月30日。 Invalid: 30 February 2026; unknown year: 12 November.';
 assert.deepEqual(new Set(quotedSourceDates(quote)),new Set(['2026-11-19','2026-10-30']));assert.equal(dateSupportedByQuote('2026-11-19',quote),true);assert.equal(dateSupportedByQuote('2026-11-12',quote),false);assert.equal(dateSupportedByQuote('next Friday',quote),false);
});
