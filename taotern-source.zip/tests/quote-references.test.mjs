import test from 'node:test';
import assert from 'node:assert/strict';
import {buildQuoteCatalogue,referenceClaimSchema,validateReferenceClaims} from '../lib/intelligence/quote-references.ts';
const text='Decision\tA-17:\r\nMira Tan must submit the report.\n坡道\u00a0寬度112公分。\n檢查員😀\u2003Jo Chan confirmed the measurement.';
const source={chunk_id:'chunk-a',document_id:'doc-a',document_title:'Synthetic source',page_number:2,text,page_text:'Header\n'+text+'\nFooter',score:1,source_sha256:'a'.repeat(64),version:'2',source_date:'2026-10-05',document_type:'circular'};
const coverage={selected_document_count:1,included_document_count:1,total_chunk_count:1,included_chunk_count:1,truncated:false,excluded_document_ids:[]};
const claim=id=>[{id:'c1',text:'The source records a reporting action.',citations:[{reference_id:id}]}];
test('source IDs reconstruct exact multiline and Unicode quotes with stable final identity',async()=>{
 const catalogue=buildQuoteCatalogue([source],coverage);assert.ok(catalogue.references.length>=3);
 for(const ref of catalogue.references){const result=await validateReferenceClaims(claim(ref.reference_id),[source],catalogue,8);const citation=result[0].evidence[0];assert.equal(citation.quote,ref.quote);assert.ok(source.text.includes(citation.quote));assert.ok(source.page_text.includes(citation.quote));assert.match(citation.quote_id,/^q_[0-9a-f]{24}$/);assert.equal(citation.document_id,'doc-a');assert.equal(citation.page_number,2);}
 assert.ok(catalogue.references.some(r=>r.quote.includes('\t')&&r.quote.includes('\r\n')));assert.ok(catalogue.references.some(r=>r.quote.includes('😀')&&r.quote.includes('\u2003')));
 assert.deepEqual(referenceClaimSchema(catalogue,8).items.properties.citations.items.properties.reference_id.enum,catalogue.references.map(r=>r.reference_id));
});
test('unknown references and model-supplied quote overrides fail closed',async()=>{
 const catalogue=buildQuoteCatalogue([source],coverage);
 await assert.rejects(()=>validateReferenceClaims(claim('r999'),[source],catalogue),e=>e.code==='UNSUPPORTED_CITATION');
 const override=claim('r1');override[0].citations[0].quote='fabricated';await assert.rejects(()=>validateReferenceClaims(override,[source],catalogue),e=>e.code==='INVALID_CITATION_REFERENCE');
});
test('reference cannot escape selected document, source hash or page',async()=>{
 const catalogue=buildQuoteCatalogue([source],coverage);
 for(const replacement of [{...source,document_id:'foreign'},{...source,source_sha256:'b'.repeat(64)},{...source,page_number:3}])await assert.rejects(()=>validateReferenceClaims(claim('r1'),[replacement],catalogue),e=>e.code==='UNSUPPORTED_CITATION');
 await assert.rejects(()=>validateReferenceClaims(claim('r1'),[],catalogue),e=>e.code==='UNSUPPORTED_CITATION');
});
test('selected ID still revalidates exact current chunk and raw page',async()=>{
 const catalogue=buildQuoteCatalogue([source],coverage);
 await assert.rejects(()=>validateReferenceClaims(claim('r1'),[{...source,page_text:'Another page'}],catalogue),e=>e.code==='UNSUPPORTED_CITATION');
 await assert.rejects(()=>validateReferenceClaims(claim('r1'),[{...source,text:'Another chunk'}],catalogue),e=>e.code==='UNSUPPORTED_CITATION');
});
test('unquotable page/character mismatch is excluded and coverage disclosed',()=>{
 const mismatch={...source,text:'Synthetic Ａ-17.',page_text:'Synthetic A-17.'};const catalogue=buildQuoteCatalogue([mismatch],coverage);
 assert.equal(catalogue.references.length,0);assert.equal(catalogue.coverage.included_chunk_count,0);assert.equal(catalogue.coverage.truncated,true);assert.deepEqual(catalogue.coverage.excluded_document_ids,['doc-a']);
});
