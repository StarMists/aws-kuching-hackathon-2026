import test from 'node:test';
import assert from 'node:assert/strict';
import { ApiError, apiError } from '../lib/http.ts';
import { AIError } from '../lib/ai/types.ts';

test('API429 Retry-After is ceiled and clamped1–86400 seconds', () => {
 for (const [seconds, expected] of [[0.01,'1'],[1.01,'2'],[65,'65'],[86400.1,'86400'],[1e9,'86400']]) {
  const result=apiError(new ApiError(429,'LIMIT','Bounded limit',{retry_after_seconds:seconds}));
  assert.equal(result.status,429);assert.equal(result.headers.get('Retry-After'),expected);assert.equal(result.headers.get('Cache-Control'),'no-store');
 }
});
test('AI429 Retry-After converts milliseconds before ceil/clamp', () => {
 for (const [ms, expected] of [[1,'1'],[1001,'2'],[65000,'65'],[1e9,'86400']]) assert.equal(apiError(new AIError('AI_RATE_LIMIT','Wait',429,true,ms)).headers.get('Retry-After'),expected);
});
test('nonpositive/nonfinite/missing Retry-After values are omitted', () => {
 for (const seconds of [undefined,null,0,-1,NaN,Infinity,-Infinity,'65']) assert.equal(apiError(new ApiError(429,'LIMIT','Wait',{retry_after_seconds:seconds})).headers.get('Retry-After'),null);
 for (const ms of [null,0,-1,NaN,Infinity,-Infinity]) assert.equal(apiError(new AIError('AI_RATE_LIMIT','Wait',429,true,ms)).headers.get('Retry-After'),null);
});
test('non429 errors never advertise Retry-After', async () => {
 for (const status of [400,403,409,503]) {
  const api=apiError(new ApiError(status,'LIMIT','Wait',{retry_after_seconds:65}));assert.equal(api.headers.get('Retry-After'),null);assert.equal((await api.json()).error.code,'LIMIT');
  assert.equal(apiError(new AIError('AI_PROVIDER_ERROR','Wait',status,true,65000)).headers.get('Retry-After'),null);
 }
});
