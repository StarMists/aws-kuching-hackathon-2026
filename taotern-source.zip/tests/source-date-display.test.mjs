import test from 'node:test';
import assert from 'node:assert/strict';
import {displayDate} from '../components/aitlau/api.ts';
test('calendar source dates never shift a day across browser/user timezones',()=>{
 const old=process.env.TZ;
 try{for(const timezone of ['America/Los_Angeles','Asia/Kuala_Lumpur','UTC']){process.env.TZ=timezone;assert.equal(displayDate('2026-09-14',true),'Sep 14, 2026',timezone);}}
 finally{if(old===undefined)delete process.env.TZ;else process.env.TZ=old;}
});
test('invalid or ambiguous source dates remain literal instead of becoming inferred dates',()=>{
 assert.equal(displayDate('2026-02-31',true),'2026-02-31');assert.equal(displayDate('10/11/2026',true),'10/11/2026');assert.equal(displayDate(null,true),'Date not recorded');
});
