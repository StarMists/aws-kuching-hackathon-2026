import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {extractNativePdfPages} from './pdf';
import {describeIngestionSupport,inspectNativeText} from './native-support';
import type {IngestionPage} from './limits';
test('short titles, CJK and mathematical native text do not need a density threshold',()=>{
 for(const text of ['A','原生文字。','x² + √y = 7','∑ ≥ ∞'])assert.equal(inspectNativeText(text).usable,true,text);
 assert.equal(inspectNativeText(' \n\t').usable,false);assert.equal(inspectNativeText('\uFFFD'.repeat(10)).usable,false);
});
test('partial native support lists exact unavailable pages and prohibits extraction retry',()=>{
 const pages:IngestionPage[]=[{page_number:1,text:'Math',markdown:'Math',extraction_method:'pdf_text'},{page_number:2,text:'',markdown:'',extraction_method:'pdf_text',extraction_metadata:{reason:'blank_page'}},{page_number:3,text:'',markdown:'',extraction_method:'unsupported'}];
 const support=describeIngestionSupport(pages);assert.equal(support.status,'partial');assert.deepEqual(support.native_pages,[1]);assert.deepEqual(support.blank_pages,[2]);assert.deepEqual(support.unsupported_pages,[3]);assert.equal(support.retry_allowed,false);assert.match(support.message||'',/NOT SUPPORTED.*partial.*3/);
 assert.equal(describeIngestionSupport([{page_number:1,text:'',markdown:'',extraction_method:'unsupported'}]).status,'not_supported');
 assert.equal(describeIngestionSupport([{page_number:1,text:'',markdown:'',extraction_method:'pdf_text'}]).status,'not_supported');
});
test('real sparse/math/blank/scanned PDF is triaged per page without a model call',async()=>{
 const pages=await extractNativePdfPages(new Uint8Array(await readFile(new URL('../../tests/fixtures/synthetic-civic/native-sparse-blank-scan.pdf',import.meta.url))));
 assert.equal(pages.length,4);assert.equal(pages[0].text.trim(),'Math');assert.equal(pages[0].supported,true);assert.match(pages[1].text,/√/);assert.equal(pages[1].supported,true);assert.equal(pages[2].reason,'blank_page');assert.equal(pages[2].supported,true);assert.equal(pages[3].supported,false);assert.equal(pages[3].reason,'no_extractable_text');
});
test('real mixed PDF retains usable pages and flags only image-only pages2/5',async()=>{
 const pages=await extractNativePdfPages(new Uint8Array(await readFile(new URL('../../tests/fixtures/synthetic-civic/mixed-native-scan.pdf',import.meta.url))));assert.deepEqual(pages.filter(page=>!page.supported).map(page=>page.page_number),[2,5]);assert.deepEqual(pages.filter(page=>page.supported).map(page=>page.page_number),[1,3,4]);
});
