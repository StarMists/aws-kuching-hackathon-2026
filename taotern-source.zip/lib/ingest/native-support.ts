import type { IngestionPage } from './limits';
export interface NativeTextInspection {usable:boolean;nonblank_characters:number;readable_characters:number;damaged_characters:number;}
/** Short titles, CJK and mathematical symbols are genuine native text, with no density cutoff. */
export function inspectNativeText(text:string):NativeTextInspection {
 const characters=Array.from(text).filter(character=>!(/\s/u.test(character)));
 const damaged=characters.filter(character=>/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFD\uE000-\uF8FF]/u.test(character)).length;
 const readable=characters.filter(character=>/[\p{L}\p{N}\p{P}\p{S}]/u.test(character)&&!/[\uFFFD\uE000-\uF8FF]/u.test(character)).length;
 return {usable:readable>0&&!(damaged>=2&&damaged/Math.max(1,characters.length)>=0.05),nonblank_characters:characters.length,readable_characters:readable,damaged_characters:damaged};
}
export interface IngestionSupport {status:'supported'|'not_supported'|'partial';native_pages:number[];blank_pages:number[];unsupported_pages:number[];total_pages:number;message:string|null;retry_allowed:boolean;}
export const EXTERNAL_TEXT_ADVICE='Use an external OCR/conversion tool, then upload a searchable PDF, TXT, or Markdown file. The original file is retained.';
export function describeIngestionSupport(pages:IngestionPage[]):IngestionSupport {
 const native=pages.filter(page=>page.extraction_method!=='unsupported'&&page.extraction_method!=='vision_ocr'&&inspectNativeText(page.text).usable).map(page=>page.page_number);
 const blank=pages.filter(page=>page.extraction_method!=='unsupported'&&page.extraction_method!=='vision_ocr'&&!page.text.trim()).map(page=>page.page_number);
 const unsupported=pages.filter(page=>page.extraction_method==='unsupported'||page.extraction_method==='vision_ocr').map(page=>page.page_number);
 const status=native.length===0?'not_supported':unsupported.length?'partial':'supported';
 const message=status==='supported'?null:status==='partial'?`NOT SUPPORTED: Native-text coverage is partial. Pages ${unsupported.join(', ')} have no usable native text. ${EXTERNAL_TEXT_ADVICE}`:`NOT SUPPORTED: This source has no usable native text. ${EXTERNAL_TEXT_ADVICE}`;
 return {status,native_pages:native,blank_pages:blank,unsupported_pages:unsupported,total_pages:pages.length,message,retry_allowed:status==='supported'};
}
export function supportFromRequest(value:unknown):IngestionSupport|null {
 if(typeof value!=='string')return null;
 try{const data=JSON.parse(value);const support=data?.ingestion_support;return support&&['supported','not_supported','partial'].includes(support.status)?support as IngestionSupport:null;}catch{return null;}
}
