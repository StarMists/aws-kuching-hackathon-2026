/** Deterministic page triage, shared by server parsing and browser scan preparation. */
export interface PdfTextQuality { nonblank_characters:number; readable_characters:number; damaged_characters:number; encoding_damaged:boolean; needs_raster_check:boolean; }
export interface PdfPageDecision { method:'pdf_text'|'vision_ocr'; reason:'usable_native_text'|'blank_native_page'|'image_only_scan'|'sparse_text_on_scan'|'damaged_scan_layer'|'unreadable_native_layer'; text_quality:PdfTextQuality; raster_coverage:number|null; extraction_error?:string; }
export function inspectPdfText(text:string):PdfTextQuality {
  const characters=Array.from(text).filter(character=>!character.match(/\s/u));
  const damaged=characters.filter(character=>/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFD\uE000-\uF8FF]/u.test(character)).length;
  const readable=characters.filter(character=>/[\p{L}\p{N}]/u.test(character)).length;
  const encodingDamaged=damaged>=2&&damaged/Math.max(1,characters.length)>=0.05;
  return {nonblank_characters:characters.length,readable_characters:readable,damaged_characters:damaged,encoding_damaged:encodingDamaged,needs_raster_check:encodingDamaged||characters.length<80};
}
export function classifyPdfPage(text:string,rasterCoverage:number|null):PdfPageDecision {
  const quality=inspectPdfText(text);const coverage=rasterCoverage===null?null:Math.max(0,Math.min(1,rasterCoverage));
  if(quality.encoding_damaged) {
    if((coverage||0)>=0.2)return {method:'vision_ocr',reason:'damaged_scan_layer',text_quality:quality,raster_coverage:coverage};
    return {method:'pdf_text',reason:'unreadable_native_layer',text_quality:quality,raster_coverage:coverage,extraction_error:'This native PDF text layer contains damaged character mappings. Export the source again with embedded fonts or upload corrected text as a new version.'};
  }
  if(quality.nonblank_characters===0)return {method:(coverage||0)>0?'vision_ocr':'pdf_text',reason:(coverage||0)>0?'image_only_scan':'blank_native_page',text_quality:quality,raster_coverage:coverage};
  // A short native notice/cover page remains native. Sparse text over a page-sized raster is a scan overlay.
  if(quality.nonblank_characters<80&&(coverage||0)>=0.45)return {method:'vision_ocr',reason:'sparse_text_on_scan',text_quality:quality,raster_coverage:coverage};
  return {method:'pdf_text',reason:'usable_native_text',text_quality:quality,raster_coverage:coverage};
}
interface OperatorList {fnArray:ArrayLike<number>;argsArray:ArrayLike<unknown>}
type Matrix=[number,number,number,number,number,number];
function multiply(left:Matrix,right:Matrix):Matrix {return [left[0]*right[0]+left[2]*right[1],left[1]*right[0]+left[3]*right[1],left[0]*right[2]+left[2]*right[3],left[1]*right[2]+left[3]*right[3],left[0]*right[4]+left[2]*right[5]+left[4],left[1]*right[4]+left[3]*right[5]+left[5]];}
/** Approximate rendered raster area from actual PDF drawing transforms; no text-density guesses across the entire document. */
export function pdfRasterCoverage(list:OperatorList,ops:Record<string,number>,pageArea:number):number {
  const stack:Matrix[]=[];let matrix:Matrix=[1,0,0,1,0,0],area=0;
  const imageOps=new Set([ops.paintImageXObject,ops.paintInlineImageXObject,ops.paintImageMaskXObject,ops.paintSolidColorImageMask].filter(value=>typeof value==='number'));
  const repeatOps=new Set([ops.paintImageXObjectRepeat,ops.paintImageMaskXObjectRepeat].filter(value=>typeof value==='number'));
  for(let index=0;index<list.fnArray.length;index++) {
    const operation=list.fnArray[index];const args=list.argsArray[index];
    if(operation===ops.save)stack.push([...matrix]);
    else if(operation===ops.restore)matrix=stack.pop()||[1,0,0,1,0,0];
    else if(operation===ops.transform&&Array.isArray(args)&&args.length===6&&args.every(value=>typeof value==='number'&&Number.isFinite(value)))matrix=multiply(matrix,args as Matrix);
    else if(imageOps.has(operation))area+=Math.abs(matrix[0]*matrix[3]-matrix[1]*matrix[2]);
    else if(repeatOps.has(operation)&&Array.isArray(args)&&typeof args[1]==='number'&&typeof args[2]==='number') {
      const positions=args[3] as {length?:number}|undefined;area+=Math.abs(matrix[0]*matrix[3]-matrix[1]*matrix[2])*Math.abs(args[1]*args[2])*Math.max(1,(positions?.length||2)/2);
    }
  }
  return Math.max(0,Math.min(1,area/Math.max(1,pageArea)));
}
