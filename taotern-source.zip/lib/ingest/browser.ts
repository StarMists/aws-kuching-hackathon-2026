'use client';
import { INGEST_LIMITS, type UploadMetadata } from './limits';

export interface PrepareUploadOptions { onProgress?: (message: string) => void; signal?: AbortSignal }
/** Preserve exact original bytes. Native extraction and support classification are server-side. */
export async function prepareDocumentUpload(file: File, metadata: UploadMetadata = {}, options: PrepareUploadOptions = {}): Promise<FormData> {
  if (options.signal?.aborted) throw new DOMException('Upload was cancelled.', 'AbortError');
  if (!file.size) throw new Error('Choose a file with readable content.');
  if (file.size > INGEST_LIMITS.max_upload_bytes) throw new Error('Source files must be 20 MB or smaller.');
  const types = ['application/pdf', 'text/plain', 'text/markdown', 'image/png', 'image/jpeg', 'image/webp'];
  if (!types.includes(file.type) && !/\.(pdf|txt|md|markdown|png|jpe?g|webp)$/i.test(file.name)) throw new Error('NOT SUPPORTED: Choose a PDF, TXT, Markdown, PNG, JPEG, or WebP source.');
  options.onProgress?.('Preserving the original source…');
  const form = new FormData(); form.set('file', file);
  for (const [key, value] of Object.entries(metadata)) if (value !== undefined && value !== null && value !== '') form.set(key, String(value));
  return form;
}
