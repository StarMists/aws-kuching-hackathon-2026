import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { readAIConfig } from '../ai/config';
import { visionWithConfig } from '../ai/vision';
import { bytesToBase64 } from './images';

// MOCK transport only. This checks serialization and response validation, never real OCR accuracy.
test('MOCK ONLY: photo OCR serializes real source bytes and uses the REST JSON MIME enum or legacy JSON field',async()=>{
  const bytes=new Uint8Array(await readFile(new URL('../../tests/fixtures/synthetic-civic/field-slip-photo.jpg',import.meta.url)));
  const base64=bytesToBase64(bytes);
  const config=readAIConfig({AI_ENABLED:'true',GEMINI_API_KEY:'mock-placeholder-not-a-real-key',GEMINI_API_MODE:'generate-content',AI_MAX_RETRIES:'0'});
  let calls=0;
  const result=await visionWithConfig({base64,mime_type:'image/jpeg',page_number:1,public_data_acknowledged:true},config,async(url,options)=>{
    calls++;
    assert.match(String(url),/models\/gemini-3\.8-flash:generateContent$/);
    const body=JSON.parse(String(options?.body));
    assert.deepEqual(new Uint8Array(Buffer.from(body.contents[0].parts.find((part:Record<string,unknown>)=>'inlineData'in part).inlineData.data,'base64')),bytes);
    const generation=body.generationConfig;
    const native=generation.responseFormat?.text;
    const legacy=generation.responseMimeType==='application/json'&&generation.responseJsonSchema;
    if(native?.mimeType!=='APPLICATION_JSON'&&!legacy)return Response.json({error:{code:400,status:'INVALID_ARGUMENT'}},{status:400});
    const schema=native?.schema||generation.responseJsonSchema;
    assert.deepEqual(schema.required,['text','markdown','illegible_regions']);
    assert.equal(schema.properties.illegible_regions.items.type,'string');
    return Response.json({candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify({text:'MOCK ONLY: serialization test.',markdown:'MOCK ONLY: serialization test.',illegible_regions:[]})}]}}],modelVersion:'gemini-3.8-flash',usageMetadata:{promptTokenCount:100,candidatesTokenCount:20,totalTokenCount:120}});
  });
  assert.equal(calls,1);assert.equal(result.text,'MOCK ONLY: serialization test.');assert.equal(result.provider,'gemini');assert.equal(result.api_transport,'gemini-generate-content');
});

test('MOCK ONLY: Groq OCR uses the approved Qwen vision model and preserves the same photo bytes and schema',async()=>{
  const bytes=new Uint8Array(await readFile(new URL('../../tests/fixtures/synthetic-civic/field-slip-photo.jpg',import.meta.url)));
  const config=readAIConfig({AI_ENABLED:'true',AI_PROVIDER:'groq',GROQ_API_KEY:'mock-placeholder-not-a-real-key',GROQ_MODEL:'openai/gpt-oss-120b',GROQ_VISION_MODEL:'qwen/qwen3.8-27b',GEMINI_API_KEY:'mock-fallback-not-a-real-key',AI_MAX_RETRIES:'0'});
  let calls=0;
  const result=await visionWithConfig({base64:bytesToBase64(bytes),mime_type:'image/jpeg',page_number:1,public_data_acknowledged:true},config,async(url,options)=>{
    calls++;assert.equal(String(url),'https://api.groq.com/openai/v1/chat/completions');
    const body=JSON.parse(String(options?.body));assert.equal(body.model,'qwen/qwen3.8-27b');assert.equal(body.messages[0].role,'system');
    const content=body.messages[1].content;const dataUrl=content.find((part:Record<string,unknown>)=>part.type==='image_url').image_url.url;
    assert.match(dataUrl,/^data:image\/jpeg;base64,/);assert.deepEqual(new Uint8Array(Buffer.from(dataUrl.split(',')[1],'base64')),bytes);
    assert.equal(body.response_format.type,'json_schema');assert.equal(body.response_format.json_schema.strict,true);assert.deepEqual(body.response_format.json_schema.schema.required,['text','markdown','illegible_regions']);
    assert.ok(['low','none'].includes(body.reasoning_effort));assert.equal(body.stream,false);
    return Response.json({choices:[{finish_reason:'stop',message:{content:JSON.stringify({text:'MOCK ONLY: Groq wire validation.',markdown:'MOCK ONLY: Groq wire validation.',illegible_regions:[]}),reasoning:'MOCK hidden reasoning, excluded.'}}],model:'qwen/qwen3.8-27b',id:'mock-groq-vision-receipt',usage:{prompt_tokens:2048,completion_tokens:120,total_tokens:2168}});
  });
  assert.equal(calls,1);assert.equal(result.provider,'groq');assert.equal(result.model,'qwen/qwen3.8-27b');assert.equal(result.api_transport,'groq-chat-completions');assert.equal(result.text,'MOCK ONLY: Groq wire validation.');assert.equal(result.text.includes('hidden reasoning'),false);
});
