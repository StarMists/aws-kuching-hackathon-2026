import { ApiError } from '../http';
import { INGEST_LIMITS } from './limits';
import { BundledPdfBinaryDataFactory } from './pdf-cmaps';
import { inspectNativeText } from './native-support';
export interface NativePdfPage {page_number:number;text:string;supported:boolean;reason:'native_text'|'blank_page'|'no_extractable_text'|'damaged_text_layer'|'page_text_unavailable';}


/** Native PDF text is parsed on the server from the exact private original, not client-supplied text. */
export async function extractNativePdfPages(bytes: Uint8Array): Promise<NativePdfPage[]> {
  const { getDocumentProxy,getResolvedPDFJS } = await import('unpdf');
  const {OPS}=await getResolvedPDFJS();
  let pdf: Awaited<ReturnType<typeof getDocumentProxy>> | undefined;
  try {
    const options = {
      isEvalSupported: false,
      maxImageSize: INGEST_LIMITS.max_image_pixels,
      useSystemFonts: true,
      useWorkerFetch: false,
      cMapPacked: true,
      BinaryDataFactory: BundledPdfBinaryDataFactory,
      disableFontFace: true,
    };
    pdf = await getDocumentProxy(bytes.slice(), options);
    if (pdf.numPages < 1 || pdf.numPages > INGEST_LIMITS.max_pages) throw new ApiError(413, 'PDF_PAGE_LIMIT', `PDFs must contain 1–${INGEST_LIMITS.max_pages} pages.`);
    const pages: NativePdfPage[] = [];
    let totalChars = 0;
    for (let number = 1; number <= pdf.numPages; number++) {
      const page = await pdf.getPage(number);
      let content:Awaited<ReturnType<typeof page.getTextContent>>;
      try{content=await page.getTextContent();}catch{pages.push({page_number:number,text:'',supported:false,reason:'page_text_unavailable'});page.cleanup();continue;}
      let text = '';
      for (const item of content.items) {
        if (!('str' in item)) continue;
        const value = item.str;
        if (text && !text.endsWith('\n') && !text.endsWith(' ') && value && !value.startsWith(' ')) text += ' ';
        text += value;
        if (item.hasEOL) text += '\n';
      }
      if (text.length > INGEST_LIMITS.max_page_chars) throw new ApiError(413, 'PDF_TEXT_LIMIT', `PDF page ${number} exceeds the readable text limit.`);
      totalChars += text.length;
      if (totalChars > INGEST_LIMITS.max_document_chars) throw new ApiError(413, 'PDF_TEXT_LIMIT', 'The PDF exceeds the one-million-character extracted text limit.');
      const inspection=inspectNativeText(text);
      let decision:NativePdfPage={page_number:number,text,supported:inspection.usable,reason:inspection.usable?'native_text':inspection.nonblank_characters?'damaged_text_layer':'no_extractable_text'};
      if(!inspection.nonblank_characters){
        // An actually empty page needs no extraction. Drawn/scanned content without a text layer is unsupported.
        try{const operators=await page.getOperatorList();const painted=new Set([OPS.stroke,OPS.closeStroke,OPS.fill,OPS.eoFill,OPS.fillStroke,OPS.eoFillStroke,OPS.closeFillStroke,OPS.closeEOFillStroke,OPS.shadingFill,OPS.showText,OPS.showSpacedText,OPS.nextLineShowText,OPS.nextLineSetSpacingShowText,OPS.paintImageXObject,OPS.paintInlineImageXObject,OPS.paintImageMaskXObject,OPS.paintImageXObjectRepeat,OPS.paintImageMaskXObjectRepeat,OPS.paintSolidColorImageMask].filter(value=>typeof value==='number'));if(!operators.fnArray.some(operation=>painted.has(operation)))decision={page_number:number,text,supported:true,reason:'blank_page'};}
        catch{decision={page_number:number,text,supported:false,reason:'page_text_unavailable'};}
      }
      pages.push(decision);
      page.cleanup();
    }
    return pages;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    const message = error instanceof Error ? error.message : '';
    if (/password|encrypted/i.test(message)) throw new ApiError(400, 'ENCRYPTED_PDF', 'Unlock this password-protected PDF before uploading it.');
    throw new ApiError(400, 'INVALID_PDF', 'This PDF could not be read. Upload an unencrypted, undamaged PDF.');
  } finally { await (pdf as (typeof pdf & { destroy?: () => Promise<void> }))?.destroy?.(); }
}

/** Compatibility helper: returns exact native text only, never transcribes an image. */
export async function extractPdfPages(bytes:Uint8Array):Promise<string[]>{return (await extractNativePdfPages(bytes)).map(page=>page.text);}
