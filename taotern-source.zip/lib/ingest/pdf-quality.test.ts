import test from 'node:test';
import assert from 'node:assert/strict';
import {classifyPdfPage,inspectPdfText,pdfRasterCoverage} from './pdf-quality';
test('usable native text, short Mandarin, and blank vector pages never request OCR',()=>{
 assert.equal(classifyPdfPage('Native notice: 12 cm.',0).method,'pdf_text');assert.equal(classifyPdfPage('原生文字。',0).method,'pdf_text');assert.equal(classifyPdfPage('',0).reason,'blank_native_page');
 assert.equal(classifyPdfPage('Long native source text. '.repeat(30),null).method,'pdf_text');assert.equal(inspectPdfText('Long native source text. '.repeat(30)).needs_raster_check,false);
});
test('raster-only pages and sparse scan overlays request only their own page OCR',()=>{
 assert.equal(classifyPdfPage('',0.6).reason,'image_only_scan');assert.equal(classifyPdfPage('Page 2 - scan footer',0.8).reason,'sparse_text_on_scan');assert.equal(classifyPdfPage('Notice with a small logo',0.05).method,'pdf_text');
});
test('explicit damaged glyph layers use scan images; bad native mappings are not indexed as clean text',()=>{
 const text='Bad layer '+ '\uFFFD'.repeat(20);assert.equal(classifyPdfPage(text,0.9).reason,'damaged_scan_layer');assert.ok(classifyPdfPage(text,0).extraction_error);assert.equal(classifyPdfPage('Normal Chinese text：正常繁體中文。',0).method,'pdf_text');
});
test('actual drawing transforms distinguish a page scan from a small decorative image',()=>{
 const ops={save:10,restore:11,transform:12,paintImageXObject:85};
 assert.equal(pdfRasterCoverage({fnArray:[10,12,85,11],argsArray:[null,[600,0,0,800,0,0],['scan',1700,1250],null]},ops,600*800),1);
 assert.ok(pdfRasterCoverage({fnArray:[10,12,85,11],argsArray:[null,[60,0,0,50,0,0],['logo',60,50],null]},ops,600*800)<0.01);
});
