import { ApiError } from '../http';

export const EMBEDDING_MANIFEST_CHUNK_LIMIT = 1000;
export interface EmbeddingSource { chunk_id: string; document_id: string; source_sha256: string | null; version: string }
export interface EmbeddingManifest {
  schema_version: 1;
  project_id: string;
  model: string;
  fingerprint: string;
  public_data_acknowledged: true;
  chunks: EmbeddingSource[];
  source_document_ids: string[];
  scope_total_chunks: number;
  scope_initial_indexed_chunks: number;
  scope_remaining_at_creation: number;
}

export function validateEmbeddingManifest(value: unknown): EmbeddingManifest {
  if (!value || typeof value !== 'object') throw new ApiError(409, 'INVALID_INDEX_MANIFEST', 'The durable semantic-index source manifest is missing.');
  const input = value as Partial<EmbeddingManifest>;
  if (input.schema_version !== 1 || typeof input.project_id !== 'string' || !input.project_id || typeof input.model !== 'string' || input.model.length > 100 || typeof input.fingerprint !== 'string' || !/^[a-f0-9]{64}$/.test(input.fingerprint) || input.public_data_acknowledged !== true || !Array.isArray(input.chunks) || !input.chunks.length || input.chunks.length > EMBEDDING_MANIFEST_CHUNK_LIMIT || !Array.isArray(input.source_document_ids) || input.source_document_ids.some(id => typeof id !== 'string' || id.length > 200)) throw new ApiError(409, 'INVALID_INDEX_MANIFEST', 'The durable semantic-index manifest is invalid.');
  const ids = new Set<string>();
  for (const source of input.chunks) {
    if (!source || typeof source !== 'object' || typeof source.chunk_id !== 'string' || !source.chunk_id || source.chunk_id.length > 200 || ids.has(source.chunk_id) || typeof source.document_id !== 'string' || source.document_id.length > 200 || !input.source_document_ids.includes(source.document_id) || (source.source_sha256 !== null && (typeof source.source_sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(source.source_sha256))) || typeof source.version !== 'string' || source.version.length > 120) throw new ApiError(409, 'INVALID_INDEX_MANIFEST', 'A semantic-index source reference is invalid.');
    ids.add(source.chunk_id);
  }
  for (const count of [input.scope_total_chunks, input.scope_initial_indexed_chunks, input.scope_remaining_at_creation]) if (!Number.isInteger(count) || Number(count) < 0) throw new ApiError(409, 'INVALID_INDEX_MANIFEST', 'The semantic-index coverage counts are invalid.');
  if (input.scope_initial_indexed_chunks! + input.scope_remaining_at_creation! !== input.scope_total_chunks! || input.chunks.length > input.scope_remaining_at_creation!) throw new ApiError(409, 'INVALID_INDEX_MANIFEST', 'The semantic-index coverage counts do not match its source selection.');
  return input as EmbeddingManifest;
}
