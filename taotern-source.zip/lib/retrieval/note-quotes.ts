import { ApiError } from '../http';
import { canonicalQuote } from '../intelligence/evidence';

/** Matching may collapse whitespace, but saved text is always an exact original substring. */
export function canonicalNoteQuote(chunkText: string, pageText: string, input: unknown): string {
  let fallbackEnd = Math.min(700, chunkText.length);
  if (fallbackEnd > 0 && /[\uD800-\uDBFF]/u.test(chunkText[fallbackEnd - 1])) fallbackEnd--;
  const candidate = input === undefined || input === '' ? chunkText.slice(0, fallbackEnd) : input;
  if (typeof candidate !== 'string' || candidate.length > 1500) throw new ApiError(400, 'INVALID_CITATION_QUOTE', 'Citation quotes must be exact passages from the selected source chunk and page.');
  const quote = canonicalQuote(chunkText, candidate, pageText);
  if (quote === null || !quote.trim()) throw new ApiError(400, 'INVALID_CITATION_QUOTE', 'Citation quotes must be exact passages from the selected source chunk and page.');
  return quote;
}
