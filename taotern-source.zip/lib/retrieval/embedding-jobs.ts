import { aiReadiness, embedText, estimateTokens } from '../ai';
import type { EmbeddingResult } from '../ai';
import { all, db, first, newId, now, ownedProject, parseJson } from '../db';
import { ApiError } from '../http';
import { ownedTask, taskView, type StoredTask, type TaskView } from '../ingest/tasks';
import { completeAIUsage, releaseKnownUnusedReservation, reserveAIUsage } from '../intelligence/usage';
import { buildCorpusScope } from './corpus';
import { EMBEDDING_MANIFEST_CHUNK_LIMIT, validateEmbeddingManifest, type EmbeddingManifest, type EmbeddingSource } from './embedding-manifest';

interface ChunkSource extends EmbeddingSource { text: string; embedding_json: string | null; embedding_model: string | null }
export interface EmbeddingProgress { total_chunks: number; indexed_chunks: number; remaining_chunks: number; scope_total_chunks: number; scope_indexed_chunks: number; scope_remaining_chunks: number; model: string; source_document_ids: string[]; partial_manifest: boolean }
export interface EmbeddingReceipt { chunk_id: string; document_id: string; source_sha256: string | null; provider: 'gemini'; model: string; input_tokens_estimate: number; latency_ms: number; vector_dimensions: number; saved: boolean }
export interface EmbeddingTaskView extends TaskView { index_progress: EmbeddingProgress; receipts?: EmbeddingReceipt[] }

/** Stored vectors are produced only by this server-owned provider path. */
const NEEDS_VECTOR = "(c.embedding_model IS NOT ? OR c.embedding_json IS NULL OR CASE WHEN json_valid(c.embedding_json) THEN json_array_length(c.embedding_json) ELSE 0 END<>768)";

async function manifestProgress(owner: string, manifest: EmbeddingManifest): Promise<EmbeddingProgress> {
  const count = await first<{ count: number }>(`SELECT COUNT(*) AS count FROM chunks c JOIN documents d ON d.id=c.document_id JOIN json_each(?) selected ON c.id=json_extract(selected.value,'$.chunk_id') WHERE d.owner_id=? AND c.document_id=json_extract(selected.value,'$.document_id') AND d.source_sha256 IS json_extract(selected.value,'$.source_sha256') AND d.version=json_extract(selected.value,'$.version') AND NOT ${NEEDS_VECTOR}`, JSON.stringify(manifest.chunks), owner, manifest.model);
  const indexed = count?.count ?? 0;
  return { total_chunks: manifest.chunks.length, indexed_chunks: indexed, remaining_chunks: manifest.chunks.length - indexed, scope_total_chunks: manifest.scope_total_chunks, scope_indexed_chunks: manifest.scope_initial_indexed_chunks + indexed, scope_remaining_chunks: Math.max(0, manifest.scope_remaining_at_creation - indexed), model: manifest.model, source_document_ids: manifest.source_document_ids, partial_manifest: manifest.chunks.length < manifest.scope_remaining_at_creation };
}

export async function embeddingTaskView(owner: string, id: string): Promise<EmbeddingTaskView> {
  const view = await taskView(owner, id);
  if (view.task.kind !== 'embedding') throw new ApiError(400, 'WRONG_TASK_KIND', 'This task is not a semantic-index task.');
  const manifest = validateEmbeddingManifest(parseJson(view.task.request_json, null));
  await ownedProject(owner, manifest.project_id);
  return { ...view, index_progress: await manifestProgress(owner, manifest) };
}

export async function createEmbeddingTask(owner: string, input: { project_id: string; document_ids?: string[]; public_data_acknowledged?: boolean }): Promise<EmbeddingTaskView | { task: null; index_progress: EmbeddingProgress }> {
  const scope = await buildCorpusScope(owner, { query: '', project_id: input.project_id, document_ids: input.document_ids });
  if (input.public_data_acknowledged !== true) throw new ApiError(422, 'PUBLIC_DATA_ACK_REQUIRED', 'Confirm that all selected source documents are public or synthetic before indexing them with free-tier Gemini.');
  const readiness = aiReadiness();
  if (!readiness.embedding_configured || !readiness.embedding_model) throw new ApiError(503, 'EMBEDDING_NOT_CONFIGURED', 'Configure an approved Gemini embedding model and free-tier API key before building a semantic index. Keyword search remains available.');
  const model = readiness.embedding_model;
  const count = await first<{ total: number; missing: number }>(`SELECT COUNT(*) AS total,COALESCE(SUM(CASE WHEN ${NEEDS_VECTOR} THEN 1 ELSE 0 END),0) AS missing FROM chunks c JOIN documents d ON d.id=c.document_id WHERE ${scope.predicate}`, model, ...scope.values);
  const total = count?.total ?? 0, missing = count?.missing ?? 0;
  const allDocumentIds = await all<{ id: string }>(`SELECT d.id FROM documents d WHERE ${scope.predicate} ORDER BY d.id`, ...scope.values);
  const sources = await all<ChunkSource>(`SELECT c.id AS chunk_id,c.document_id,c.text,c.embedding_json,c.embedding_model,d.source_sha256,d.version FROM chunks c JOIN documents d ON d.id=c.document_id WHERE ${scope.predicate} AND ${NEEDS_VECTOR} ORDER BY d.updated_at DESC,c.sequence LIMIT ${EMBEDDING_MANIFEST_CHUNK_LIMIT}`, ...scope.values, model);
  const sourceDocumentIds = [...new Set(sources.map(source => source.document_id))];
  if (!missing) return { task: null, index_progress: { total_chunks: 0, indexed_chunks: 0, remaining_chunks: 0, scope_total_chunks: total, scope_indexed_chunks: total, scope_remaining_chunks: 0, model, source_document_ids: allDocumentIds.map(document => document.id), partial_manifest: false } };
  const frozen = sources.map(({ chunk_id, document_id, source_sha256, version }) => ({ chunk_id, document_id, source_sha256, version }));
  const hashBytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(JSON.stringify({ project_id: input.project_id, model, chunks: frozen })).buffer);
  const fingerprint = Array.from(new Uint8Array(hashBytes)).map(byte => byte.toString(16).padStart(2, '0')).join('');
  const manifest: EmbeddingManifest = { schema_version: 1, project_id: input.project_id, model, fingerprint, public_data_acknowledged: true, chunks: frozen, source_document_ids: sourceDocumentIds, scope_total_chunks: total, scope_initial_indexed_chunks: total - missing, scope_remaining_at_creation: missing };
  validateEmbeddingManifest(manifest);
  const id = newId(), timestamp = now();
  // A duplicate click returns the same pending immutable selection, without an extra provider call.
  await db().prepare("INSERT INTO tasks (id,owner_id,project_id,kind,request_json,status,attempt,model,queue_position,queued_at,created_at,updated_at) SELECT ?,?,?,'embedding',?,'queued',0,?,(SELECT COALESCE(MAX(queue_position),0)+1 FROM tasks WHERE owner_id=? AND status IN ('queued','processing')),?,?,? WHERE NOT EXISTS (SELECT 1 FROM tasks existing WHERE existing.owner_id=? AND existing.project_id=? AND existing.kind='embedding' AND existing.status IN ('queued','processing') AND json_extract(existing.request_json,'$.fingerprint')=?)").bind(id, owner, input.project_id, JSON.stringify(manifest), model, owner, timestamp, timestamp, timestamp, owner, input.project_id, fingerprint).run();
  const active = await first<{ id: string }>("SELECT id FROM tasks WHERE owner_id=? AND project_id=? AND kind='embedding' AND status IN ('queued','processing') AND json_extract(request_json,'$.fingerprint')=? ORDER BY created_at LIMIT 1", owner, input.project_id, fingerprint);
  if (!active) throw new ApiError(409, 'INDEX_QUEUE_CHANGED', 'The semantic-index queue changed. Retry the request.');
  return embeddingTaskView(owner, active.id);
}

/** Same authoritative per-owner queue, lease, and fencing as ingestion/intelligence. */
export async function processEmbeddingTask(owner: string, id: string): Promise<EmbeddingTaskView> {
  const initial = await ownedTask(owner, id);
  if (initial.kind !== 'embedding') throw new ApiError(400, 'WRONG_TASK_KIND', 'Use the appropriate processor for this task.');
  if (['completed', 'failed', 'stopped', 'idle'].includes(initial.status)) return embeddingTaskView(owner, id);
  const timestamp = now(), claim = newId(), expiry = new Date(Date.now() + 60000).toISOString();
  const task = await db().prepare("UPDATE tasks SET status='processing',attempt=attempt+1,claim_id=?,lease_expires_at=?,error_message=NULL,updated_at=? WHERE id=? AND owner_id=? AND kind='embedding' AND (status='queued' OR (status='processing' AND (claim_id IS NULL OR lease_expires_at<?))) AND NOT EXISTS (SELECT 1 FROM tasks other WHERE other.owner_id=? AND other.id<>? AND other.status='processing') AND (status='processing' OR NOT EXISTS (SELECT 1 FROM tasks earlier WHERE earlier.owner_id=? AND earlier.status='queued' AND (COALESCE(earlier.queue_position,2147483647)<COALESCE(tasks.queue_position,2147483647) OR (COALESCE(earlier.queue_position,2147483647)=COALESCE(tasks.queue_position,2147483647) AND earlier.created_at<tasks.created_at)))) RETURNING *").bind(claim, expiry, timestamp, id, owner, timestamp, owner, id, owner).first<StoredTask>();
  if (!task) return embeddingTaskView(owner, id);
  let reservation: string | null = null;
  const receipts: EmbeddingReceipt[] = [];
  try {
    const manifest = validateEmbeddingManifest(parseJson(task.request_json, null));
    await ownedProject(owner, manifest.project_id);
    if (task.project_id !== manifest.project_id) throw new ApiError(409, 'INVALID_INDEX_MANIFEST', 'The source manifest does not belong to this project.');
    const readiness = aiReadiness();
    if (!readiness.embedding_configured) throw new ApiError(503, 'EMBEDDING_NOT_CONFIGURED', 'The configured Gemini embedding service is unavailable. Keyword search remains active.');
    if (readiness.embedding_model !== manifest.model) throw new ApiError(409, 'EMBEDDING_MODEL_CHANGED', 'The embedding model changed after this task was created. Create a new index task for the new model.');
    const selection = JSON.stringify(manifest.chunks);
    const actual = await first<{ count: number }>("SELECT COUNT(*) AS count FROM chunks c JOIN documents d ON d.id=c.document_id JOIN json_each(?) selected ON c.id=json_extract(selected.value,'$.chunk_id') WHERE d.owner_id=? AND d.status='ready' AND c.document_id=json_extract(selected.value,'$.document_id') AND d.source_sha256 IS json_extract(selected.value,'$.source_sha256') AND d.version=json_extract(selected.value,'$.version')", selection, owner);
    if (actual?.count !== manifest.chunks.length) throw new ApiError(409, 'SOURCE_CHANGED', 'An indexed source changed after this task was queued. Start a new index task for the current source versions.');
    const pending = await all<ChunkSource>(`SELECT c.id AS chunk_id,c.document_id,c.text,c.embedding_json,c.embedding_model,d.source_sha256,d.version FROM chunks c JOIN documents d ON d.id=c.document_id JOIN json_each(?) selected ON c.id=json_extract(selected.value,'$.chunk_id') WHERE d.owner_id=? AND d.status='ready' AND c.document_id=json_extract(selected.value,'$.document_id') AND d.source_sha256 IS json_extract(selected.value,'$.source_sha256') AND d.version=json_extract(selected.value,'$.version') AND ${NEEDS_VECTOR} ORDER BY CAST(selected.key AS INTEGER) LIMIT 2`, selection, owner, manifest.model);
    for (const chunk of pending) {
      // Recheck the fence before each real request; a stopped/expired task cannot launch more work.
      const fenced = await first<{ id: string }>("SELECT id FROM tasks WHERE id=? AND owner_id=? AND status='processing' AND claim_id=? AND lease_expires_at>?", id, owner, claim, now());
      if (!fenced) break;
      reservation = await reserveAIUsage(owner, `${id}:chunk:${chunk.chunk_id}`, 'gemini', manifest.model, estimateTokens(manifest.model === 'gemini-embedding-2' ? `title: none | text: ${chunk.text}` : chunk.text), 0);
      const started = Date.now();
      const result: EmbeddingResult = await embedText(chunk.text, { task: 'document', public_data_acknowledged: true, signal: AbortSignal.timeout(24000) }, reservation);
      await completeAIUsage(reservation, { provider: result.provider, model: result.model, usage: { input_tokens: result.input_tokens_estimate, output_tokens: 0, total_tokens: result.input_tokens_estimate, estimated: true }, latency_ms: Date.now() - started, fallback_used: false, attempts: 1, cached: false });
      reservation = null;
      if (result.model !== manifest.model || result.values.length !== 768 || result.values.some(value => !Number.isFinite(value))) throw new ApiError(502, 'INVALID_EMBEDDING', 'The provider returned a vector with unexpected provenance or dimensions.');
      const saved = await db().prepare("UPDATE chunks SET embedding_json=?,embedding_model=? WHERE id=? AND document_id=? AND text=? AND EXISTS (SELECT 1 FROM documents d WHERE d.id=chunks.document_id AND d.owner_id=? AND d.status='ready' AND d.source_sha256 IS ? AND d.version=?) AND EXISTS (SELECT 1 FROM tasks WHERE id=? AND owner_id=? AND status='processing' AND claim_id=? AND lease_expires_at>?)").bind(JSON.stringify(result.values), result.model, chunk.chunk_id, chunk.document_id, chunk.text, owner, chunk.source_sha256, chunk.version, id, owner, claim, now()).run();
      receipts.push({ chunk_id: chunk.chunk_id, document_id: chunk.document_id, source_sha256: chunk.source_sha256, provider: result.provider, model: result.model, input_tokens_estimate: result.input_tokens_estimate, latency_ms: Date.now() - started, vector_dimensions: result.values.length, saved: saved.meta.changes === 1 });
      if (saved.meta.changes !== 1) throw new ApiError(409, 'SOURCE_OR_TASK_CHANGED', 'The source or task changed while its embedding was generated. No stale vector was saved.');
    }
    const progress = await manifestProgress(owner, manifest);
    await db().prepare("UPDATE tasks SET status=?,claim_id=NULL,lease_expires_at=NULL,error_message=NULL,updated_at=? WHERE id=? AND owner_id=? AND status='processing' AND claim_id=?").bind(progress.remaining_chunks ? 'processing' : 'completed', now(), id, owner, claim).run();
  } catch (error) {
    if (reservation) {
      const code = error && typeof error === 'object' && 'code' in error ? String(error.code) : '';
      if (['AI_INPUT_BUDGET_EXCEEDED', 'AI_DISABLED', 'AI_NOT_CONFIGURED', 'EMBEDDING_NOT_CONFIGURED', 'PUBLIC_DATA_ACK_REQUIRED'].includes(code)) await releaseKnownUnusedReservation(reservation).catch(() => undefined);
      else await completeAIUsage(reservation, null, true).catch(() => undefined);
    }
    const message = error instanceof Error ? error.message.slice(0, 500) : 'Semantic indexing failed. Existing source text and saved vectors have been retained.';
    await db().prepare("UPDATE tasks SET status='failed',error_message=?,claim_id=NULL,lease_expires_at=NULL,updated_at=? WHERE id=? AND owner_id=? AND status='processing' AND claim_id=?").bind(message, now(), id, owner, claim).run();
  }
  return { ...await embeddingTaskView(owner, id), receipts };
}
