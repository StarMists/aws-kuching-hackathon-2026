import { AIError } from './types';
// Official formats verified 2026-10-07. Read only machine identifiers, never provider messages/metadata:
// https://ai.google.dev/gemini-api/docs/api-errors
// https://ai.google.dev/gemini-api/docs/generate-content/api-errors
const object=(value:unknown):Record<string,unknown>=>value&&typeof value==='object'&&!Array.isArray(value)?value as Record<string,unknown>:{};
const INTERACTION_CODES:Record<string,{code:string;message:string;retryable?:boolean}>={
  authentication:{code:'AI_CREDENTIALS_REJECTED',message:'Provider authentication was rejected. Check the securely saved provider credential.'},
  permission_denied:{code:'AI_ACCESS_DENIED',message:'The provider denied access to this resource. Check the key restrictions and model access.'},
  invalid_request:{code:'AI_INVALID_REQUEST',message:'The provider rejected the request format or parameters.'},
  parameter_unknown:{code:'AI_UNSUPPORTED_PARAMETER',message:'The provider rejected an unsupported request parameter.'},
  failed_precondition:{code:'AI_PREREQUISITE_UNMET',message:'A provider account prerequisite is unmet. The free-only project cannot proceed through a paid setup.'},
  payment_required:{code:'AI_PAYMENT_REQUIRED',message:'The provider requires account credit. Paid setup is outside this project configuration.'},
  model_not_found:{code:'AI_MODEL_UNAVAILABLE',message:'The configured provider model is unavailable.'},
  not_found:{code:'AI_RESOURCE_UNAVAILABLE',message:'The requested provider resource is unavailable.'},
  quota_exceeded:{code:'AI_DAILY_PROVIDER_QUOTA',message:'The provider daily quota is exhausted. Wait for its reset or use an already-configured free backup.'},
  rate_limit_exceeded:{code:'AI_RATE_LIMIT',message:'The provider request or token rate limit was reached.',retryable:true},
  too_many_requests:{code:'AI_RATE_LIMIT',message:'The provider received too many requests.',retryable:true},
  service_unavailable:{code:'AI_PROVIDER_UNAVAILABLE',message:'The provider is temporarily unavailable.',retryable:true},
  deadline_exceeded:{code:'AI_TIMEOUT',message:'The provider request deadline expired.',retryable:true},
  api_error:{code:'AI_PROVIDER_ERROR',message:'The provider returned an internal error.',retryable:true},
  safety:{code:'AI_CONTENT_BLOCKED',message:'The provider blocked the generated content.'},
  recitation:{code:'AI_CONTENT_BLOCKED',message:'The provider blocked a recitation-sensitive response.'},
  spii:{code:'AI_CONTENT_BLOCKED',message:'The provider blocked sensitive personal information.'},
};
export function sanitizedProviderError(payload:unknown,httpStatus:number,provider:string,retryAfter:number|null=null):AIError {
  const error=object(object(payload).error);
  if(provider.startsWith('Gemini')){
    const detail=Array.isArray(error.details)?error.details.map(object).find(d=>d['@type']==='type.googleapis.com/google.rpc.ErrorInfo'&&d.domain==='googleapis.com'):undefined;
    if(detail?.reason==='API_KEY_INVALID')return new AIError('AI_CREDENTIALS_REJECTED','Gemini reports API_KEY_INVALID. Check the securely saved credential; HTTP 400 alone does not establish a key problem.',503,false);
    if(detail?.reason==='API_KEY_SERVICE_BLOCKED')return new AIError('AI_ACCESS_DENIED','Gemini reports that this service is blocked by the key or project access configuration.',503,false);
    const known=typeof error.code==='string'&&Object.prototype.hasOwnProperty.call(INTERACTION_CODES,error.code)?INTERACTION_CODES[error.code]:undefined;
    if(known)return new AIError(known.code,known.message,httpStatus===429?429:503,known.retryable===true,retryAfter);
    if(error.status==='FAILED_PRECONDITION')return new AIError('AI_PREREQUISITE_UNMET','A Gemini account prerequisite is unmet. The project remains free-only.',503,false);
  }
  const retryable=httpStatus===408||httpStatus===429||httpStatus>=500;
  const code=httpStatus===429?'AI_RATE_LIMIT':httpStatus===401?'AI_CREDENTIALS_REJECTED':httpStatus===403?'AI_ACCESS_DENIED':httpStatus===404?'AI_MODEL_UNAVAILABLE':httpStatus===400?'AI_INVALID_REQUEST':'AI_PROVIDER_ERROR';
  return new AIError(code,`${provider} returned HTTP ${httpStatus}.`,httpStatus===429?429:503,retryable,retryAfter);
}
export async function boundedErrorPayload(response:Response):Promise<unknown> {
  if(Number(response.headers.get('content-length'))>65536)return null;
  const reader=response.body?.getReader();if(!reader)return null;
  const decoder=new TextDecoder();let text='',bytes=0;
  try {while(true){const part=await reader.read();if(part.done)break;bytes+=part.value.length;if(bytes>65536){await reader.cancel();return null;}text+=decoder.decode(part.value,{stream:true});}text+=decoder.decode();return JSON.parse(text);}catch{return null;}finally {reader.releaseLock();}
}
