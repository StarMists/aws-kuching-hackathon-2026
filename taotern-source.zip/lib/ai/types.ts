/** Server-only AI boundary. Never import runtime helpers from a client component. */
export type AIProviderName = 'gemini' | 'groq' | 'openai' | 'owner' | 'openrouter';
export type JSONSchema = Record<string, unknown>;
export type AITransport='gemini-interactions'|'gemini-generate-content'|'groq-chat-completions'|'owner-chat-completions'|'openrouter-chat-completions';
export interface AIFailedAttempt {provider:AIProviderName;model:string;code:string;api_transport?:AITransport}
export interface AIUsage { input_tokens:number; output_tokens:number; total_tokens:number; thought_tokens?:number; estimated?:boolean }
export interface AIReceipt { provider:AIProviderName; model:string; usage:AIUsage; latency_ms:number; request_id?:string; fallback_used:boolean; attempts:number; cached:boolean; api_transport?:AITransport; failed_attempts?:AIFailedAttempt[] }
export interface AIResult extends AIReceipt { text:string }
export interface AIImage { base64:string; mime_type:'image/png'|'image/jpeg'|'image/webp' }
export interface AIRequest {
  system:string;
  prompt:string;
  schema?:JSONSchema;
  schema_name?:string;
  max_output_tokens?:number;
  signal?:AbortSignal;
  image?:AIImage;
  public_data_acknowledged?:boolean;
  /** Server-only durable quota hook; never serialized to a provider. */
  before_attempt?:(attempt:number,provider:ProviderConfig)=>Promise<void>;
}
export interface ProviderConfig { provider:AIProviderName; model:string; api_key:string; vision_model?:string; api_mode?:'auto'|'interactions'|'generate-content';api_base_url?:string;owner_dialect?:'openai_compatible'|'openrouter';private_docker?:boolean }
export interface AIConfig {
  enabled:boolean;
  primary:ProviderConfig|null;
  fallback:ProviderConfig|null;
  embedding_model:string|null;
  data_policy:'public-synthetic-only'|'owner-docker-only';
  timeout_ms:number;
  max_input_tokens:number;
  max_output_tokens:number;
  max_retries:number;
}
export interface VisionPageRequest extends AIImage { page_number:number; signal?:AbortSignal; public_data_acknowledged?:boolean }
export interface VisionPageResult extends AIReceipt { text:string; markdown:string; illegible_regions:string[] }
export interface EmbeddingResult { values:number[]; provider:'gemini'; model:string; input_tokens_estimate:number }
export interface ProviderAdapter { readonly name:AIProviderName; generate(request:AIRequest,config:ProviderConfig,signal:AbortSignal,fetcher:typeof fetch):Promise<Omit<AIResult,'fallback_used'|'attempts'|'cached'>> }

export class AIError extends Error {
  failed_attempts:AIFailedAttempt[]=[];
  attempts=0;
  readonly code:string;
  readonly status:number;
  readonly retryable:boolean;
  readonly retry_after_ms:number|null;
  constructor(code:string,message:string,status=503,retryable=false,retryAfter:number|null=null) {
    super(message); this.name='AIError'; this.code=code; this.status=status; this.retryable=retryable; this.retry_after_ms=retryAfter;
  }
}
/** Allowlisted attempt metadata only; never upstream messages, headers or bodies. */
export function aiFailureDetails(error:unknown):{attempts:number;failed_attempts:AIFailedAttempt[]}|null {
  if(!error||typeof error!=='object')return null;
  const raw=(error as {failed_attempts?:unknown}).failed_attempts;
  if(!Array.isArray(raw))return null;
  const attempts=raw.slice(0,3).filter((a):a is AIFailedAttempt=>!!a&&typeof a==='object'&&['gemini','groq','openai','owner','openrouter'].includes(a.provider)&&typeof a.model==='string'&&/^[A-Za-z0-9_/.:\-]{1,100}$/.test(a.model)&&typeof a.code==='string'&&/^[A-Z][A-Z0-9_]{1,80}$/.test(a.code)&&(!a.api_transport||['gemini-interactions','gemini-generate-content','groq-chat-completions','owner-chat-completions','openrouter-chat-completions'].includes(a.api_transport))).map(a=>({provider:a.provider,model:a.model,code:a.code,...(a.api_transport?{api_transport:a.api_transport}:{})}));
  return attempts.length?{attempts:attempts.length,failed_attempts:attempts}:null;
}
export function aiFailureText(error:unknown):string {const details=aiFailureDetails(error);return details?' | Provider attempts: '+details.failed_attempts.map(a=>`${a.provider}/${a.model} (${a.api_transport||'API'}): ${a.code}`).join('; '):'';}
