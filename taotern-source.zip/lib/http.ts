import { AIError,aiFailureDetails } from './ai/types';
export class ApiError extends Error {
  constructor(public status:number,public code:string,message:string,public details?:unknown){super(message);this.name='ApiError';}
}
export function apiData<T>(data:T,status=200):Response{return Response.json({data},{status,headers:{'Cache-Control':'no-store'}})}
function errorHeaders(status:number,retrySeconds:unknown):Headers{
 const headers=new Headers({'Cache-Control':'no-store'});
 if(status===429&&typeof retrySeconds==='number'&&Number.isFinite(retrySeconds)&&retrySeconds>0)headers.set('Retry-After',String(Math.min(86400,Math.max(1,Math.ceil(retrySeconds)))));
 return headers;
}
export function apiError(error:unknown):Response{
  if(error instanceof AIError){const details={...(aiFailureDetails(error)||{}),...(error.retry_after_ms===null?{}:{retry_after_ms:error.retry_after_ms})};return Response.json({error:{code:error.code,message:error.message,...(Object.keys(details).length?{details}:{})}},{status:error.status,headers:errorHeaders(error.status,error.retry_after_ms===null?null:error.retry_after_ms/1000)});}
  if(error instanceof ApiError){const retry=error.details&&typeof error.details==='object'&&'retry_after_seconds'in error.details?error.details.retry_after_seconds:undefined;const attempts=aiFailureDetails(error);const details=attempts?{...(error.details&&typeof error.details==='object'?error.details:{}),...attempts}:error.details;return Response.json({error:{code:error.code,message:error.message,...(details===undefined?{}:{details})}},{status:error.status,headers:errorHeaders(error.status,retry)});}
  console.error('api_failed',error instanceof Error?error.message:String(error));
  return Response.json({error:{code:'INTERNAL_ERROR',message:'The workspace could not complete this request. Please try again.'}},{status:500,headers:{'Cache-Control':'no-store'}});
}
export async function readJson<T=Record<string,unknown>>(request:Request):Promise<T>{try{return await request.json() as T}catch{throw new ApiError(400,'INVALID_JSON','Send a valid JSON request.')}}
export function requiredString(value:unknown,label:string,max=200):string{if(typeof value!=='string'||!value.trim())throw new ApiError(400,'INVALID_INPUT',`${label} is required.`);const result=value.trim();if(result.length>max)throw new ApiError(400,'INVALID_INPUT',`${label} must be ${max} characters or fewer.`);return result;}
