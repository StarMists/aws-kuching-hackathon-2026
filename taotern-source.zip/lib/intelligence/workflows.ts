import { AIError, type AIReceipt, type AIRequest, type AIResult } from '../ai/types';
import type { ArtifactKind } from '../contracts';
import { CLAIM_SCHEMA,GROUNDING_SYSTEM,claimsMarkdown,evidencePrompt,safeReceipt,validateClaims,type EvidenceCoverage,type EvidenceSource,type GroundedClaim } from './evidence';
import { dateSupportedByQuote,normalizeUnambiguousDate } from './dates';
import {pageSupportWarning} from './page-coverage';
import {buildQuoteCatalogue,referenceClaimSchema,validateReferenceClaims,REFERENCE_GROUNDING_SYSTEM,type QuoteCatalogue} from './quote-references';
export { dateSupportedByQuote,normalizeUnambiguousDate } from './dates';

export interface AnalysisInput {project_id:string;kind:ArtifactKind;document_ids?:string[];prompt?:string;previous_document_id?:string;new_document_id?:string;case_text?:string;public_data_acknowledged?:boolean;idempotency_key?:string}
export interface AnalysisFinding {id:string;type:string;title:string;claim_ids:string[];old_claim_ids:string[];new_claim_ids:string[];date:string|null;date_basis:'explicit'|'document_metadata'|'unspecified';change_type:'superseded'|'contradiction'|'addition'|'removal'|'unknown'|null;old_outcome:'supported'|'unsupported'|'indeterminate'|null;new_outcome:'supported'|'unsupported'|'indeterminate'|null;questions:string[];review:{status:'unreviewed'|'confirmed'|'ignored';note:string;updated_at:string|null}}
export interface AnalysisContent {schema_version:1;kind:ArtifactKind;title:string;claims:GroundedClaim[];sections:Array<{heading:string;claim_ids:string[]}>;findings:AnalysisFinding[];missing_evidence:string[];coverage:EvidenceCoverage;receipt:AIReceipt;input_fingerprint?:string;case_text?:string;previous_document_id?:string;new_document_id?:string;user_edited?:boolean;edit_history?:Array<{edited_at:string;previous_markdown:string}>}
const stringList={type:'array',items:{type:'string'}};
const nullString={type:['string','null']};
export const ANALYSIS_SCHEMA={type:'object',additionalProperties:false,properties:{title:{type:'string'},claims:{type:'array',items:CLAIM_SCHEMA},sections:{type:'array',items:{type:'object',additionalProperties:false,properties:{heading:{type:'string'},claim_ids:stringList},required:['heading','claim_ids']}},findings:{type:'array',items:{type:'object',additionalProperties:false,properties:{id:{type:'string'},type:{type:'string'},title:{type:'string'},claim_ids:stringList,old_claim_ids:stringList,new_claim_ids:stringList,date:nullString,date_basis:{type:'string',enum:['explicit','document_metadata','unspecified']},change_type:{type:['string','null'],enum:['superseded','contradiction','addition','removal','unknown',null]},old_outcome:{type:['string','null'],enum:['supported','unsupported','indeterminate',null]},new_outcome:{type:['string','null'],enum:['supported','unsupported','indeterminate',null]},questions:stringList},required:['id','type','title','claim_ids','old_claim_ids','new_claim_ids','date','date_basis','change_type','old_outcome','new_outcome','questions']}},missing_evidence:stringList},required:['title','claims','sections','findings','missing_evidence']};
/** Omit irrelevant null fields so detailed timelines fit the approved free-tier output budget. */
export function analysisSchema(kind:ArtifactKind) {
  const complete=ANALYSIS_SCHEMA.properties.findings.items.properties;
  const limit=kind==='timeline'?8:6;
  const names=['id','type','title','claim_ids','questions',...(kind==='timeline'?['date','date_basis']:[]),...(['conflict','impact','replay'].includes(kind)?['old_claim_ids','new_claim_ids']:[]),...(['conflict','impact'].includes(kind)?['change_type']:[]),...(kind==='replay'?['old_outcome','new_outcome']:[])];
  const citation=CLAIM_SCHEMA.properties.citations.items;
  const claims={type:'array',maxItems:limit,items:{...CLAIM_SCHEMA,properties:{id:{type:'string',maxLength:16},text:{type:'string',maxLength:200},citations:{type:'array',maxItems:2,items:{...citation,properties:{...citation.properties,quote:{type:'string',maxLength:180}}}}}}};
  const properties:Record<string,unknown>={title:{type:'string',maxLength:100},claims,missing_evidence:{type:'array',maxItems:3,items:{type:'string',maxLength:180}}};
  if(kind==='brief')properties.sections={...ANALYSIS_SCHEMA.properties.sections,maxItems:3};
  else properties.findings={type:'array',maxItems:limit,items:{type:'object',additionalProperties:false,properties:Object.fromEntries(names.map(name=>[name,name==='title'?{type:'string',maxLength:100}:name==='id'?{type:'string',maxLength:16}:name==='questions'?{type:'array',maxItems:2,items:{type:'string',maxLength:180}}:complete[name as keyof typeof complete]])),required:names}};
  return {type:'object',additionalProperties:false,properties,required:Object.keys(properties)};
}
const instructions:Record<ArtifactKind,string>={
  brief:'Create a short editable project briefing. Cover the current proposal, evidence-backed rationale, decisions, open actions, uncertainties, and newer versions. Cite every substantive sentence. Organize claims into useful sections. Do not invent sign-off, approvals, budgets, or outcomes.',
  timeline:'Reconstruct the decision timeline, including proposal, rationale, dissent, actual decision, revision, future action deadlines and launch dates. One event per finding. Every explicit finding date must appear as a full date in an exact quote attached to its linked event claim. The first citation supports the event itself; if its date appears only in a header, add a second short exact date-header citation from the SAME document and event context. A meeting held date is not a proposed launch date, and a circular issuance date is not its planned launch. Preserve planning-only decisions and conditional launches. Separate event dates from source document dates; identify date_basis. If the relevant dated source context is unavailable, leave the date null and ask for it. Do not infer dates from your generated claim text. Do not call a proposal a completed launch, or a due date a completed action. Sort verified dated events chronologically.',
  conflict:'Identify competing source statements and distinguish a documented version supersession from an unresolved contradiction. Each finding compares ONE specific attribute. old_claim_ids and new_claim_ids must both state and quote that SAME attribute and its respective value; a new launch-date claim cannot support a counter-count finding. Prioritize at most three correct two-sided comparisons over historical background. Never reuse an unrelated claim merely to fill a required side. If either matching side is absent, omit that comparison and ask for the missing evidence. A compact claim may summarize several values only when its exact quote supports every value. Before output, check each finding against both linked quotes. Preserve source dates and versions. Later statements are not automatically authoritative. A missing passage is not a contradiction. Humans will confirm or ignore findings.',
  gap:'Identify evidence gaps and unresolved questions. State a gap as a question in questions or missing_evidence, never as an assertion that an event did not happen. If the source explicitly marks an action unresolved, include that supported claim. Separate a missing approval record from a false claim that approval never occurred. Humans will confirm or ignore findings.',
  impact:'Compare the explicitly selected older and newer documents. Each finding compares ONE specific attribute, with old and new claims and quotes about that SAME attribute. Do not pair a counter count with a launch date or an amount with an approval. Prioritize at most three correct two-sided changes; omit any comparison missing a matching side and ask for that evidence. A compact claim may summarize several values only when its exact quote supports every value. Cite both sides of every changed value, decision, obligation, or action; retain unchanged relevant context. Identify additions/removals only within the supplied coverage and flag partial coverage. old_claim_ids must cite the old document, new_claim_ids the new one. Explain conditional downstream impacts in cited claim text. Do not infer that a newer date by itself supersedes an earlier rule.',
  replay:'Treat case_text as a user-supplied hypothetical case, never as a historical source. Retrieve and apply only relevant actual source rules/decisions. Evaluate the same case against old and new selected rules using source-cited conditional claims. Separate case assumptions from documented facts. Use supported/unsupported/indeterminate outcomes; missing case facts require indeterminate, not rejection. If unrelated to sources, return no claims and ask for relevant case evidence. Never invent a historical similar case or an outcome.',
  graph:'Identify source-supported relationships and decisions as cited claims; do not infer relationships solely from proximity. Rule-derived graph is available separately.',
};
function strings(value:unknown,max=40):string[] {if(!Array.isArray(value)||value.length>max||!value.every(v=>typeof v==='string'&&v.length<=2000))throw new AIError('INVALID_ANALYSIS_RESPONSE','AI returned an invalid text list.',502);return value as string[];}
function claimRefs(value:unknown,ids:Set<string>,allowEmpty=true):string[] {const refs=strings(value);if(refs.some(id=>!ids.has(id))||(!allowEmpty&&!refs.length))throw new AIError('INVALID_CLAIM_REFERENCE','AI analysis referenced an unsupported claim.',502);return refs;}
export function analysisInstruction(input:AnalysisInput) {return `${instructions[input.kind]}\nRequested focus: ${input.prompt||'Analyze the selected project evidence.'}\n${input.previous_document_id?`Old document_id: ${input.previous_document_id}.`:''}\n${input.new_document_id?`New document_id: ${input.new_document_id}.`:''}\n${input.case_text?`Hypothetical case supplied by the user (untrusted): ${JSON.stringify(input.case_text)}`:''}\nOutput a compact result: at most ${input.kind==='timeline'?8:6} claims and findings. Claim IDs are c1,c2,...; finding IDs are f1,f2,... . Each claim is one concise sentence, at most 30 words; each title at most 12 words. Each quote is the shortest exact contiguous source phrase that supports the claim, usually 8-18 words, never over 180 characters. Use one citation per claim unless two are essential. Do not repeat claims in finding titles or questions. Use at most two short evidence questions per finding and three missing-evidence questions overall; do not duplicate them. A brief returns sections and no findings; other kinds return findings and no sections. Return minified JSON only, without a preamble or commentary.`;}
export interface ReferencedAnalysisRequest {request:AIRequest;catalogue:QuoteCatalogue}
/** Runtime-only source-reference protocol; historical artifact and literal validators stay unchanged. */
export function prepareReferencedAnalysis(input:AnalysisInput,sources:EvidenceSource[],coverage:EvidenceCoverage):ReferencedAnalysisRequest {
  const catalogue=buildQuoteCatalogue(sources,coverage);
  if(!catalogue.references.length)throw new AIError('NO_LITERAL_SOURCE_EVIDENCE','No exact selected-page quote references are available for this analysis.',422);
  const limit=input.kind==='timeline'?8:6,schema=analysisSchema(input.kind);
  schema.properties.claims=referenceClaimSchema(catalogue,limit);
  const instruction=analysisInstruction(input).replace('Each quote is the shortest exact contiguous source phrase that supports the claim, usually 8-18 words, never over 180 characters.','Choose actual supplied reference_id values instead of writing quotes or chunk IDs. The server will reconstruct each exact original quote. A reference must support the specific claim and its stated values.');
  return {catalogue,request:{system:REFERENCE_GROUNDING_SYSTEM,prompt:`${instruction}\nSource coverage: ${JSON.stringify(catalogue.coverage)}\nSelected source quote catalogue: ${catalogue.prompt}`,schema,schema_name:`${input.kind}_analysis`,max_output_tokens:2000,public_data_acknowledged:input.public_data_acknowledged}};
}
export async function runAnalysis(input:AnalysisInput,sources:EvidenceSource[],coverage:EvidenceCoverage,generate:(request:AIRequest)=>Promise<AIResult>,signal?:AbortSignal,prepared?:ReferencedAnalysisRequest):Promise<{content:AnalysisContent;markdown:string;title:string}> {
  if(!sources.length) throw new AIError('NO_SOURCE_EVIDENCE','No usable source excerpts are available for this analysis.',422);
  const result=await generate(prepared?{...prepared.request,signal}:{system:GROUNDING_SYSTEM,prompt:`${analysisInstruction(input)}\nSource coverage: ${JSON.stringify(coverage)}\nSelected source excerpts: ${evidencePrompt(sources)}`,schema:analysisSchema(input.kind),schema_name:`${input.kind}_analysis`,max_output_tokens:2000,signal,public_data_acknowledged:input.public_data_acknowledged});
  let raw:Record<string,unknown>;
  try {raw=JSON.parse(result.text) as Record<string,unknown>;} catch {throw new AIError('INVALID_ANALYSIS_RESPONSE','AI returned invalid analysis JSON.',502);}
  if(raw&&input.kind==='brief'&&raw.findings===undefined)raw.findings=[];
  if(raw&&input.kind!=='brief'&&raw.sections===undefined)raw.sections=[];
  const itemLimit=input.kind==='timeline'?8:6;
  if(!raw||typeof raw.title!=='string'||!raw.title.trim()||raw.title.length>100||!Array.isArray(raw.sections)||!Array.isArray(raw.findings)||raw.sections.length>3||raw.findings.length>itemLimit) throw new AIError('INVALID_ANALYSIS_RESPONSE','AI returned an invalid compact analysis structure.',502);
  const claims=await (prepared?validateReferenceClaims(raw.claims,sources,prepared.catalogue,itemLimit):validateClaims(raw.claims,sources,itemLimit)),ids=new Set(claims.map(c=>c.id));
  if(claims.some(claim=>claim.id.length>16||claim.text.length>200||claim.evidence.length>2))throw new AIError('INVALID_ANALYSIS_RESPONSE','AI returned an oversized compact claim.',502);
  const sections=raw.sections.map(value=>{const section=value as Record<string,unknown>;if(typeof section.heading!=='string'||section.heading.length>120)throw new AIError('INVALID_ANALYSIS_RESPONSE','Invalid analysis section.',502);return {heading:section.heading,claim_ids:claimRefs(section.claim_ids,ids)};});
  const findingIds=new Set<string>();
  const findings:AnalysisFinding[]=raw.findings.map(value=>{
    const item=value as Record<string,unknown>;
    if(typeof item.id!=='string'||!item.id||item.id.length>64||findingIds.has(item.id)||typeof item.type!=='string'||item.type.length>40||typeof item.title!=='string'||item.title.length>240)throw new AIError('INVALID_ANALYSIS_RESPONSE','Invalid analysis finding.',502);
    findingIds.add(item.id);
    const refs=claimRefs(item.claim_ids,ids),oldRefs=claimRefs(item.old_claim_ids??[],ids),newRefs=claimRefs(item.new_claim_ids??[],ids);
    const questions=strings(item.questions,2);
    if(!refs.length&&!oldRefs.length&&!newRefs.length&&!questions.length)throw new AIError('UNCITED_CLAIM','An analysis finding has neither cited claims nor an evidence question.',502);
    if(input.kind==='conflict'&&(!oldRefs.length||!newRefs.length))throw new AIError('UNSUPPORTED_CONFLICT','A conflict requires cited source statements on both sides.',502);
    const oldDoc=input.previous_document_id,newDoc=input.new_document_id;
    if((input.kind==='impact'||input.kind==='replay')&&oldDoc&&oldRefs.some(id=>!claims.find(c=>c.id===id)?.evidence.some(e=>e.document_id===oldDoc)))throw new AIError('INVALID_VERSION_CITATION','The old-rule claim does not cite the selected old document.',502);
    if((input.kind==='impact'||input.kind==='replay')&&newDoc&&newRefs.some(id=>!claims.find(c=>c.id===id)?.evidence.some(e=>e.document_id===newDoc)))throw new AIError('INVALID_VERSION_CITATION','The new-rule claim does not cite the selected new document.',502);
    const basis=['explicit','document_metadata','unspecified'].includes(String(item.date_basis))?item.date_basis as AnalysisFinding['date_basis']:'unspecified';
    let date=typeof item.date==='string'&&item.date.length<=80?normalizeUnambiguousDate(item.date):null;
    const linked=claims.filter(c=>[...refs,...oldRefs,...newRefs].includes(c.id));
    const explicitDate=date;
    if(explicitDate&&basis==='explicit'&&!linked.some(c=>c.evidence.some(e=>e.document_id===c.evidence[0]?.document_id&&dateSupportedByQuote(explicitDate,e.quote))))date=null;
    const metadataDate=date;
    if(metadataDate&&basis==='document_metadata'&&!linked.some(c=>c.evidence.some(e=>normalizeUnambiguousDate(e.source_date)===metadataDate)))date=null;
    if(basis==='unspecified')date=null;
    const change=['superseded','contradiction','addition','removal','unknown'].includes(String(item.change_type))?item.change_type as AnalysisFinding['change_type']:null;
    const outcome=(value:unknown)=>['supported','unsupported','indeterminate'].includes(String(value))?value as AnalysisFinding['old_outcome']:null;
    let oldOutcome=outcome(item.old_outcome),newOutcome=outcome(item.new_outcome);
    if(input.kind==='replay'){if(!oldRefs.length)oldOutcome='indeterminate';if(!newRefs.length)newOutcome='indeterminate';}
    return {id:item.id,type:item.type,title:item.title,claim_ids:refs,old_claim_ids:oldRefs,new_claim_ids:newRefs,date,date_basis:date?basis:'unspecified',change_type:change,old_outcome:oldOutcome,new_outcome:newOutcome,questions,review:{status:'unreviewed',note:'',updated_at:null}};
  });
  if(input.kind==='timeline')findings.sort((a,b)=>{const left=a.date?Date.parse(a.date):NaN,right=b.date?Date.parse(b.date):NaN;return (Number.isFinite(left)?left:Infinity)-(Number.isFinite(right)?right:Infinity)||(a.date||'9999').localeCompare(b.date||'9999');});
  const missing=strings(raw.missing_evidence,3);
  const content:AnalysisContent={schema_version:1,kind:input.kind,title:raw.title.trim(),claims,sections,findings,missing_evidence:missing,coverage:prepared?.catalogue.coverage||coverage,receipt:safeReceipt(result),...(input.case_text?{case_text:input.case_text}:{}),...(input.previous_document_id?{previous_document_id:input.previous_document_id}:{}),...(input.new_document_id?{new_document_id:input.new_document_id}:{})};
  return {content,title:content.title,markdown:analysisMarkdown(content)};
}
export function analysisMarkdown(content:AnalysisContent):string {
  const lines=[`# ${content.title}`];
  const supportWarning=pageSupportWarning(content.coverage);if(supportWarning)lines.push(supportWarning);
  if(content.kind==='replay')lines.push('This is a conditional comparison of a user-supplied hypothetical case. It is not a historical case outcome or an approval decision.');
  const covered=new Set<string>();
  for(const section of content.sections){const claims=content.claims.filter(c=>section.claim_ids.includes(c.id));if(claims.length){lines.push(`## ${section.heading}`,claimsMarkdown(claims));claims.forEach(c=>covered.add(c.id));}}
  const other=content.claims.filter(c=>!covered.has(c.id));if(other.length)lines.push('## Source-grounded findings',claimsMarkdown(other));
  if(!content.claims.length)lines.push('Insufficient evidence: the selected source excerpts do not support the requested conclusion.');
  if(content.findings.length){lines.push('## Investigation items');for(const item of content.findings){lines.push(`### ${item.date?`${item.date} (${item.date_basis}) · `:''}${item.title}`);if(item.change_type)lines.push(`Classification: ${item.change_type}.`);if(content.kind==='replay')lines.push(`Old rules: ${item.old_outcome||'indeterminate'}. New rules: ${item.new_outcome||'indeterminate'}.`);for(const question of item.questions)lines.push(`- Evidence needed: ${question}`);}}
  if(content.missing_evidence.length)lines.push('## Evidence still needed',...content.missing_evidence.map(question=>`- ${question}`));
  lines.push('## Coverage',`${content.coverage.included_chunk_count} of ${content.coverage.total_chunk_count} stored chunks included, across ${content.coverage.included_document_count} of ${content.coverage.selected_document_count} selected documents. ${content.coverage.truncated?'Partial source coverage. Missing excerpts do not establish that a fact is false.':'Selected corpus covered within the input budget.'}`,'## Generation receipt',`Provider: ${content.receipt.provider}. Model: ${content.receipt.model}. Input tokens: ${content.receipt.usage.input_tokens}. Output tokens: ${content.receipt.usage.output_tokens}. ${content.receipt.cached?'Reused validated cached output.':'Generated by an actual provider request.'}`);
  return lines.join('\n\n');
}
