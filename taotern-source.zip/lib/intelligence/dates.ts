const MONTHS:Record<string,number>={january:1,jan:1,february:2,feb:2,march:3,mar:3,april:4,apr:4,may:5,june:6,jun:6,july:7,jul:7,august:8,aug:8,september:9,sep:9,sept:9,october:10,oct:10,november:11,nov:11,december:12,dec:12};
const MONTH='(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)';
function calendarDate(year:number,month:number,day:number):string|null {
  if(!Number.isInteger(year)||year<1||year>9999||month<1||month>12||day<1||day>31)return null;
  const date=new Date(0);date.setUTCHours(0,0,0,0);date.setUTCFullYear(year,month-1,day);
  // Reject rollover (30 February, 31 April, etc.) rather than silently assigning another day.
  if(date.getUTCFullYear()!==year||date.getUTCMonth()!==month-1||date.getUTCDate()!==day)return null;
  return `${String(year).padStart(4,'0')}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
}
/** Date-only values. Slash dates, omitted years, ranges, and relative dates remain unspecified. */
export function normalizeUnambiguousDate(value:string|null|undefined):string|null {
  if(typeof value!=='string')return null;const text=value.trim();
  let match=/^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(text);
  if(match)return calendarDate(Number(match[1]),Number(match[2]),Number(match[3]));
  match=new RegExp(`^(\\d{1,2})(?:st|nd|rd|th)?\\s+(${MONTH})\\.?[,]?\\s+(\\d{4})$`,'i').exec(text);
  if(match)return calendarDate(Number(match[3]),MONTHS[match[2].toLowerCase()],Number(match[1]));
  match=new RegExp(`^(${MONTH})\\.?\\s+(\\d{1,2})(?:st|nd|rd|th)?[,]?\\s+(\\d{4})$`,'i').exec(text);
  if(match)return calendarDate(Number(match[3]),MONTHS[match[1].toLowerCase()],Number(match[2]));
  match=/^(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*(?:日|号)$/.exec(text);
  return match?calendarDate(Number(match[1]),Number(match[2]),Number(match[3])):null;
}
export function quotedSourceDates(quote:string):string[] {
  const result=new Set<string>();
  const patterns=[/\b\d{4}-\d{1,2}-\d{1,2}\b/g,new RegExp(`\\b\\d{1,2}(?:st|nd|rd|th)?\\s+${MONTH}\\.?[,]?\\s+\\d{4}\\b`,'gi'),new RegExp(`\\b${MONTH}\\.?\\s+\\d{1,2}(?:st|nd|rd|th)?[,]?\\s+\\d{4}\\b`,'gi'),/\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*(?:日|号)/gu];
  for(const pattern of patterns)for(const match of quote.matchAll(pattern)){const date=normalizeUnambiguousDate(match[0]);if(date)result.add(date);}
  return [...result];
}
export function dateSupportedByQuote(date:string,quote:string):boolean {const normalized=normalizeUnambiguousDate(date);return normalized!==null&&quotedSourceDates(quote).includes(normalized);}
