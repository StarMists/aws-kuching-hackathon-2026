import type {EvidenceCoverage} from './evidence';
export interface CoverageDocument {id:string;title:string;page_count:number;extraction_method:string|null}
export interface CoveragePage {document_id:string;page_number:number;text:string;extraction_method?:string;extraction_metadata_json?:string|null}
/** Page support is separate from chunk selection: every retained chunk can fit while a PDF page is unsupported. */
export function withPageSupport(coverage:EvidenceCoverage,documents:CoverageDocument[],pages:CoveragePage[]):EvidenceCoverage {
 const unsupported:NonNullable<EvidenceCoverage['unsupported_pages']>=[];
 let total=0,supported=0;
 for(const document of documents){
  const count=Number.isInteger(document.page_count)&&document.page_count>0?document.page_count:0;total+=count;
  for(let number=1;number<=count;number++){
   const page=pages.find(p=>p.document_id===document.id&&p.page_number===number);
   let metadata:Record<string,unknown>={};try{if(page?.extraction_metadata_json)metadata=JSON.parse(page.extraction_metadata_json)||{};}catch{}
   const unavailable=page?.extraction_method==='unsupported'||metadata.support_status==='not_supported'||metadata.supported===false||(!page&&document.extraction_method==='partial_native_text');
   if(unavailable){const reason=typeof metadata.reason_code==='string'?metadata.reason_code:typeof metadata.reason==='string'?metadata.reason:'page_evidence_unavailable';unsupported.push({document_id:document.id,document_title:document.title,page_number:number,reason_code:reason.slice(0,100)});}
   else if(page)supported++;
  }
 }
 const partial=unsupported.length>0||documents.some(d=>d.extraction_method==='partial_native_text');
 if(!partial)return coverage;
 return {...coverage,truncated:true,total_page_count:total,supported_page_count:supported,unsupported_pages:unsupported,partial_document_ids:documents.filter(d=>d.extraction_method==='partial_native_text'||unsupported.some(p=>p.document_id===d.id)).map(d=>d.id)};
}
export function pageSupportWarning(coverage:EvidenceCoverage):string|null {
 if(!coverage.partial_document_ids?.length&&!coverage.unsupported_pages?.length)return null;
 const pages=coverage.unsupported_pages?.map(p=>`${p.document_title||p.document_id}, page ${p.page_number}`).join('; ');
 return `Partial native-page evidence: ${coverage.supported_page_count??'?'} of ${coverage.total_page_count??'?'} selected pages are supported. ${pages?`NOT SUPPORTED: ${pages}. `:''}Unreadable pages are excluded from evidence; their missing text cannot establish that a fact is false.`;
}
