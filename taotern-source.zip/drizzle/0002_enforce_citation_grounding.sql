-- Forward-only schema guards. Existing citation rows remain intact.
-- New citation parts must use an accepted source of their response job and literal stored evidence.
CREATE TRIGGER `citation_selected_source_insert` BEFORE INSERT ON `chat_message_parts`
WHEN NEW.type='citation' AND NOT EXISTS (
  SELECT 1 FROM chat_jobs j JOIN chat_job_sources s ON s.job_id=j.id
  WHERE j.response_message_id=NEW.message_id AND s.document_id=NEW.citation_document_id
)
BEGIN
  SELECT RAISE(ABORT, 'Citation must use the response job selected source');
END;
--> statement-breakpoint
CREATE TRIGGER `citation_selected_source_update` BEFORE UPDATE ON `chat_message_parts`
WHEN NEW.type='citation' AND NOT EXISTS (
  SELECT 1 FROM chat_jobs j JOIN chat_job_sources s ON s.job_id=j.id
  WHERE j.response_message_id=NEW.message_id AND s.document_id=NEW.citation_document_id
)
BEGIN
  SELECT RAISE(ABORT, 'Citation must use the response job selected source');
END;
--> statement-breakpoint
CREATE TRIGGER `citation_literal_quote_insert` BEFORE INSERT ON `chat_message_parts`
WHEN NEW.type='citation' AND NOT EXISTS (
  SELECT 1 FROM chunks c JOIN pages p ON p.id=c.page_id
  WHERE c.id=NEW.citation_chunk_id AND c.document_id=NEW.citation_document_id
    AND c.page_number=NEW.citation_page_number
    AND instr(c.text,NEW.citation_quote)>0 AND instr(p.text,NEW.citation_quote)>0
)
BEGIN
  SELECT RAISE(ABORT, 'Citation quote must occur literally in its chunk and page');
END;
--> statement-breakpoint
CREATE TRIGGER `citation_literal_quote_update` BEFORE UPDATE ON `chat_message_parts`
WHEN NEW.type='citation' AND NOT EXISTS (
  SELECT 1 FROM chunks c JOIN pages p ON p.id=c.page_id
  WHERE c.id=NEW.citation_chunk_id AND c.document_id=NEW.citation_document_id
    AND c.page_number=NEW.citation_page_number
    AND instr(c.text,NEW.citation_quote)>0 AND instr(p.text,NEW.citation_quote)>0
)
BEGIN
  SELECT RAISE(ABORT, 'Citation quote must occur literally in its chunk and page');
END;
