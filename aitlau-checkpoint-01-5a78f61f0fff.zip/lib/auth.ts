import { env } from 'cloudflare:workers';
import { ApiError } from './http';
export async function requireOwner(request:Request):Promise<string>{
  const id=request.headers.get('oai-authenticated-user-id');
  const email=request.headers.get('oai-authenticated-user-email');
  if(id&&email)return id;
  // This binding is opt-in solely for local preview. Never configured in Sites production.
  if((env as unknown as Record<string,unknown>).LOCAL_DEV_AUTH==='true')return 'local-preview-owner';
  throw new ApiError(401,'SIGN_IN_REQUIRED','Sign in with ChatGPT to open your private workspace.');
}
export function assertSameOrigin(request:Request):void{
 const origin=request.headers.get('origin');
 if(origin&&origin!==new URL(request.url).origin)throw new ApiError(403,'INVALID_ORIGIN','This request must come from the workspace.');
}
