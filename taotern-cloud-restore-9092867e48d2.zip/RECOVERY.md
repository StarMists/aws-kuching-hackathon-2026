# Taotern Sites recovery and verification

## Scope and current checkpoint

This repository is Taotern Evidence Workspace, the Sites/Vinext TypeScript migration of the original AITLAU product. It uses a Worker, D1 structured records, private R2 originals/page images, and server-only provider calls. It does not start the original Docker, Supabase, Flutter, or Python services. See `docs/PROVENANCE.md` for the exact inspected source pins and the distinction between contract adaptation and executable code reuse.

Checkpoint: **2026-10-07 05:11 UTC**. Current hosted source is `ee00cedc21579d8c42ec3da8dcd4cfdcd3f21174`, deployment `appgdep_6ac5d44111588191ad9191312d48682f`, environment revision14, at https://taotern-kuching-2026.liuyz8715.chatgpt.site/ . Audience is public, but projects/documents are authenticated and owner-private; visitor AI is disabled. The publisher confirmed the repaired release terminal live at05:10:57 UTC. A fixed Groq health probe passed112 actual tokens at05:12:42 UTC; same-job grounded workflow retries are pending. This small probe does not establish a six-tool quality pass. The separately clean-restored base is `9e7e5421c27ad286e1c296506e7a630aff23a949`. This checkpoint is not a release certification.

| Required feature | Observed status at this checkpoint |
|---|---|
| Document library, uploads, metadata and OCR | Actual text/nativePDF/Mandarin upload, exact pages/bytes, source-date POST/PATCH/clear and range responses passed locally. Hosted photo OCR attempts failed; repaired retry/transcription quality remain pending. |
| Keyword/natural retrieval and cited answers | Real fresh-nonce keyword search passed. Hosted Gemini Embedding2 indexed8/8 actual chunks and a real paraphrase returned cited relevant documents. One hosted PDF factual answer and exact page highlight passed. Follow-up/unknown acceptance pending. |
| Decision timeline | Actual hosted job failed with incomplete/output-budget response; no artifact. Compact-provider repair and same-job retry pending. |
| Editable/exportable cited brief | Actual hosted generation failed Gemini HTTP503. Editing/export acceptance blocked until a real artifact exists. |
| Conflicts/gaps and human review | Actual conflict failed HTTP503; gap timed out; no finding artifacts. Human confirm/ignore acceptance pending. |
| New-version impact and old/new case replay | Stored version lineage/hash dedup passed locally. Actual impact timed out; replay failed HTTP503; no artifacts. |
| Relationship graph | Actual source-derived project graph and empty out-of-scope graph passed HTTP checks. Hosted interaction/mobile acceptance pending. |
| Fresh upload/unknown/contradiction/cancel/restore | Fresh runtime nonce upload/search and same-task stop/restore/restart/R2 survival passed. Live unknown/contradiction reasoning pending. |
| Persistent Projects/chats/notes/artifacts | Projects/notes, metadata CAS, owner/project boundaries, raw Unicode quotations and restart persistence passed locally. Hosted project rename/description edit observed. Six failed analysis jobs preserved; populated AI history/artifact reload acceptance pending. |
| Free Gemini primary/Groq backup | Gemini health, one grounded answer and real embeddings passed. Complex six-workflow batch failed; provider repair/Groq live acceptance pending. Keys remain backend-only. |
| Responsive xushi-inspired GUI | Code-native geometry implemented; initial real source view inspected; final Taotern responsive screenshots pending. |
| Main-only source backup | Base9e7e542 independently clean-installed/built/tested. Whole downloaded native checkpoint02 ZIP matched all408 base hashes,0 missing/mismatched, CRC clean. Latest-release native delta pending. |

## Restore application source in a clean directory

Prerequisites: Node.js >=22.13.0, npm, and access to the declared dependency registry or its exact seeded cache. Do not assume installed dependencies or environment secrets are included in the source archive.

1. Extract the source package into a fresh writable directory. Confirm that `package.json`, `package-lock.json`, `app/`, `lib/`, `db/`, `drizzle/`, and the bundled license notices exist.
2. Run `npm run install:ci`. Do not overlap package installers. This installs the lockfile's declared runtime/build dependencies without creating a global environment.
3. Run `npx tsc --noEmit`.
4. Run `node --loader ./tests/typescript-loader.mjs --test tests/*.test.mjs`. The API suite is skipped unless `QA_BASE_URL` is set; this default command establishes deterministic/mock results only.
5. Run `npm run build`. This creates the local built Worker configuration at `dist/server/wrangler.json`; the build does not publish.
6. For an empty local D1 database only, apply the initial migration with:

   `node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_remarkable_makkari.sql`

   For a new empty database, then apply `drizzle/0001_enforce_domain_invariants.sql` and `drizzle/0002_enforce_citation_grounding.sql` with the same command, in that order. Apply later migrations in sequence when present. Never replay either migration into an existing database. Production migrations are a separately authorized Sites operation.
7. Start a built local Worker with `npm start -- --port 5174`. It listens on loopback and uses `.wrangler/state` for D1/R2. This is local preview, not deployment.
8. For isolated synthetic integration testing, run `node tests/run-worker-integration.mjs` in another terminal/process. This runner owns its built Worker, all HTTP checks, an actual restart-persistence check, and teardown. Stop any existing preview on5174 first. It is the supported route in environments where commands have separate network namespaces.

   For an ordinary shared-network terminal, the equivalent already-running preview command is `QA_BASE_URL=http://127.0.0.1:5174 QA_AUTH_MODE=headers node --test tests/api-integration.test.mjs`.

   These local header identities must never be used to impersonate users on a hosted Site. The suite only accepts loopback origins. It creates clearly synthetic records and does not delete user data.

Optional development preview: `npm run dev -- --hostname 127.0.0.1 --port 5173`. The portable preview simulates ChatGPT sign-in at `/signin-with-chatgpt?return_to=/`; supplied identity headers are stripped by the mock. For that preview use `QA_AUTH_MODE=cookie`; cross-owner tests are explicitly skipped because the mock has a single stable development user.

## Restore configuration and data separately

The source archive intentionally excludes `.env*`, credentials, `.wrangler/`, database contents, uploaded files, model outputs, dependencies, caches, and full original company repositories. Source backup is not a user-data backup.

- The Site declares D1 `DB` and R2 `BUCKET` in `.openai/hosting.json`.
- A source restore must attach/create the authorized Site's bindings through Sites, apply its migrations, and restore a separately obtained D1/R2 backup if existing user data is needed.
- D1 alone is insufficient: source originals/page images are in private R2. Preserve source hashes and storage keys as a pair. No full cloud-data restore has been verified at this checkpoint.
- Configure provider secrets only through the authorized server-side environment. Never paste keys into browser inputs, source files, commits, or test reports.
- `AI_ENABLED` defaults false. Approved settings include `GEMINI_API_KEY`/`GEMINI_MODEL`, optional `GEMINI_EMBEDDING_MODEL`, and `GROQ_API_KEY`/`GROQ_MODEL` backup. The runtime allowlist is the source of truth; availability and free-quota entitlement still require actual provider verification.
- `AI_VISITOR_ENABLED` stays false until global/viewer quota guards and public isolation are accepted. `QA_ALLOWED_OWNER_ID` is configured server-side; the owner-only `/qa` page returns notFound for other identities. Global/day and per-viewer usage bounds include unknown/interrupted attempts.
- The free-provider flow accepts only public or synthetic documents/prompts after the data-use acknowledgement. Keep real sensitive government/company material out of this test workflow.

## Resume interrupted work

Persisted tasks, chat jobs, and analysis jobs expose their real canonical status and error. Resume/retry only the existing job, preserving its source snapshot. Polling and reload must not duplicate messages or artifacts. The Worker is not an always-running scheduler; bounded job slices are resumed through the documented process/polling APIs.

The owner-only QA harness can load matching saved synthetic runs through read-only APIs after a reload. Select the same project, original allowed sources and old/new pair, load saved jobs, then explicitly acknowledge data use before retrying failed jobs. Retry preserves IDs/source snapshots, paces successful calls by 65 seconds and pauses on the first failure; it never retries 429 automatically. Normal product UI remains the primary feature workflow.

Task source files survive stop/failure so the owning user can retry. An absent key must remain a visible failure; it must never turn into a canned answer or fabricated OCR transcription. An incomplete evidence result should identify what still requires human verification.

## Recorded checks

- Actual built ee00ced Worker HTTP integration:18 checks passed, including fresh source upload, PDF page identity, exact originals, keyword/project boundaries, notes/CAS/citation forgery rejection, graph scope, no-key failures and cross-owner IDs/mixed lists.
- Actual Worker restart preserved Project/documents/pages/tasks/notes and saved chat container (the no-key turn was rejected, so no populated AI messages). Original private R2 file retained the fresh source nonce after restart.
- Exact9e7e542 source clean restore:701 dependencies installed from lockfile; TypeScript exit0;41 deterministic/mock tests passed and the API suite was explicitly skipped; independent Worker build exit0. No symlink to the original checkout or source-tree import fallback was used. Generated restore dependencies were removed after verification.
- Original immutable source tar SHA256: `e542c982e4147c16a04c82647642a9f84b4fa419b6417ac24df4662a0bee4548`. Its native upload staging has408 files,4,717,387 bytes, split90/90/90/90/48; every staged byte was hash-checked.
- Focused current-source error sanitization:5 deterministic tests passed after the9e7e542 snapshot. These diagnostics are subsequent local work.
- Native PDF/CJK extraction and chunk/image/metadata checks:7 focused parser tests passed in the ingestion owner’s test suite.
- Initial read-only packaging inventory: no high-specificity credential indicator found in inspected source inputs; this is not a comprehensive secret-safety certification.
- Hosted authentication, fixed Gemini readiness, one native-PDF factual answer/source highlight and8/8 real Gemini Embedding2 chunks passed on the bounded synthetic corpus. All6 actual analysis jobs on4c8/environment8 failed with no artifact; see docs/ACCEPTANCE.md. Follow-up/unknown/contradiction, repaired OCR, six-workflow quality and final responsive screenshots remain pending.
- Pre-repair deterministic/mock aggregate had71 passes and1 skipped API suite. Subsequent Retry-After4/4 and atomic quota SQLite8/8 focused checks passed; latest whole-app TypeScript and harness ESLint exit0. These figures are separate from live model acceptance. New migration0002 guards exact literal quotes and accepted response-job sources; existing historical rows are unchanged.
- Backup ZIP02 SHA256: `a4bed501360fe499df95dc620d05ae00c1478647cae06975bf59e7d786ec4cf2`; CRC checked locally and exact remote download readback confirmed by publisher at main commit `99bdd0c7b8160d71b94a4130907703578c4e8681`. Whole native checkpoint02 archive at remote main `4c1dd8ec848e0c8850bcd872db624a208b6ccd95` independently matched all408 base files. Archive SHA256: `062928f5a0e544e4eccafbf1620443f84ff2a664f556e52e941cb353c3a990ca`; no missing/mismatched files, CRC clean. Later source deltas require a separate readback. Local headless Chromium could not start because the sandbox disallowed its process-singleton socket; no local visual pass is inferred from HTTP tests.
