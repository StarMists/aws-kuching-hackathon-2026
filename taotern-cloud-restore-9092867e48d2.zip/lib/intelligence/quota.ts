/** Pure quota policy and atomic SQL, shared by Workers and deterministic SQLite tests. */
export interface AIQuotaPolicy {verified_owner_id:string;visitor_enabled:boolean;global_daily_tokens:number;owner_daily_tokens:number;visitor_daily_tokens:number;visitor_pool_daily_tokens:number;visitor_requests_per_minute:number;global_active:number;visitor_active:number;lease_seconds:number}
export interface QuotaReservation {id:string;owner:string;job_id:string;provider:string;model:string;input:number;output:number;timestamp:string;parent_id?:string}
export interface QuotaTotals {global_tokens:number;owner_tokens:number;visitor_tokens:number;reserved_tokens:number;unknown_tokens:number;owner_calls:number;minute_calls:number;global_active:number;visitor_active:number;oldest_minute:string|null;oldest_active:string|null;oldest_visitor_active:string|null}
function bound(e:Record<string,unknown>,key:string,fallback:number,max:number) {const n=Number(e[key]);return Number.isFinite(n)&&n>0?Math.max(1,Math.min(max,Math.floor(n))):fallback;}
export function readQuotaPolicy(e:Record<string,unknown>):AIQuotaPolicy {return {verified_owner_id:typeof e.QA_ALLOWED_OWNER_ID==='string'?e.QA_ALLOWED_OWNER_ID:'',visitor_enabled:e.AI_VISITOR_ENABLED==='true',global_daily_tokens:bound(e,'AI_GLOBAL_DAILY_TOKEN_BUDGET',100000,150000),owner_daily_tokens:bound(e,'AI_DAILY_TOKEN_BUDGET',100000,200000),visitor_daily_tokens:bound(e,'AI_VISITOR_DAILY_TOKEN_BUDGET',10000,10000),visitor_pool_daily_tokens:bound(e,'AI_VISITOR_POOL_DAILY_TOKEN_BUDGET',20000,20000),visitor_requests_per_minute:bound(e,'AI_VISITOR_REQUESTS_PER_MINUTE',2,2),global_active:bound(e,'AI_MAX_ACTIVE_REQUESTS',2,2),visitor_active:1,lease_seconds:45};}
export function quotaWindows(timestamp:string,leaseSeconds=45) {const date=new Date(timestamp);return {day:date.toISOString().slice(0,10)+'T00:00:00.000Z',reset:new Date(Date.UTC(date.getUTCFullYear(),date.getUTCMonth(),date.getUTCDate()+1)).toISOString(),minute:new Date(date.getTime()-60000).toISOString(),active:new Date(date.getTime()-leaseSeconds*1000).toISOString()};}
export function quotaReservationStatement(p:AIQuotaPolicy,r:QuotaReservation) {
 const w=quotaWindows(r.timestamp,p.lease_seconds),visitor=r.owner!==p.verified_owner_id,cost=r.input+r.output;
 const sql=`INSERT INTO ai_usage (id,owner_id,job_id,provider,model,input_tokens,output_tokens,status,created_at)
 SELECT ?,?,?,?,?,?,?,?,? WHERE
 COALESCE((SELECT SUM(input_tokens+output_tokens) FROM ai_usage WHERE created_at>=?),0)+?<=?
 AND COALESCE((SELECT SUM(input_tokens+output_tokens) FROM ai_usage WHERE owner_id=? AND created_at>=?),0)+?<=?
 AND (?=0 OR COALESCE((SELECT SUM(input_tokens+output_tokens) FROM ai_usage WHERE owner_id<>? AND created_at>=?),0)+?<=?)
 AND (?=0 OR (SELECT COUNT(*) FROM ai_usage WHERE owner_id=? AND created_at>=?)<?)
 AND ((? IS NULL AND (SELECT COUNT(*) FROM ai_usage WHERE status='reserved' AND created_at>=?)<?
 AND (?=0 OR (SELECT COUNT(*) FROM ai_usage WHERE status='reserved' AND owner_id<>? AND created_at>=?)<?))
 OR (? IS NOT NULL AND EXISTS (SELECT 1 FROM ai_usage WHERE id=? AND owner_id=? AND status='reserved' AND created_at>=?)))`;
 const args:(string|number|null)[]=[r.id,r.owner,r.job_id,r.provider,r.model,r.input,r.output,r.parent_id?'retry_reserved':'reserved',r.timestamp,w.day,cost,p.global_daily_tokens,r.owner,w.day,cost,visitor?p.visitor_daily_tokens:p.owner_daily_tokens,visitor?1:0,p.verified_owner_id,w.day,cost,p.visitor_pool_daily_tokens,visitor?1:0,r.owner,w.minute,p.visitor_requests_per_minute,r.parent_id||null,w.active,p.global_active,visitor?1:0,p.verified_owner_id,w.active,p.visitor_active,r.parent_id||null,r.parent_id||null,r.owner,w.active];
 return {sql,args};
}
export function quotaTotalsStatement(p:AIQuotaPolicy,owner:string,timestamp:string) {
 const w=quotaWindows(timestamp,p.lease_seconds);
 const sql=`SELECT
 COALESCE(SUM(CASE WHEN created_at>=? THEN input_tokens+output_tokens ELSE 0 END),0) AS global_tokens,
 COALESCE(SUM(CASE WHEN owner_id=? AND created_at>=? THEN input_tokens+output_tokens ELSE 0 END),0) AS owner_tokens,
 COALESCE(SUM(CASE WHEN owner_id<>? AND created_at>=? THEN input_tokens+output_tokens ELSE 0 END),0) AS visitor_tokens,
 COALESCE(SUM(CASE WHEN owner_id=? AND created_at>=? AND status IN ('reserved','retry_reserved') THEN input_tokens+output_tokens ELSE 0 END),0) AS reserved_tokens,
 COALESCE(SUM(CASE WHEN owner_id=? AND created_at>=? AND status IN ('failed_unknown_usage','completed_with_unknown_prior_usage') THEN input_tokens+output_tokens ELSE 0 END),0) AS unknown_tokens,
 COALESCE(SUM(CASE WHEN owner_id=? AND created_at>=? THEN 1 ELSE 0 END),0) AS owner_calls,
 COALESCE(SUM(CASE WHEN owner_id=? AND created_at>=? THEN 1 ELSE 0 END),0) AS minute_calls,
 COALESCE(SUM(CASE WHEN status='reserved' AND created_at>=? THEN 1 ELSE 0 END),0) AS global_active,
 COALESCE(SUM(CASE WHEN status='reserved' AND owner_id<>? AND created_at>=? THEN 1 ELSE 0 END),0) AS visitor_active,
 MIN(CASE WHEN owner_id=? AND created_at>=? THEN created_at ELSE NULL END) AS oldest_minute,
 MIN(CASE WHEN status='reserved' AND created_at>=? THEN created_at ELSE NULL END) AS oldest_active,
 MIN(CASE WHEN status='reserved' AND owner_id<>? AND created_at>=? THEN created_at ELSE NULL END) AS oldest_visitor_active
 FROM ai_usage WHERE created_at>=?`;
 const args=[w.day,owner,w.day,p.verified_owner_id,w.day,owner,w.day,owner,w.day,owner,w.day,owner,w.minute,w.active,p.verified_owner_id,w.active,owner,w.minute,w.active,p.verified_owner_id,w.active,[w.day,w.minute,w.active].sort()[0]];
 return {sql,args};
}
