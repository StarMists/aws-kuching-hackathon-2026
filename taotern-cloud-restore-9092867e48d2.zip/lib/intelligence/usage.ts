import { env } from 'cloudflare:workers';
import { all,db,first,newId,now } from '../db';
import { ApiError } from '../http';
import type { AIReceipt,AIRequest,ProviderConfig } from '../ai/types';
import { quotaReservationStatement,quotaTotalsStatement,quotaWindows,readQuotaPolicy,type AIQuotaPolicy,type QuotaTotals } from './quota';
interface UsageReservation {id:string;owner_id:string;job_id:string;provider:string;model:string;input_tokens:number;output_tokens:number;status:string;created_at:string}
function policy() {return readQuotaPolicy(env as unknown as Record<string,unknown>);}
function assertAccess(owner:string,p:AIQuotaPolicy) {
 const verified=!!p.verified_owner_id&&owner===p.verified_owner_id;
 if(!verified&&!p.visitor_enabled)throw new ApiError(403,'VISITOR_AI_DISABLED','Visitor AI is temporarily paused while shared demo limits are verified. Private projects, documents and keyword search remain available.',{visitor_ai_disabled:true});
 if(p.visitor_enabled&&!p.verified_owner_id)throw new ApiError(503,'AI_OWNER_NOT_CONFIGURED','The shared AI safety configuration is incomplete. Please try again after the demo owner finishes setup.');
}
async function totals(owner:string,p:AIQuotaPolicy,timestamp=now()):Promise<QuotaTotals> {const statement=quotaTotalsStatement(p,owner,timestamp);return await first<QuotaTotals>(statement.sql,...statement.args)||{global_tokens:0,owner_tokens:0,visitor_tokens:0,reserved_tokens:0,unknown_tokens:0,owner_calls:0,minute_calls:0,global_active:0,visitor_active:0,oldest_minute:null,oldest_active:null,oldest_visitor_active:null};}
function quotaMessage(message:string,reset:string,remaining:number) {return `${message} Remaining allowance: ${Math.max(0,remaining)} tokens. Reset: ${reset}.`; }
function retryDetails(reset:string,remaining:number,scope:string,timestamp:string) {return {scope,remaining_tokens:Math.max(0,remaining),reset_at:reset,retry_after_seconds:Math.max(1,Math.ceil((Date.parse(reset)-Date.parse(timestamp))/1000))};}
async function quotaError(owner:string,p:AIQuotaPolicy,cost:number,timestamp:string,parentId?:string):Promise<never> {
 const t=await totals(owner,p,timestamp),w=quotaWindows(timestamp,p.lease_seconds),visitor=owner!==p.verified_owner_id;
 if(t.global_tokens+cost>p.global_daily_tokens)throw new ApiError(429,'AI_GLOBAL_DAILY_BUDGET_EXCEEDED',quotaMessage('The shared demo AI token budget is exhausted.',w.reset,p.global_daily_tokens-t.global_tokens),retryDetails(w.reset,p.global_daily_tokens-t.global_tokens,'global',timestamp));
 const ownerLimit=visitor?p.visitor_daily_tokens:p.owner_daily_tokens;
 if(t.owner_tokens+cost>ownerLimit)throw new ApiError(429,'AI_DAILY_BUDGET_EXCEEDED',quotaMessage('Your daily AI allowance cannot cover another bounded request.',w.reset,ownerLimit-t.owner_tokens),retryDetails(w.reset,ownerLimit-t.owner_tokens,'viewer',timestamp));
 if(visitor&&t.visitor_tokens+cost>p.visitor_pool_daily_tokens)throw new ApiError(429,'AI_VISITOR_POOL_BUDGET_EXCEEDED',quotaMessage('The shared visitor AI allowance is exhausted.',w.reset,p.visitor_pool_daily_tokens-t.visitor_tokens),retryDetails(w.reset,p.visitor_pool_daily_tokens-t.visitor_tokens,'visitor_pool',timestamp));
 if(visitor&&t.minute_calls>=p.visitor_requests_per_minute){const reset=new Date(Date.parse(t.oldest_minute||timestamp)+60000).toISOString();throw new ApiError(429,'AI_VISITOR_RATE_LIMIT',quotaMessage('Please wait before another AI request. Each provider retry also counts toward this limit.',reset,ownerLimit-t.owner_tokens),retryDetails(reset,ownerLimit-t.owner_tokens,'viewer_minute',timestamp));}
 if(!parentId&&(t.global_active>=p.global_active||(visitor&&t.visitor_active>=p.visitor_active))){const reset=new Date(Date.parse((visitor&&t.visitor_active>=p.visitor_active?t.oldest_visitor_active:t.oldest_active)||timestamp)+p.lease_seconds*1000).toISOString();throw new ApiError(429,'AI_SHARED_BUSY',quotaMessage('The shared AI service is busy. Your source data is retained; an active request may finish sooner.',reset,ownerLimit-t.owner_tokens),retryDetails(reset,ownerLimit-t.owner_tokens,'shared_active',timestamp));}
 throw new ApiError(429,'AI_RESERVATION_EXPIRED','The AI request reservation expired or was no longer active. Retry the durable job.',retryDetails(new Date(Date.parse(timestamp)+1000).toISOString(),ownerLimit-t.owner_tokens,'reservation',timestamp));
}
async function reserve(owner:string,jobId:string,provider:string,model:string,input:number,output:number,parentId?:string):Promise<string> {
 const p=policy();assertAccess(owner,p);
 if(!Number.isInteger(input)||input<0||!Number.isInteger(output)||output<0||input+output<1||input+output>20000)throw new ApiError(400,'AI_INVALID_RESERVATION','The AI request requires a valid bounded token reservation.');
 const id=newId(),timestamp=now(),statement=quotaReservationStatement(p,{id,owner,job_id:jobId,provider,model,input,output,timestamp,parent_id:parentId});
 // The conditional INSERT is one D1 statement, so simultaneous isolates cannot
 // both pass a stale budget, minute-rate, or active-lease check.
 const result=await db().prepare(statement.sql).bind(...statement.args).run();
 if(!result.meta.changes)return quotaError(owner,p,input+output,timestamp,parentId);
 return id;
}
export async function reserveAIUsage(owner:string,jobId:string,provider:string,model:string,inputEstimate=5000,outputEstimate=2000):Promise<string> {return reserve(owner,jobId,provider,model,inputEstimate,outputEstimate);}
/** Runtime provider attempts require a durable reservation; pure adapter tests do not. */
export async function withAIReservation<T>(reservationId:string,request:Pick<AIRequest,'signal'>,work:(beforeAttempt:(attempt:number,provider:ProviderConfig)=>Promise<void>)=>Promise<T>):Promise<T> {
 if(typeof reservationId!=='string'||!reservationId)throw new ApiError(503,'AI_RESERVATION_REQUIRED','A durable AI usage reservation is required before contacting the provider.');
 const initial=await first<UsageReservation>('SELECT * FROM ai_usage WHERE id=?',reservationId);
 if(!initial||initial.status!=='reserved')throw new ApiError(409,'AI_RESERVATION_INVALID','The AI usage reservation is no longer active. Retry the durable job.');
 const p=policy();assertAccess(initial.owner_id,p);
 const retries:string[]=[];
 try {return await work(async(attempt,provider)=>{
  if(request.signal?.aborted)throw new ApiError(499,'AI_CANCELLED','Generation was cancelled.');
  const current=await first<UsageReservation>("SELECT * FROM ai_usage WHERE id=? AND status='reserved' AND created_at>=?",reservationId,quotaWindows(now(),p.lease_seconds).active);
  if(!current)throw new ApiError(429,'AI_RESERVATION_EXPIRED','The AI request reservation expired. Retry the durable job.');
  if(attempt===1)await db().prepare("UPDATE ai_usage SET provider=?,model=? WHERE id=? AND status='reserved'").bind(provider.provider,provider.model,reservationId).run();
  if(attempt>1)retries.push(await reserve(initial.owner_id,`retry:${reservationId}`,provider.provider,provider.model,initial.input_tokens,initial.output_tokens,reservationId));
 });} finally {for(const id of retries)await completeAIUsage(id,null,true);}
}
export async function completeAIUsage(id:string,receipt:AIReceipt|null,failed=false) {
 if(receipt){
  const additional=await all<{id:string}>('SELECT id FROM ai_usage WHERE job_id=? ORDER BY created_at DESC,rowid DESC',`retry:${id}`);
  // Actual usage belongs to the last attempt, on its own UTC day. Prior rows
  // keep their original bounds, including when a retry crosses midnight.
  const target=receipt.attempts>1&&additional.length?additional[0].id:id;
  const legacy=Math.max(0,receipt.attempts-1-additional.length);
  if(target!==id)await db().prepare("UPDATE ai_usage SET status='failed_unknown_usage' WHERE id=?").bind(id).run();
  await db().prepare('UPDATE ai_usage SET provider=?,model=?,input_tokens=?,output_tokens=?,status=? WHERE id=?').bind(receipt.provider,receipt.model,receipt.usage.input_tokens+5000*legacy,Math.max(receipt.usage.output_tokens,receipt.usage.total_tokens-receipt.usage.input_tokens)+2000*legacy,failed?'failed':legacy>0?'completed_with_unknown_prior_usage':'completed',target).run();
 }else await db().prepare("UPDATE ai_usage SET status='failed_unknown_usage' WHERE id=?").bind(id).run();
}
export async function releaseKnownUnusedReservation(id:string) {await db().prepare("UPDATE ai_usage SET input_tokens=0,output_tokens=0,status='rejected_before_generation' WHERE id=? AND status='reserved'").bind(id).run();}
export async function usageSummary(owner:string) {return all<{provider:string;model:string;input_tokens:number;output_tokens:number;calls:number}>('SELECT provider,model,SUM(input_tokens) AS input_tokens,SUM(output_tokens) AS output_tokens,COUNT(*) AS calls FROM ai_usage WHERE owner_id=? AND created_at>=? GROUP BY provider,model',owner,new Date().toISOString().slice(0,10)+'T00:00:00.000Z');}
export async function usageBudget(owner:string) {
 const p=policy(),timestamp=now(),w=quotaWindows(timestamp,p.lease_seconds),t=await totals(owner,p,timestamp),visitor=owner!==p.verified_owner_id,limit=visitor?p.visitor_daily_tokens:p.owner_daily_tokens;
 const available=[limit-t.owner_tokens,p.global_daily_tokens-t.global_tokens,...(visitor?[p.visitor_pool_daily_tokens-t.visitor_tokens]:[])];
 return {day_utc:w.day.slice(0,10),reset_at:w.reset,daily_token_budget:limit,used_or_reserved_token_bound:t.owner_tokens,reserved_tokens:t.reserved_tokens,unknown_usage_included:t.unknown_tokens,remaining_tokens:Math.max(0,Math.min(...available)),viewer_remaining_tokens:Math.max(0,limit-t.owner_tokens),calls:t.owner_calls,providers:await usageSummary(owner),viewer_role:visitor?'visitor':'owner',visitor_ai_disabled:visitor&&!p.visitor_enabled,shared:{daily_token_budget:p.global_daily_tokens,remaining_tokens:Math.max(0,p.global_daily_tokens-t.global_tokens),active_requests:t.global_active,max_active_requests:p.global_active,lease_seconds:p.lease_seconds},...(visitor?{visitor_pool:{daily_token_budget:p.visitor_pool_daily_tokens,remaining_tokens:Math.max(0,p.visitor_pool_daily_tokens-t.visitor_tokens)},minute_rate:{limit:p.visitor_requests_per_minute,used:t.minute_calls}}:{}),warning:'The app budget uses conservative reservations. Each retry is reserved separately. Successful receipts record actual tokens including thoughts; interrupted calls retain estimated usage. Provider account quotas also apply.'};
}
