import { env } from 'cloudflare:workers';
import { aiReadiness } from './ai';
import type { RuntimeConfig } from './contracts';
export function runtimeConfig(owner?:string):RuntimeConfig{
 const settings=env as unknown as Record<string,string|undefined>;
 const ownerMatch=!!owner&&!!settings.QA_ALLOWED_OWNER_ID&&owner===settings.QA_ALLOWED_OWNER_ID;
 const visitorDisabled=!ownerMatch&&settings.AI_VISITOR_ENABLED!=='true';
 return {
  ...aiReadiness(),retrieval_backend:'sites',ocr_configured:false,ocr_paused:true,ocr_notice:'OCR is paused. Upload native-text PDF, TXT, or Markdown sources.',viewer_role:ownerMatch?'owner':'visitor',visitor_ai_disabled:visitorDisabled,...(visitorDisabled?{ai_access_notice:'Visitor AI is temporarily paused while shared demo limits are verified. Your private projects, documents and keyword search remain available.'}:{}),max_upload_bytes:20*1024*1024,supported_types:['application/pdf','text/plain','text/markdown'],
  max_document_pages:80,max_ocr_pages:20,storage:{database:!!env.DB,files:!!env.BUCKET},private_workspace:true,
 };
}
