/** Server runtime entry point; keys never leave Cloudflare Workers bindings. */
import { env } from 'cloudflare:workers';
import { readAIConfig,publicAIConfig } from './ai/config';
import { generateWithConfig,embeddingWithConfig } from './ai/providers';
import { visionWithConfig } from './ai/vision';
import { withAIReservation } from './intelligence/usage';
import type { AIRequest,VisionPageRequest } from './ai/types';
export { AIError,aiFailureDetails,aiFailureText } from './ai/types';
export { estimateTokens } from './ai/providers';
export type { AIRequest,AIResult,AIReceipt,AIUsage,VisionPageRequest,VisionPageResult,EmbeddingResult,JSONSchema } from './ai/types';
export function getAIConfig() {return readAIConfig(env as unknown as Record<string,unknown>);}
export function aiReadiness() {const config=getAIConfig();return {...publicAIConfig(config),embedding_model:config.embedding_model};}
export function generateText(request:AIRequest,reservationId:string) {return withAIReservation(reservationId,request,before_attempt=>generateWithConfig({...request,before_attempt},getAIConfig()));}
export function embedText(text:string,options:{task:'query'|'document';signal?:AbortSignal;public_data_acknowledged?:boolean},reservationId:string) {return withAIReservation(reservationId,options,async beforeAttempt=>{const config=getAIConfig(),gemini=[config.primary,config.fallback].find(p=>p?.provider==='gemini');if(gemini)await beforeAttempt(1,{...gemini,model:config.embedding_model||gemini.model});return embeddingWithConfig(text,options.task,config,options);});}
export function extractVisionPage(request:VisionPageRequest,reservationId:string) {return withAIReservation(reservationId,request,beforeAttempt=>visionWithConfig(request,getAIConfig(),fetch,beforeAttempt));}
