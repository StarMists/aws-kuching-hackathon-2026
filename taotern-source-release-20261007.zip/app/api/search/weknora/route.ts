import { assertSameOrigin, requireOwner } from '@/lib/auth';
import { ApiError, apiData, apiError, readJson, requiredString } from '@/lib/http';
import { indexWeKnoraSources, weknoraClient } from '@/lib/retrieval/weknora';

export const dynamic = 'force-dynamic';
export async function GET(request: Request): Promise<Response> {
  try {
    await requireOwner(request);
    const client = weknoraClient();
    await client.health(); await client.checkKnowledgeBase();
    return apiData({ backend: 'weknora', service_reachable: true, existing_kb_accessible: true, host_index_query_verified: false });
  } catch (error) { return apiError(error); }
}
export async function POST(request: Request): Promise<Response> {
  try {
    assertSameOrigin(request); const owner = await requireOwner(request); const body = await readJson<Record<string, unknown>>(request);
    if (body.public_data_acknowledged !== true) throw new ApiError(422, 'PUBLIC_DATA_ACK_REQUIRED', 'Acknowledge the selected source transmission to the existing WeKnora service.');
    if (body.document_ids !== undefined && !Array.isArray(body.document_ids)) throw new ApiError(400, 'INVALID_SCOPE', 'Send an array of selected document IDs.');
    return apiData(await indexWeKnoraSources(owner, requiredString(body.project_id, 'Project ID', 200), body.document_ids as string[] | undefined));
  } catch (error) { return apiError(error); }
}
