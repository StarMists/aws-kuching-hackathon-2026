# Local teammate verification

## Status and scope

The Taotern installer and adapters are prepared for the owner's **existing** AITLAU Docker stack. The original backend/model, Docker installer, original OCR engine and WeKnora round trip have **not been verified on a teammate's host**. Source typechecks/mocks and local Worker tests are separate evidence. Only an actual host report can change these statuses.

Use the latest release/installer bundle named by the publisher. The native GitHub tree may lag that bundle during handoff. Preserve `Participants: Daniel Ong Zhi En, You Zheng` in the root README.

The installer attaches only the new Taotern UI adapter to a verified existing Docker network and uses a new Taotern D1/R2 state volume. It does not rebuild, reset or delete the original stack. Existing private configuration is reused server-side. Do not send `.env`, resolved Compose configuration, passwords, API keys, tokens or complete container inspection output to chat or reports.

## Start, then one-command report

From the extracted app directory on Windows:

1. Confirm Docker Desktop and the original stack are already running. Locate the actual existing `Docker-Deployment` checkout.
2. Run `./local-runtime/Install.ps1 -ExistingStack "C:\path\to\Docker-Deployment" -Project "your-existing-compose-project"`. Choose only a Docker network reported on those existing containers. If PowerShell blocks the script, use the owner's approved execution route; do not change global security policy.
3. Run `./local-runtime/Check.ps1` for startup/health. Open `http://127.0.0.1:8788` and verify the Taotern GUI. This does not establish backend/model/OCR quality.
4. After explicitly agreeing to process **only our synthetic fixtures** with the already-configured existing model, run the redacted acceptance harness:

   `node tests/run-host-verification.mjs --base-url http://127.0.0.1:8788 --live-ai`

   If host Node22+ is unavailable, use the packaged container route:

   `docker compose -f .taotern-install/compose.local.yaml exec -T taotern_ui node tests/run-host-verification.mjs --base-url http://127.0.0.1:8788 --live-ai --output /data/host-verification`

   The updated Check.ps1 may wrap this command through its explicit `-LiveAI` switch. Without `--live-ai`, no model-backed acceptance is claimed.

5. Copy the redacted report out of the new adapter container, if using that route:

   `docker compose -f .taotern-install/compose.local.yaml cp taotern_ui:/data/host-verification/report.json ./host-verification-report.json`

The runner prints the exact report path. Reports contain PASS/FAIL/NOTRUN, version/health metadata, synthetic IDs/hashes, checked citation coordinates, actual provider receipts/token counts and export hashes. They exclude environment values, credentials, raw model responses and unrelated user documents. An inner-container DockerCLI NOTRUN must be paired with the outer host Docker/Compose version check; it is not an engine pass. Do not run alongside other active jobs under the same local owner. No automatic provider retry occurs; the analysis batch pauses after a real provider/job failure. Calls are paced by at least65 seconds. Original OCR can take longer than a single-page model call; bounded waits remain visible.

## Expected original fixture facts

- Circularv1: source date2026-09-14;3 native PDF pages; proposed12November2026; RM240,000 ceiling;3 counters. No OCR should run on native pages.
- Minutes: source date2026-10-02;2 native pages; D-02 retains the older plan **for planning only**; no procurement commitment approved; Jo Chan dissent; A-17 Mira report due30October and A-18 Arif procurement reference due28October remain unresolved.
- Circularv2: source date2026-10-05;3 native pages;19November/RM210,000/2 counters supersede the corresponding v1 planning values; inspection3November. Source originals/hashes and previous-version link must survive.
- Later operations note: source date2026-10-06; repeats the older12November/3-counter plan. Treat this separately from documented v1→v2 supersession.
- Photo OCR: actual original-engine receipt plus112cm, `NOT signed off`, and nonce `SERAI-47-LANTERN-PEAR`. The text oracle is never uploaded.
- Mixed5-page PDF: exact originals and saved page mapping; OCR **only pages2 and5**; pages1/3/4 retain native source text. Both scanned pages contain the original field-slip image. Confirm the final fixture correction is in the release before claiming this pass.
- Unknown fields: supplier, signed procurement reference, served-resident total and measured queue reduction are not provided. An answer must not invent them or assert the underlying events never occurred.

## What the report checks

Actual app startup/health, read-only Docker/service discovery, a new synthetic persistent Project, native PDF originals/date/version readback, keyword scope, real existing WeKnora index completion and paraphrased query with literal source citations, original OCR receipt and needed-pages-only processing, all six real saved analysis workflows, literal page/chunk citations, editable brief save, cited Markdown exports and conservative fixture-specific meaning checks. Keyword/vector results alone never count as WeKnora reuse. A completed job/literal quote alone does not establish every conclusion is correct.

## Actual app-only restart proof

The runner saves `restart-state.json` beside its report. Stop/restart **only** the new `taotern_ui` adapter, keeping its state volume; do not restart/reset/remove the original stack:

`docker compose -f .taotern-install/compose.local.yaml restart taotern_ui`

Then run the same harness with `--verify-restart /data/host-verification/restart-state.json --output /data/host-verification-after-restart` in the adapter container. A pass requires a changed per-process `/local-health` boot ID and identical synthetic Project/artifact envelope and original R2 bytes. If boot IDs are unavailable, restart is not established. A browser reload is insufficient.

## Manual GUI follow-through and blockers

Open actual source PDFs as the main reader, switch exact pages, and check citation highlights. In the synthetic Project, inspect timeline dates and planning qualifications; compare same-attribute old/new conflict sides; confirm/ignore a finding with an explicit QA note and reload; inspect the brief edit/export; click relationship graph evidence; test a follow-up/unknown question and stop/restore the same durable job. Record screenshots as actual host views, never substitute mock screenshots or seeded answers.

Return the redacted JSON and exact failed/NOTRUN codes to the publisher. Missing model/gateway/WeKnora settings, inaccessible existing knowledge base, unsupported quotes or timeouts remain real blockers. Reuse the already-approved local configuration; do not register a new tenant, create credentials, buy a model or initialize a replacement backend to make a test appear to pass.
