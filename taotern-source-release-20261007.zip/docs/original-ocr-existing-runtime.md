# Original AITLAU OCR runtime integration

The local Taotern UI calls `local-runtime/original-ocr-gateway.mjs`, which uses the **already running original Supabase database, Storage and OCR container**. It creates no second OCR engine or queue. `lib/ingest/original-ocr.ts` imports completed original page results into the UI's isolated D1 source/citation view.

## Required existing configuration

- `AITLAU_OCR_BACKEND=original` (owner AI mode also requires this original adapter)
- `AITLAU_SUPABASE_URL`: existing private Supabase gateway
- `SERVICE_ROLE_KEY` or `AITLAU_SUPABASE_SERVICE_ROLE_KEY`: existing server environment, never browser configuration
- `AITLAU_OWNER_ID`: explicit existing Supabase `auth.users` UUID with corresponding profile. No account or credential is created.
- Local gateway injects a random process-only `AITLAU_LOCAL_BRIDGE_TOKEN` and loopback `AITLAU_LOCAL_BRIDGE_URL`.
- Existing original OCR container must already be healthy and have its original model proxy configured for the owner's API.

## Exact interface adaptation

`POST /internal/ocr/jobs/:localTaskUUID` receives the immutable original bytes/hash, local document UUID and selected exact-page JPEGs. It losslessly embeds those JPEG byte streams in a derived PDF, sized at300 DPI so the original400-DPI renderer remains bounded. Original bytes remain in private R2. The derived PDF and source-page mapping are stored in existing `task-pdfs` and `pdf_files` metadata. The local task UUID is also the original queue task UUID.

The adapter inserts the original `public.pdf_files` and `public.tasks` shapes, then calls the original `enqueue_task` RPC. This direct server-side insertion is a deliberate interface adaptation: it does **not** claim to call/copy `create_task`, whose original authenticated-upload ownership check is incompatible with a service-role Storage upload. It uses an explicitly configured existing owner and private Storage. Original database migrations, queue RPCs, worker claim/heartbeat/cache/finalizer and engine are unchanged.

`GET /internal/ocr/jobs/:id` returns actual original task status, original document metadata and exact raw `document_pages` fields: `id,document_id,page_number,markdown_content,ocr_metadata`. The adapter maps original derived-PDF page numbers back to original source-page numbers. Native text pages never enter this queue.

`POST .../:id/stop` dequeues a queued task with original `dequeue_task`, then sets canonical stopped status and fences its claim. `POST .../:id/retry` resets failed/stopped to idle then uses original `enqueue_task`; completed tasks do not rerun. All lookups and mutations constrain the configured original owner UUID. Original worker caches/artifacts are retained. The existing queue's global pause remains authoritative and is not changed by this adapter.

## Faithful engine boundary

The worker continues to execute unchanged `taotern_ocr.OCRPipeline` and `PageOCRGraph`, including orientation, layout, OCR, deterministic repair, visual audit and targeted rewrite according to the original run configuration. The original filesystem retains document Markdown, confidence Markdown, rendered/annotated PDFs, reports, source metadata, per-model request receipts and caches. The UI preserves raw `ocr_metadata`; it does not fabricate confidence or claim an audit result without the original report.

The existing service only exposes `/health`, `/ready`, and `/internal/v1/wake`; submit/poll/stop/retry are the thin gateway interfaces above. No Docker socket, Docker CLI, software download, original engine rebuild, local model launch, alternate paid service or public service exposure is required.

## Verification and current limits

`node --test local-runtime/original-ocr-gateway.test.mjs`:3 tests pass. Submit/poll/idempotence are explicitly mocked and make no provider calls. The actual synthetic source JPEG is embedded byte-for-byte; PyMuPDF independently verified a valid single raster-page PDF with no invented text layer. Whole-app TypeScript checks pass.

Actual existing-host queue/OCR execution has not been established by these mock tests and needs the teammate's existing runtime/configuration. No live OCR-quality success is claimed. PNG/WebP direct uploads without the browser's JPEG preparation fail clearly; the normal upload dialog prepares supported JPEGs. Current native/scan detection retains the captured24-nonwhitespace-character rule; sophisticated sparse-overlay or damaged-text detection was paused when the owner requested literal original engine reuse.

Pinned source engine: TaoternOCR `80336b06ff8d04e6497d80cd148950faaa67be35`; deployment `4118358a2239c7feb74de9b9a7931113cb92a7da`. Unchanged full engine packet and30-file SHA manifest are available in the packaged original-source handoff. The new gateway is an integration adapter, not a rewrite of that engine.
