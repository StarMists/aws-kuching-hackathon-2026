# Reusing the existing AITLAU WeKnora runtime

The owner confirmed their desktop already has Docker and has run AITLAU, and approved using that local route while retaining the Taotern GUI. Keep the working Sites retrieval implementation unchanged until a replacement is verified. The teammate runs the packaged installer and host checks on that existing installation. No second WeKnora backend or new credentials are created.

## Pinned source

- Docker-Deployment baseline: `4118358a2239c7feb74de9b9a7931113cb92a7da`
- AITLAU application snapshot: `edafa77efea3ece16e43be63d59f4f47a9a56e70`
- Existing client: `aitlau_chat/src/aitlau_chat/weknora.py`
- Page-to-Markdown indexer: `aitlau_chat/src/aitlau_chat/indexer.py`
- Immutable job sources, buffered SSE and citation decoding: `aitlau_chat/src/aitlau_chat/worker.py`
- Existing document/knowledge mappings: `aitlau_chat/src/aitlau_chat/persistence.py`

The source snapshots are under `../input/Docker-Deployment-main` and `../input/AITLAU-edafa77efea3ece16e43be63d59f4f47a9a56e70` in the cloud checkout. The teammate selects their actual existing checkout; those cloud snapshot paths are not required on the desktop.

## Verified REST contract

- Create KB: POST `/api/v1/knowledge-bases`
- Upload page-preserving Markdown: POST `/api/v1/knowledge-bases/:kb/knowledge/file`
- Poll actual parsing: GET `/api/v1/knowledge/:knowledgeId`
- Retry a failed duplicate: POST `/api/v1/knowledge/:knowledgeId/reparse`
- Create chat session: POST `/api/v1/sessions`
- Stream grounded answer: POST `/api/v1/agent-chat/:sessionId`
- Stop generation: POST `/api/v1/sessions/:sessionId/stop`
- Read-only service health: GET `/health`
- Selected-source retrieval: POST `/api/v1/knowledge-search` with `query`, `knowledge_base_id`, and explicit `knowledge_ids`

The agent-chat payload uses explicit selected `knowledge_ids`, `agent_id: builtin-smart-reasoning`, web search disabled, and empty external MCP/skill selections. The original worker maps returned knowledge IDs back to the accepted document selection and decodes page citations into durable message parts.

## Existing Compose topology

The pinned Compose configuration uses `wechatopenai/weknora-app:v0.6.1` at `http://weknora_app:8080`, exposed only inside its Docker network. Dependencies are PostgreSQL 17/ParadeDB, Redis 7, Qdrant 1.16.2, the WeKnora docreader, and the existing model proxy. Caddy forwards `/api/chat/*` to `aitlau_chat:8100`; it does not expose the WeKnora REST service. The Python worker's public code only defines health/readiness and internal wake endpoints; document chat is driven through Supabase durable jobs and Realtime.

Model traffic uses `http://aitlau_model_proxy:8110/v1`. Built-in model IDs are `aitlau-local-chat` and `aitlau-local-embedding`; the default embedding model is `qwen_0.6b_embedding`. A Qwen 3.6 27B chat API alone does not supply the knowledge service or necessarily an embedding endpoint.

## Teammate host checks

1. Locate the existing checkout and inspect existing container names, health and nonsecret network/port metadata. Do not dump resolved Compose configuration, environment values, passwords, API keys or tokens.
2. Check WeKnora's `/health` from its existing Docker network through a supported local route. Do not scan ports or publish a new public endpoint.
3. Reuse the existing application's tenant access internally. The original client can register a tenant on failed login; do not invoke that fallback or create new credentials.
4. Reuse existing document-to-knowledge mappings and actual ready indexes where possible. Preserve page Markdown headings, accepted source selection, source hashes, version identity, citation decoding and stop/retry behavior.
5. Retain the Taotern GUI. Wire a verified local HTTP adapter or the original durable backend behind it, preserving owner/project scope. Do not replace working retrieval until a real source upload/index/query/citation round trip passes.
6. Verify the existing model and embedding endpoints without revealing credentials. No new paid infrastructure, model subscription, account, credential or public exposure is authorized by this handoff.

No existing external WeKnora URL was verified from the cloud source or available connectors. A Sites Worker cannot directly host the original Go/PostgreSQL/Redis/Qdrant service. The owner's approved existing local Docker route is therefore the faithful reuse path to inspect first.


## Packaged GUI adapter

The local installer supplies `RETRIEVAL_BACKEND=weknora` and the existing internal `WEKNORA_BASE_URL=http://weknora_app:8080`. The operator supplies an existing tenant API key and existing knowledge-base ID locally. Missing access is an explicit configuration error; the adapter never calls registration, KB creation, model creation, or failed-source reparse automatically.

- Authenticated GET `/api/search/weknora` checks the existing service health and selected KB access. This is readiness only, not an index/query acceptance claim.
- Authenticated POST `/api/search/weknora` takes `{project_id,document_ids,public_data_acknowledged:true}`. Each call uploads or polls one owned, ready source version. Repeat calls until `remaining_documents` is zero. The response reports document counts, not Gemini chunk/vector counts.
- Page Markdown uses the pinned original `# title` and `## Page N` headings. The new isolated D1 stores a document/source-hash/version to WeKnora knowledge-ID mapping. The original WeKnora and Supabase schemas are untouched.
- Acknowledged local search uses explicit accepted knowledge IDs. Returned passages must map to a literal stored chunk/page before the GUI can link them. Unmapped passages are discarded. Retrieval is labelled WeKnora; no independent vector-only or score-method claim is made.
- Explicit keyword mode retains deterministic native lexical retrieval and makes no WeKnora request. Non-keyword local search uses the existing private backend when the server verifies the owner-Docker data policy; it does not require calling private material public. Public/synthetic policy still requires acknowledgement. The cloud default backend remains unchanged.

## Host acceptance and stopping conditions

After installation, open the loopback GUI, select a project and original synthetic PDF, check service readiness, and build the WeKnora document index. Record the actual response until all selected documents are ready. Ask a keyword question and a paraphrased question with source acknowledgement; open every cited page and compare the exact text to the PDF. Verify an unrelated project cannot retrieve the indexed source without explicit outside-project scope. Restart only the new GUI container and repeat the scoped query to prove mapping/state persistence.

A successful parse alone is not a successful query/citation round trip. `host_verified` and `host_index_query_verified` remain false in readiness/index responses; record the actual host receipts separately. The eight adapter tests mock HTTP and validate request/envelope restrictions only. No actual existing-host WeKnora success has been observed in the cloud workspace.
