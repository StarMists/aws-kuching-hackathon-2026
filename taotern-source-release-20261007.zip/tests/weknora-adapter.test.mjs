import test from 'node:test';
import assert from 'node:assert/strict';
import { WeKnoraClient, extractKnowledgeId, parseKnowledgeStatus, readWeKnoraConfig, weknoraSearchAllowed } from '../lib/retrieval/weknora-client.ts';
const config = () => ({enabled:true,base_url:'http://weknora_app:8080',api_key:'synthetic-test-key',knowledge_base_id:'kb-owned',timeout_ms:1000});
test('local adapter accepts verified compose name and rejects remote plaintext/URL credentials',()=>{
 assert.equal(readWeKnoraConfig({RETRIEVAL_BACKEND:'weknora',WEKNORA_BASE_URL:'http://weknora_app:8080'}).enabled,true);
 for(const url of ['http://remote.example.com','https://user:password@example.com','file:///tmp/data'])assert.throws(()=>readWeKnoraConfig({RETRIEVAL_BACKEND:'weknora',WEKNORA_BASE_URL:url}),error=>error.code==='WEKNORA_CONFIG_INVALID');
});
test('MOCK ONLY: existing index upload preserves original route and never registers a tenant',async()=>{
 const calls=[];const client=new WeKnoraClient(config(),async(url,init)=>{calls.push({url,init});assert.ok(init.body instanceof FormData);assert.equal(init.body.get('file').type,'text/markdown');return Response.json({data:{id:'knowledge-a',parse_status:'pending'}});});
 const result=await client.uploadMarkdown('owned-doc.md','# Source\n\n## Page 2\n\nActual page text');
 assert.equal(result.knowledge_id,'knowledge-a');assert.equal(result.parse_status,'pending');assert.equal(calls.length,1);assert.equal(calls[0].url,'http://weknora_app:8080/api/v1/knowledge-bases/kb-owned/knowledge/file');assert.equal(new Headers(calls[0].init.headers).get('X-API-Key'),'synthetic-test-key');
 assert.ok(!calls.some(call=>call.url.includes('/auth/')));
});
test('MOCK ONLY: original duplicate-file response reuses existing knowledge identity without creating anything',async()=>{
 const client=new WeKnoraClient(config(),async()=>Response.json({code:'duplicate_file',data:{knowledge_id:'already-indexed',parse_status:'completed'}},{status:409}));
 assert.deepEqual(await client.uploadMarkdown('doc.md','content'),{knowledge_id:'already-indexed',parse_status:'completed'});
});
test('MOCK ONLY: search uses an explicit selected knowledge list and original API envelope',async()=>{
 let body;const client=new WeKnoraClient(config(),async(url,init)=>{assert.match(url,/\/api\/v1\/knowledge-search$/);body=JSON.parse(init.body);return Response.json({data:[{knowledge_id:'k-a',content:'Actual source',score:.9}]});});
 const rows=await client.search('question',['k-a','k-b']);assert.equal(rows.length,1);assert.deepEqual(body.knowledge_ids,['k-a','k-b']);assert.equal(body.knowledge_base_id,'kb-owned');
});
test('MOCK ONLY: empty source list causes no retrieval request',async()=>{
 let calls=0;const client=new WeKnoraClient(config(),async()=>{calls++;return Response.json({data:[]});});assert.deepEqual(await client.search('query',[]),[]);assert.equal(calls,0);
});
test('MOCK ONLY: missing tenant access and rejected auth fail without registration or error-body disclosure',async()=>{
 let calls=0;const missing=new WeKnoraClient({...config(),api_key:''},async()=>{calls++;return Response.json({});});await assert.rejects(()=>missing.search('query',['k']),error=>error.code==='WEKNORA_NOT_CONFIGURED');assert.equal(calls,0);
 const rejected=new WeKnoraClient(config(),async()=>new Response('secret echoed upstream',{status:401}));await assert.rejects(()=>rejected.search('query',['k']),error=>error.code==='WEKNORA_AUTH_REJECTED'&&!error.message.includes('secret echoed'));
});
test('MOCK ONLY: agent payload preserves pinned source-only restrictions',async()=>{
 let body;const client=new WeKnoraClient(config(),async(url,init)=>{body=JSON.parse(init.body);return new Response('event: answer\ndata: {}\n\n',{headers:{'content-type':'text/event-stream'}});});
 await client.agentChat('session-a','question',['k-a']);assert.equal(body.web_search_enabled,false);assert.deepEqual(body.mcp_service_ids,[]);assert.deepEqual(body.skill_names,[]);assert.deepEqual(body.knowledge_ids,['k-a']);assert.equal(body.agent_id,'builtin-smart-reasoning');
});
test('original common knowledge/status envelopes are decoded exactly',()=>{
 assert.equal(extractKnowledgeId({data:{knowledgeId:'k-a'}}),'k-a');assert.equal(parseKnowledgeStatus({data:{parse_status:'COMPLETED'}}),'completed');assert.equal(extractKnowledgeId({data:{}}),null);
});

test('server-owned private Docker policy enables existing retrieval without a public-data assertion; keyword remains native',()=>{
 assert.equal(weknoraSearchAllowed(true,'hybrid',false,'owner-docker-only'),true);
 assert.equal(weknoraSearchAllowed(true,'hybrid',false,'public-synthetic-only'),false);
 assert.equal(weknoraSearchAllowed(true,'hybrid',true,'public-synthetic-only'),true);
 assert.equal(weknoraSearchAllowed(true,'keyword',true,'owner-docker-only'),false);
 assert.equal(weknoraSearchAllowed(false,'hybrid',true,'owner-docker-only'),false);
});
