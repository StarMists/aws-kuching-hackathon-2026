/** Interface adapter for the unchanged original AITLAU Supabase/Python OCR runtime. */
import { env } from 'cloudflare:workers';
import { ApiError } from '../http';
import { bucket } from '../db';
import type { Document, TaskStatus } from '../contracts';
import type { IngestionPage, IngestionRequest } from './limits';
import { bytesToBase64 } from './images';
const configuration=()=>{const values=env as unknown as Record<string,unknown>;return {enabled:values.AITLAU_OCR_BACKEND==='original'||values.AI_PROVIDER==='owner',url:String(values.AITLAU_LOCAL_BRIDGE_URL||''),token:String(values.AITLAU_LOCAL_BRIDGE_TOKEN||'')};};
export function originalOCRConfigured():boolean{return configuration().enabled;}
interface OriginalTask {id:string;status:TaskStatus;metadata?:Record<string,unknown>;}
interface OriginalPage {id:string;document_id:string;page_number:number;markdown_content:string;ocr_metadata:Record<string,unknown>;}
interface OriginalResult {task:OriginalTask;document?:{id:string;total_pages:number;metadata?:Record<string,unknown>}|null;pages?:OriginalPage[];source_pages?:number[];source_sha256?:string;}
async function request(id:string,method='GET',suffix='',body?:unknown):Promise<OriginalResult>{
 const c=configuration();if(!c.enabled||!c.url||!c.token)throw new ApiError(503,'ORIGINAL_OCR_NOT_CONFIGURED','The original AITLAU OCR queue adapter is unavailable. The source is retained for retry.');
 const url=new URL(c.url);if(url.protocol!=='http:'||!['127.0.0.1','localhost','[::1]'].includes(url.hostname))throw new ApiError(503,'ORIGINAL_OCR_CONFIG_INVALID','The original OCR adapter must be a private local gateway.');
 const response=await fetch(`${c.url.replace(/\/$/,'')}/internal/ocr/jobs/${encodeURIComponent(id)}${suffix}`,{method,headers:{authorization:'Bearer '+c.token,...(body?{'content-type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{}),redirect:'error',signal:AbortSignal.timeout(method==='GET'?18_000:55_000)}).catch(()=>{throw new ApiError(503,'ORIGINAL_OCR_UNREACHABLE','The existing original OCR service could not be reached. The source is retained for retry.');});
 const text=await response.text();if(text.length>8_000_000)throw new ApiError(502,'ORIGINAL_OCR_RESPONSE_LIMIT','The original OCR result is too large.');
 let payload:OriginalResult&{error?:{code?:string;message?:string}};try{payload=JSON.parse(text);}catch{throw new ApiError(502,'ORIGINAL_OCR_INVALID_RESPONSE','The original OCR gateway returned invalid JSON.');}
 if(!response.ok)throw new ApiError(response.status,payload.error?.code||'ORIGINAL_OCR_FAILED',payload.error?.message||'The original OCR gateway rejected the request.');
 if(!payload.task||payload.task.id!==id||!['idle','queued','processing','completed','failed','stopped'].includes(payload.task.status))throw new ApiError(502,'ORIGINAL_OCR_INVALID_RESPONSE','The original OCR task identity or status is invalid.');return payload;
}
export async function originalOCRAction(id:string,action:'stop'|'retry'):Promise<void>{await request(id,'POST','/'+action);}
export async function processOriginalOCR(id:string,document:Document,input:IngestionRequest,sourcePages:IngestionPage[]):Promise<{status:TaskStatus;pages:IngestionPage[];model:string|null;error:string|null}>{
 if(!input.public_data_acknowledged)throw new ApiError(400,'PUBLIC_DATA_ACK_REQUIRED','Confirm provider processing of this source before queueing the original OCR engine.');
 if(!document.r2_key||!document.source_sha256)throw new ApiError(409,'SOURCE_MISSING','The private original source is missing.');
 const source=await bucket().get(document.r2_key);if(!source)throw new ApiError(409,'SOURCE_MISSING','The retained original source is unavailable.');
 const pageImages=[];
 for(const page of sourcePages){if(!page.image_r2_key||page.image_content_type!=='image/jpeg')throw new ApiError(400,'ORIGINAL_OCR_JPEG_REQUIRED','Use the upload dialog to prepare exact scanned-page JPEGs for the original engine.');const image=await bucket().get(page.image_r2_key);if(!image||image.customMetadata?.source_sha256!==document.source_sha256)throw new ApiError(409,'SOURCE_IMAGE_MISSING','The retained page image is unavailable.');const bytes=new Uint8Array(await image.arrayBuffer());const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new Uint8Array(bytes).buffer))).map(byte=>byte.toString(16).padStart(2,'0')).join('');if(hash!==page.extraction_metadata?.source_artifact_sha256)throw new ApiError(409,'SOURCE_IMAGE_HASH_MISMATCH','The retained page image has changed.');pageImages.push({page_number:page.page_number,content_type:'image/jpeg',base64:bytesToBase64(bytes)});}
 await request(id,'POST','',{page_images:pageImages,document_id:document.id,title:document.title,filename:document.filename,source_sha256:document.source_sha256,content_type:document.content_type,source_pages:sourcePages.map(page=>page.page_number),source_base64:bytesToBase64(new Uint8Array(await source.arrayBuffer())),public_data_acknowledged:true});
 const result=await request(id);const hash=result.source_sha256||result.task.metadata?.taotern_source_sha256;
 if(hash!==document.source_sha256)throw new ApiError(409,'ORIGINAL_OCR_HASH_MISMATCH','The original engine result belongs to another retained source.');
 if(['failed','stopped'].includes(result.task.status))return {status:result.task.status,pages:[],model:null,error:'The original AITLAU OCR task '+result.task.status+'. Check the existing worker task metadata and retry the same source.'};
 if(result.task.status!=='completed')return {status:result.task.status,pages:[],model:null,error:null};
 const mapping=result.source_pages||[];const pages=result.pages||[];
 if(mapping.length!==sourcePages.length||pages.length!==mapping.length||new Set(mapping).size!==mapping.length||mapping.some(number=>!sourcePages.some(page=>page.page_number===number)))throw new ApiError(502,'ORIGINAL_OCR_PAGE_MAPPING_INVALID','The original OCR result does not match the requested source pages.');
 const mapped=pages.map(page=>{const number=mapping[page.page_number-1];if(!number||typeof page.markdown_content!=='string'||page.markdown_content.length>120000)throw new ApiError(502,'ORIGINAL_OCR_PAGE_INVALID','The original OCR page content is invalid.');const original=sourcePages.find(row=>row.page_number===number)!;return {...original,text:page.markdown_content,markdown:page.markdown_content,extraction_method:'vision_ocr' as const,extraction_metadata:{...original.extraction_metadata,original_engine:true,engine:'taotern_ocr.OCRPipeline/PageOCRGraph',original_task_id:id,original_document_id:result.document?.id,original_page_id:page.id,original_page_number:page.page_number,source_sha256:document.source_sha256,original_ocr_metadata:page.ocr_metadata,verification_status:'original_engine_reported'}};});
 return {status:'completed',pages:mapped,model:typeof result.document?.metadata?.model==='string'?result.document.metadata.model:null,error:null};
}
