import { env } from 'cloudflare:workers';
import type { Document, Page } from '../contracts';
import { all, db, first, now, ownedProject } from '../db';
import { ApiError } from '../http';
import { canonicalQuote } from '../intelligence/evidence';
import { buildCorpusScope, loadScopedCorpus } from './corpus';
import { groupSearchHits } from './ranking';
import { WeKnoraClient, parseKnowledgeStatus, readWeKnoraConfig } from './weknora-client';
import type { RankedSearchHit, RetrievalOptions, RetrievalResult } from './types';

export interface WeKnoraDocumentMapping { owner_id: string; document_id: string; source_sha256: string | null; version: string; knowledge_base_id: string; knowledge_id: string; status: string; updated_at: string }
export function weknoraClient(): WeKnoraClient { return new WeKnoraClient(readWeKnoraConfig(env as unknown as Record<string, unknown>)); }
export function weknoraEnabled(): boolean { return readWeKnoraConfig(env as unknown as Record<string, unknown>).enabled; }
export function documentMarkdown(document: Pick<Document, 'title'>, pages: Pick<Page, 'page_number' | 'text' | 'markdown'>[]): string {
  return [`# ${document.title}`, '', ...[...pages].sort((a, b) => a.page_number - b.page_number).flatMap(page => [`## Page ${page.page_number}`, '', page.markdown || page.text, ''])].join('\n');
}

/** One document upload/poll per call; parser progress is durable, not a fake ready flag. */
export async function indexWeKnoraSources(owner: string, projectId: string, documentIds?: string[]): Promise<{ total_documents: number; indexed_documents: number; remaining_documents: number; pending_document_id: string | null; backend: 'weknora'; host_verified: boolean }> {
  const options: RetrievalOptions = { query: '', project_id: projectId, document_ids: documentIds };
  const scope = await buildCorpusScope(owner, options); await ownedProject(owner, projectId);
  const documents = await all<Document>(`SELECT d.* FROM documents d WHERE ${scope.predicate} ORDER BY d.created_at`, ...scope.values);
  const client = weknoraClient();
  const mappings = await all<WeKnoraDocumentMapping>('SELECT * FROM weknora_documents WHERE owner_id=? AND knowledge_base_id=? AND document_id IN (SELECT value FROM json_each(?))', owner, client.config.knowledge_base_id, JSON.stringify(documents.map(document => document.id)));
  const ready = (document: Document) => mappings.some(mapping => mapping.document_id === document.id && mapping.source_sha256 === document.source_sha256 && mapping.version === document.version && mapping.status === 'ready');
  const pending = documents.find(document => !ready(document));
  if (pending) {
    let mapping = mappings.find(row => row.document_id === pending.id && row.source_sha256 === pending.source_sha256 && row.version === pending.version);
    if (!mapping) {
      const pages = await all<Page>('SELECT * FROM pages WHERE document_id=? ORDER BY page_number', pending.id);
      if (!pages.length) throw new ApiError(422, 'NO_SOURCE_EVIDENCE', 'The selected document has no stored source pages.');
      const upload = await client.uploadMarkdown(`${pending.id}.md`, documentMarkdown(pending, pages));
      const status = upload.parse_status === 'completed' ? 'ready' : ['failed', 'cancelled', 'canceled'].includes(upload.parse_status ?? '') ? 'failed' : 'processing';
      await db().prepare('INSERT INTO weknora_documents (owner_id,document_id,source_sha256,version,knowledge_base_id,knowledge_id,status,updated_at) VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(owner_id,document_id,source_sha256,version) DO UPDATE SET knowledge_base_id=excluded.knowledge_base_id,knowledge_id=excluded.knowledge_id,status=excluded.status,updated_at=excluded.updated_at').bind(owner, pending.id, pending.source_sha256, pending.version, client.config.knowledge_base_id, upload.knowledge_id, status, now()).run();
      mapping = { owner_id: owner, document_id: pending.id, source_sha256: pending.source_sha256, version: pending.version, knowledge_base_id: client.config.knowledge_base_id, knowledge_id: upload.knowledge_id, status, updated_at: now() };
    }
    const status = parseKnowledgeStatus(await client.knowledge(mapping.knowledge_id));
    if (['failed', 'cancelled', 'canceled'].includes(status ?? '')) { await db().prepare("UPDATE weknora_documents SET status='failed',updated_at=? WHERE owner_id=? AND document_id=? AND knowledge_id=?").bind(now(), owner, pending.id, mapping.knowledge_id).run(); throw new ApiError(503, 'WEKNORA_PARSE_FAILED', 'Existing WeKnora reported a failed/cancelled parse. Review it in the existing service; source text remains preserved.'); }
    if (status === 'completed') await db().prepare("UPDATE weknora_documents SET status='ready',updated_at=? WHERE owner_id=? AND document_id=? AND source_sha256 IS ? AND version=? AND knowledge_id=?").bind(now(), owner, pending.id, pending.source_sha256, pending.version, mapping.knowledge_id).run();
  }
  const indexed = await first<{ count: number }>(`SELECT COUNT(*) AS count FROM documents d JOIN weknora_documents w ON w.document_id=d.id AND w.owner_id=d.owner_id AND w.source_sha256 IS d.source_sha256 AND w.version=d.version WHERE ${scope.predicate} AND w.knowledge_base_id=? AND w.status='ready'`, ...scope.values, client.config.knowledge_base_id);
  const count = indexed?.count ?? 0;
  return { total_documents: documents.length, indexed_documents: count, remaining_documents: documents.length - count, pending_document_id: pending?.id ?? null, backend: 'weknora', host_verified: false };
}

export async function retrieveWeKnora(owner: string, options: RetrievalOptions): Promise<RetrievalResult> {
  // External relevance must not be prefiltered by the native lexical query.
  const corpus = await loadScopedCorpus(owner, { ...options, query: '' });
  const client = weknoraClient();
  const mappings = await all<WeKnoraDocumentMapping>('SELECT * FROM weknora_documents WHERE owner_id=? AND knowledge_base_id=? AND status=\'ready\' AND document_id IN (SELECT value FROM json_each(?))', owner, client.config.knowledge_base_id, JSON.stringify(corpus.documents.map(document => document.id)));
  const valid = mappings.filter(mapping => corpus.documents.some(document => document.id === mapping.document_id && document.source_sha256 === mapping.source_sha256 && document.version === mapping.version));
  if (!valid.length && corpus.documents.length) throw new ApiError(409, 'WEKNORA_INDEX_REQUIRED', 'Index the selected source versions into the existing WeKnora service before searching them. The current native search is preserved when this backend is not selected.');
  const rows = await client.search(options.query, valid.map(mapping => mapping.knowledge_id), options.signal);
  const pages = await all<Page>('SELECT p.* FROM pages p JOIN documents d ON d.id=p.document_id WHERE d.owner_id=? AND p.document_id IN (SELECT value FROM json_each(?))', owner, JSON.stringify(valid.map(mapping => mapping.document_id)));
  const hits: RankedSearchHit[] = [];
  for (const row of rows) {
    const mapping = valid.find(value => value.knowledge_id === row.knowledge_id);
    if (!mapping || typeof row.content !== 'string') continue;
    const candidates = corpus.chunks.filter(chunk => chunk.document_id === mapping.document_id);
    const fragments = [row.content, ...row.content.split(/\n+|(?<=[.!?。！？])\s+/u).filter(text => text.trim().length >= 12)].map(text => text.replace(/^#{1,6}\s+.*\n?/gmu, '').trim()).filter(Boolean).slice(0, 40);
    let matched = false;
    for (const chunk of candidates) {
      const page = pages.find(value => value.id === chunk.page_id); if (!page) continue;
      const quote = fragments.map(fragment => canonicalQuote(chunk.text, fragment, page.text)).find(Boolean); if (!quote) continue;
      const source = `/api/documents/${encodeURIComponent(chunk.document_id)}`;
      hits.push({ chunk_id: chunk.id, document_id: chunk.document_id, document_title: chunk.document_title, filename: chunk.filename, page_number: chunk.page_number, text: chunk.text, score: typeof row.score === 'number' && Number.isFinite(row.score) ? row.score : 0, lexical_score: 0, matched_terms: [], mode: 'weknora', source_date: chunk.source_date, version: chunk.version, document_type: chunk.document_type, department: chunk.department, source_sha256: chunk.source_sha256, source_url: source, file_url: source + '/file', citation_url: `${source}?page=${chunk.page_number}&chunk=${encodeURIComponent(chunk.id)}` }); matched = true; break;
    }
    if (!matched) continue; // Never invent a D1 chunk/page citation for an external passage.
  }
  const unique = [...new Map(hits.map(hit => [hit.chunk_id, hit])).values()].sort((a, b) => b.score - a.score).slice(0, options.limit ?? 20);
  const warning = 'Ranked passages came from the existing WeKnora knowledge-search API and were matched back to exact owned source chunks/pages. The server does not report a verified keyword/vector breakdown; no vector-only claim is made.';
  return { results: unique, documents: groupSearchHits(unique), mode: 'weknora', requested_mode: options.mode ?? 'hybrid', semantic_available: false, semantic_indexed_chunk_count: 0, query_expansion_available: false, expanded_terms: [], scope: { type: options.document_ids ? 'selection' : options.project_id && !options.allow_outside_project ? 'project' : 'library', project_id: options.project_id ?? null, outside_project: Boolean(options.project_id && options.allow_outside_project) }, coverage: { selected_document_count: corpus.documents.length, eligible_document_count: valid.length, candidate_chunk_count: rows.length, total_chunk_count: corpus.total_chunk_count, truncated: corpus.truncated || valid.length < corpus.documents.length }, warnings: [warning, ...corpus.warnings], warning, provider: 'weknora', model: 'existing-knowledge-search' };
}
