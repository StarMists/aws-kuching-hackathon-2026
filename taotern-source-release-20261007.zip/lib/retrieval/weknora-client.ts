/** HTTP reuse of the pinned AITLAU WeKnora client. No registration or credential minting. */
import { ApiError } from '../http';

export interface WeKnoraConfig { enabled: boolean; base_url: string; api_key: string; knowledge_base_id: string; timeout_ms: number }
export interface WeKnoraSearchRow { id?: string; knowledge_id?: string; content?: string; score?: number; metadata?: Record<string, unknown>; [key: string]: unknown }
const setting = (environment: Record<string, unknown>, key: string) => typeof environment[key] === 'string' ? (environment[key] as string).trim() : '';

export function readWeKnoraConfig(environment: Record<string, unknown>): WeKnoraConfig {
  const enabled = setting(environment, 'RETRIEVAL_BACKEND') === 'weknora';
  const base = setting(environment, 'WEKNORA_BASE_URL').replace(/\/+$/u, '');
  if (base) {
    let url: URL; try { url = new URL(base); } catch { throw new ApiError(503, 'WEKNORA_CONFIG_INVALID', 'Configure a valid existing WeKnora server URL.'); }
    const local = ['localhost', '127.0.0.1', '[::1]', 'weknora_app', 'aitlau-weknora-app', 'host.docker.internal'].includes(url.hostname);
    if (url.username || url.password || url.search || url.hash || (url.protocol !== 'https:' && !(url.protocol === 'http:' && local))) throw new ApiError(503, 'WEKNORA_CONFIG_INVALID', 'Use HTTPS for a remote WeKnora service or the existing private Docker/loopback address. Credentials must not be in the URL.');
  }
  return { enabled, base_url: base, api_key: setting(environment, 'WEKNORA_API_KEY'), knowledge_base_id: setting(environment, 'WEKNORA_KNOWLEDGE_BASE_ID'), timeout_ms: 18000 };
}

function dataObject(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
  const object = value as Record<string, unknown>;
  return object.data && typeof object.data === 'object' && !Array.isArray(object.data) ? object.data as Record<string, unknown> : object;
}
export function extractKnowledgeId(value: unknown): string | null {
  const object = dataObject(value);
  for (const key of ['knowledge_id', 'knowledgeId', 'id']) if (typeof object[key] === 'string' && object[key]) return object[key] as string;
  return null;
}
export function parseKnowledgeStatus(value: unknown): string | null {
  const object = dataObject(value);
  return typeof object.parse_status === 'string' ? object.parse_status.toLowerCase() : null;
}

/** The data policy is server-derived; a client cannot grant private Docker access. */
export function weknoraSearchAllowed(enabled: boolean, mode: string, acknowledged: boolean, serverDataPolicy?: string): boolean {
  return enabled && mode !== 'keyword' && (acknowledged || serverDataPolicy === 'owner-docker-only');
}

export class WeKnoraClient {
  constructor(readonly config: WeKnoraConfig, private fetcher: typeof fetch = fetch) {}
  private configured(): void {
    if (!this.config.enabled || !this.config.base_url || !this.config.api_key || !this.config.knowledge_base_id) throw new ApiError(503, 'WEKNORA_NOT_CONFIGURED', 'Configure the existing WeKnora URL, tenant API key and knowledge-base ID. No new tenant will be created.');
  }
  private async request(path: string, init: RequestInit = {}, authenticated = true): Promise<Response> {
    if (authenticated) this.configured();
    const headers = new Headers(init.headers);
    if (authenticated) headers.set('X-API-Key', this.config.api_key);
    const controller = new AbortController(), timer = setTimeout(() => controller.abort(), this.config.timeout_ms);
    const abort = () => controller.abort(); init.signal?.addEventListener('abort', abort, { once: true });
    try {
      const response = await this.fetcher(this.config.base_url + path, { ...init, headers, redirect: 'error', signal: controller.signal });
      return response;
    } catch { throw new ApiError(503, 'WEKNORA_UNREACHABLE', 'The existing WeKnora service could not be reached. Check its Docker network and health.'); }
    finally { clearTimeout(timer); init.signal?.removeEventListener('abort', abort); }
  }
  private async json(response: Response): Promise<unknown> {
    if (!response.ok && response.status !== 409) throw new ApiError(503, response.status === 401 || response.status === 403 ? 'WEKNORA_AUTH_REJECTED' : response.status === 404 ? 'WEKNORA_ENDPOINT_NOT_FOUND' : 'WEKNORA_SERVICE_ERROR', `Existing WeKnora returned HTTP ${response.status}. No upstream response or credential was logged.`);
    const text = await response.text();
    if (text.length > 1_000_000) throw new ApiError(502, 'WEKNORA_RESPONSE_TOO_LARGE', 'The WeKnora response exceeded the bounded response size.');
    try { return JSON.parse(text); } catch { throw new ApiError(502, 'WEKNORA_INVALID_RESPONSE', 'Existing WeKnora returned invalid JSON.'); }
  }
  async health(): Promise<{ reachable: boolean }> {
    if (!this.config.base_url) throw new ApiError(503, 'WEKNORA_NOT_CONFIGURED', 'Configure the existing WeKnora URL.');
    const response = await this.request('/health', {}, false);
    if (!response.ok) throw new ApiError(503, 'WEKNORA_UNREACHABLE', `Existing WeKnora health returned HTTP ${response.status}.`);
    return { reachable: true };
  }
  async checkKnowledgeBase(): Promise<unknown> { return this.json(await this.request(`/api/v1/knowledge-bases/${encodeURIComponent(this.config.knowledge_base_id)}`)); }
  async uploadMarkdown(filename: string, markdown: string): Promise<{ knowledge_id: string; parse_status: string | null }> {
    const form = new FormData(); form.set('file', new Blob([markdown], { type: 'text/markdown' }), filename);
    const response = await this.request(`/api/v1/knowledge-bases/${encodeURIComponent(this.config.knowledge_base_id)}/knowledge/file`, { method: 'POST', body: form });
    const payload = await this.json(response);
    if (response.status === 409 && (!payload || typeof payload !== 'object' || (payload as Record<string, unknown>).code !== 'duplicate_file')) throw new ApiError(409, 'WEKNORA_UPLOAD_CONFLICT', 'Existing WeKnora rejected the source upload.');
    const id = extractKnowledgeId(payload); if (!id) throw new ApiError(502, 'WEKNORA_INVALID_RESPONSE', 'The existing WeKnora upload did not return a knowledge ID.');
    return { knowledge_id: id, parse_status: parseKnowledgeStatus(payload) };
  }
  async knowledge(id: string): Promise<unknown> { return this.json(await this.request(`/api/v1/knowledge/${encodeURIComponent(id)}`)); }
  async search(query: string, knowledgeIds: string[], signal?: AbortSignal): Promise<WeKnoraSearchRow[]> {
    if (!knowledgeIds.length) return [];
    const payload = await this.json(await this.request('/api/v1/knowledge-search', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ query, knowledge_base_id: this.config.knowledge_base_id, knowledge_ids: knowledgeIds }), signal }));
    const values = payload && typeof payload === 'object' && 'data' in payload ? (payload as { data: unknown }).data : null;
    if (!Array.isArray(values)) throw new ApiError(502, 'WEKNORA_INVALID_RESPONSE', 'Existing WeKnora search returned an unsupported result envelope.');
    return values.filter((value): value is WeKnoraSearchRow => Boolean(value && typeof value === 'object')).slice(0, 100);
  }
  async createSession(): Promise<string> {
    const payload = await this.json(await this.request('/api/v1/sessions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }));
    const id = extractKnowledgeId(payload); if (!id) throw new ApiError(502, 'WEKNORA_INVALID_RESPONSE', 'Existing WeKnora did not return a session ID.'); return id;
  }
  async agentChat(sessionId: string, query: string, knowledgeIds: string[], signal?: AbortSignal): Promise<Response> {
    if (!knowledgeIds.length) throw new ApiError(400, 'NO_SOURCE_DOCUMENTS', 'WeKnora chat requires an explicit selected source list.');
    const response = await this.request(`/api/v1/agent-chat/${encodeURIComponent(sessionId)}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ query, knowledge_ids: knowledgeIds, agent_enabled: true, agent_id: 'builtin-smart-reasoning', web_search_enabled: false, mcp_service_ids: [], skill_names: [], mentioned_items: [], disable_title: true }), signal });
    if (!response.ok) await this.json(response); return response;
  }
  async stopSession(sessionId: string, messageId: string): Promise<void> { await this.json(await this.request(`/api/v1/sessions/${encodeURIComponent(sessionId)}/stop`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message_id: messageId }) })); }
}
