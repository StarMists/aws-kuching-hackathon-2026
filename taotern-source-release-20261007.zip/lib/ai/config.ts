import { AIError, type AIConfig, type AIProviderName, type ProviderConfig } from './types';

export const DATA_POLICY_NOTICE = 'Only submit public or synthetic documents and prompts.';
const GEMINI_FREE_MODELS = new Set(['gemini-3.8-flash','gemini-3.5-flash-lite','gemini-3.1-flash-lite','gemini-3.7-flash','gemini-3.6-flash','gemini-3.5-flash']);
const GROQ_FREE_MODELS = new Set(['openai/gpt-oss-120b','openai/gpt-oss-20b','qwen/qwen3.8-27b']);
function setting(env:Record<string,unknown>,key:string) { const value=env[key]; return typeof value==='string' ? value.trim() : ''; }
function bound(env:Record<string,unknown>,key:string,otherwise:number,min:number,max:number) { const value=Number(setting(env,key)); return Number.isFinite(value)&&value>0 ? Math.max(min,Math.min(max,Math.floor(value))) : otherwise; }
function provider(env:Record<string,unknown>,name:AIProviderName):ProviderConfig|null {
  if(name==='owner'){
    if(setting(env,'MODEL_PROXY_ENABLED')!=='true'||setting(env,'MODEL_PROXY_PRIVATE_DOCKER')!=='true')throw new AIError('OWNER_API_DISABLED','The owner adapter is disabled until the existing private Docker proxy is configured.',503);
    const base=setting(env,'MODEL_PROXY_UPSTREAM_URL');
    if(base!=='http://aitlau_model_proxy:8110/v1'&&base!=='http://aitlau_model_proxy:8110/v1/')throw new AIError('OWNER_API_NOT_CONFIGURED','Use the configured original private Docker model-proxy service. Public endpoints require a separately authorized configuration.',503);
    const model=setting(env,'MODEL_PROXY_GENERATION_MODEL')||'model-proxy-managed';
    return {provider:'owner',model,vision_model:model,api_key:'',api_base_url:base,owner_dialect:'openai_compatible',private_docker:true};
  }
  if(name==='openai') return null; // Preserved adapter boundary; paid calls are deliberately not enabled.
  const key=setting(env,name==='gemini'?'GEMINI_API_KEY':'GROQ_API_KEY');
  if(!key) return null;
  const model=setting(env,name==='gemini'?'GEMINI_MODEL':'GROQ_MODEL') || (name==='gemini'?'gemini-3.8-flash':'openai/gpt-oss-120b');
  const allowed=name==='gemini'?GEMINI_FREE_MODELS:GROQ_FREE_MODELS;
  if(!allowed.has(model)) throw new AIError('MODEL_NOT_APPROVED',`${name} model is outside the configured free-model allowlist.`,503);
  const visionModel=setting(env,name==='gemini'?'GEMINI_VISION_MODEL':'GROQ_VISION_MODEL');
  if(visionModel && !(name==='gemini'?GEMINI_FREE_MODELS:GROQ_FREE_MODELS).has(visionModel)) throw new AIError('MODEL_NOT_APPROVED','The vision model is outside the configured free-model allowlist.',503);
  if(name==='groq'&&visionModel&&visionModel!=='qwen/qwen3.8-27b') throw new AIError('VISION_MODEL_UNSUPPORTED','The configured Groq model does not support images.',503);
  const apiMode=setting(env,'GEMINI_API_MODE')||'generate-content';
  if(name==='gemini'&&!['auto','interactions','generate-content'].includes(apiMode))throw new AIError('AI_API_MODE_UNSUPPORTED','Configure auto, interactions, or generate-content for the Gemini API mode.',503);
  return {provider:name,model,api_key:key,...(visionModel?{vision_model:visionModel}:{}),...(name==='gemini'?{api_mode:apiMode as ProviderConfig['api_mode']}:{})};
}
export function readAIConfig(env:Record<string,unknown>):AIConfig {
  const enabled=setting(env,'AI_ENABLED')==='true';
  const name=setting(env,'AI_PROVIDER') || 'gemini';
  if(name!=='gemini'&&name!=='groq'&&name!=='owner') throw new AIError('PROVIDER_NOT_APPROVED','Only the approved free Gemini and Groq providers are enabled.',503);
  const primary=provider(env,name);
  const fallback=name==='owner'?null:provider(env,name==='gemini'?'groq':'gemini');
  const embeddingModel=setting(env,'GEMINI_EMBEDDING_MODEL');
  if(embeddingModel && !['gemini-embedding-2','gemini-embedding-001'].includes(embeddingModel)) throw new AIError('EMBEDDING_MODEL_UNSUPPORTED','Configure a supported Gemini embedding model.',503);
  return {enabled,primary,fallback,embedding_model:embeddingModel||null,data_policy:name==='owner'?'owner-docker-only':'public-synthetic-only',timeout_ms:bound(env,'AI_TIMEOUT_MS',22000,1000,22000),max_input_tokens:bound(env,'AI_MAX_INPUT_TOKENS',5000,500,5500),max_output_tokens:bound(env,'AI_MAX_OUTPUT_TOKENS',1800,128,2000),max_retries:setting(env,'AI_MAX_RETRIES')==='0'?0:1};
}
export function publicAIConfig(config:AIConfig) {
  const active=config.primary||config.fallback;
  const vision=config.primary?.provider==='gemini'||!!config.primary?.vision_model||config.fallback?.provider==='gemini'||!!config.fallback?.vision_model;
  const recipients=[config.primary,config.fallback].filter((p):p is ProviderConfig=>!!p);
  const notice=config.data_policy==='owner-docker-only'?'This local mode calls the existing private Docker model proxy. The original backend controls its actual provider, model, credentials, retention and costs. The GUI does not receive upstream credentials. Gemini and Groq are not used by this mode.':[DATA_POLICY_NOTICE,...(recipients.some(p=>p.provider==='gemini')?['Configured Gemini generation or embeddings send data to Google. Free-tier prompts may be used to improve Google products.']:[]),...(recipients.some(p=>p.provider==='groq')?['Configured Groq generation or OCR sends data to Groq. Inference data is not retained by default; limited reliability or abuse logs may be retained for up to 30 days.']:[])].join(' ');
  return {ai_enabled:config.enabled,provider:active?.provider||'gemini',model:active?.model||'gemini-3.8-flash',gemini_api_mode:[config.primary,config.fallback].find(p=>p?.provider==='gemini')?.api_mode||'generate-content',configured:config.enabled&&!!active,embedding_configured:config.enabled&&!!config.embedding_model&&!![config.primary,config.fallback].find(p=>p?.provider==='gemini'),ocr_configured:config.enabled&&vision,data_policy:config.data_policy,data_policy_notice:notice,free_tier:config.data_policy!=='owner-docker-only',paid_calls_enabled:false,max_input_tokens:config.max_input_tokens,max_output_tokens:config.max_output_tokens,provider_model_verification:'configuration-only',fallback_configured:config.enabled&&!!config.fallback};
}
