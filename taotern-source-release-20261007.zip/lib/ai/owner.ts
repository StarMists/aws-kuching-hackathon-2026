/** Faithful Worker port of the existing shared model-proxy request normalizer.
 * Source: Docker-Deployment-main/aitlau_model_proxy/.../app.py prepare_chat_body.
 * This is the invocation boundary, not the Python OCR graph/runtime.
 */
import {AIError,type AIRequest,type ProviderConfig,type ProviderAdapter,type AIUsage} from './types';
import {boundedErrorPayload,sanitizedProviderError} from './errors';
import {estimateTokens} from './providers';
export type OwnerDialect='openai_compatible'|'openrouter';
export function prepareOwnerChatBody(body:Record<string,unknown>,model:string,dialect:OwnerDialect):Record<string,unknown> {
 const payload=JSON.parse(JSON.stringify(body)) as Record<string,unknown>;
 if(!Array.isArray(payload.messages))return payload;
 for(const message of payload.messages){if(message&&typeof message==='object'&&!('content' in message))message.content='';}
 if(model.trim())payload.model=model.trim();
 if(dialect==='openrouter'){
  for(const key of ['cache_prompt','thinking_budget_tokens','reasoning_format','chat_template_kwargs','parallel_tool_calls'])delete payload[key];
  if(payload.repeat_penalty!==undefined){payload.repetition_penalty=payload.repeat_penalty;delete payload.repeat_penalty;}
  const response=payload.response_format as Record<string,unknown>|undefined;
  if(response?.type==='json_schema'&&response.schema&&typeof response.schema==='object')payload.response_format={type:'json_schema',json_schema:{name:'taotern_ocr_response',strict:true,schema:response.schema}};
  const effort=payload.reasoning_effort;delete payload.reasoning_effort;
  if(typeof effort==='string'&&effort)payload.reasoning={effort};
  const existing=payload.provider;
  payload.provider={...(existing&&typeof existing==='object'&&!Array.isArray(existing)?existing:{}),require_parameters:false,allow_fallbacks:true,data_collection:'deny'};
 }
 return payload;
}
export function ownerCompletionEndpoint(base:string,privateDocker=false):string {
 let url:URL;try{url=new URL(base);}catch{throw new AIError('OWNER_API_ENDPOINT_INVALID','Configure the owner model API base URL.',503);}
 const host=url.hostname.toLowerCase();
 if(privateDocker&&url.origin==='http://aitlau_model_proxy:8110'&&!url.username&&!url.password&&!url.search&&!url.hash&&(url.pathname==='/v1'||url.pathname==='/v1/'||url.pathname==='/v1/chat/completions'))return 'http://aitlau_model_proxy:8110/v1/chat/completions';
 if(url.protocol!=='https:'||url.username||url.password||url.search||url.hash||host==='localhost'||host.endsWith('.local')||/^127\.|^10\.|^192\.168\.|^169\.254\.|^172\.(1[6-9]|2\d|3[01])\./.test(host)||host==='[::1]'||/^\[(?:fc|fd|fe80)/i.test(host))throw new AIError('OWNER_API_ENDPOINT_UNSAFE','The hosted app requires an approved public HTTPS model endpoint without credentials in its URL. Local Docker addresses cannot be used by this Worker.',503);
 url.pathname=url.pathname.replace(/\/$/,'');
 if(!url.pathname.endsWith('/chat/completions'))url.pathname+='/chat/completions';
 return url.toString();
}
export function ownerChatBody(request:AIRequest,config:ProviderConfig):Record<string,unknown> {
 const content=request.image?[{type:'text',text:request.system+'\n\n'+request.prompt},{type:'image_url',image_url:{url:`data:${request.image.mime_type};base64,${request.image.base64}`}}]:request.prompt;
 const messages=request.image?[{role:'user',content}]:[{role:'system',content:request.system},{role:'user',content}];
 const body={model:config.model,messages,max_tokens:request.max_output_tokens,stream:false,cache_prompt:false,thinking_budget_tokens:0,reasoning_effort:'none',chat_template_kwargs:{enable_thinking:false},...(request.schema?{response_format:{type:'json_schema',schema:request.schema}}:{})};
 return prepareOwnerChatBody(body,config.model,config.owner_dialect||'openai_compatible');
}
function number(value:unknown){return typeof value==='number'&&Number.isFinite(value)&&value>=0?Math.floor(value):0;}
export const ownerAdapter:ProviderAdapter={name:'owner',async generate(request,config,signal,fetcher){
 if(!config.api_base_url)throw new AIError('OWNER_API_NOT_CONFIGURED','The owner model endpoint has not been configured.',503);
 const started=Date.now();
 const response=await fetcher(ownerCompletionEndpoint(config.api_base_url,config.private_docker),{method:'POST',headers:{'Content-Type':'application/json',...(config.api_key?{Authorization:`Bearer ${config.api_key}`}:{})},body:JSON.stringify(ownerChatBody(request,config)),signal});
 if(!response.ok){const seconds=Number(response.headers.get('retry-after'));throw sanitizedProviderError(await boundedErrorPayload(response),response.status,'Owner model API',Number.isFinite(seconds)&&seconds>0?Math.min(300000,seconds*1000):null);}
 if(Number(response.headers.get('content-length'))>1000000)throw new AIError('AI_RESPONSE_TOO_LARGE','The owner model response exceeded the allowed size.',502);
 const raw=await response.text();if(raw.length>1000000)throw new AIError('AI_RESPONSE_TOO_LARGE','The owner model response exceeded the allowed size.',502);
 let value:Record<string,unknown>;try{value=JSON.parse(raw) as Record<string,unknown>;}catch{throw new AIError('AI_INVALID_RESPONSE','The owner model returned invalid JSON.',502);}
 const choices=Array.isArray(value.choices)?value.choices:[],choice=choices[0] as Record<string,unknown>|undefined,message=choice?.message as Record<string,unknown>|undefined;
 if(choice?.finish_reason!=='stop')throw new AIError('AI_INCOMPLETE_RESPONSE','The owner model did not finish within the bounded output budget.',502);
 const text=typeof message?.content==='string'?message.content:'';
 if(!text.trim())throw new AIError('AI_EMPTY_RESPONSE','The owner model returned no final answer.',502);
 if(/<think\b|<\/think>/i.test(text))throw new AIError('AI_REASONING_IN_FINAL_OUTPUT','The owner endpoint mixed reasoning into the final answer. Use its configured non-thinking response mode.',502);
 const u=value.usage as Record<string,unknown>|undefined,usage:AIUsage={input_tokens:number(u?.prompt_tokens),output_tokens:number(u?.completion_tokens),total_tokens:number(u?.total_tokens)};
 if(!usage.total_tokens){usage.input_tokens=estimateTokens(request.system+request.prompt+JSON.stringify(request.schema||{}))+(request.image?2048:0);usage.output_tokens=estimateTokens(text);usage.total_tokens=usage.input_tokens+usage.output_tokens;usage.estimated=true;}
 return {text,provider:'owner',model:typeof value.model==='string'?value.model:config.model,usage,latency_ms:Date.now()-started,api_transport:'owner-chat-completions',...(typeof value.id==='string'?{request_id:value.id}:{})};
}};
