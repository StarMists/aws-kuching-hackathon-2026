declare namespace Cloudflare {
 interface Env {
  DB?: D1Database;
  QA_ALLOWED_OWNER_ID?:string;
  AI_VISITOR_ENABLED?:string;
  BUCKET?: R2Bucket;
  AI_ENABLED?:string;
  AI_PROVIDER?:string;
  GEMINI_API_KEY?:string;
  GEMINI_MODEL?:string;
  GEMINI_EMBEDDING_MODEL?:string;
  GEMINI_API_MODE?:string;
  AI_TIMEOUT_MS?:string;
  AI_DAILY_TOKEN_BUDGET?:string;
  AI_GLOBAL_DAILY_TOKEN_BUDGET?:string;
  AI_VISITOR_DAILY_TOKEN_BUDGET?:string;
  AI_VISITOR_POOL_DAILY_TOKEN_BUDGET?:string;
  AI_VISITOR_REQUESTS_PER_MINUTE?:string;
  AI_MAX_ACTIVE_REQUESTS?:string;
  GROQ_API_KEY?:string;
  GROQ_MODEL?:string;
  GROQ_VISION_MODEL?:string;
  OPENAI_API_KEY?:string;
  OPENAI_MODEL?:string;
  AI_DAILY_REQUEST_LIMIT?:string;
  AI_DAILY_TOKEN_LIMIT?:string;
 }
}
