param([int]$Port=8788,[switch]$LiveAI)
$ErrorActionPreference='Stop'
$url="http://127.0.0.1:$Port"
for($i=0;$i -lt 90;$i++){try{$health=Invoke-RestMethod "$url/local-health";if($health.status -eq 'ready'){break}}catch{};Start-Sleep -Seconds 2}
if(-not $health){throw 'Local GUI runtime did not become ready. Original backend data was not changed.'}
$health|ConvertTo-Json
$root=Split-Path $PSScriptRoot -Parent;$compose=Join-Path $root '.taotern-install/compose.local.yaml'
$args=@('compose','-f',$compose,'exec','-T','taotern_ui','node','tests/run-host-verification.mjs','--base-url','http://127.0.0.1:8788')
if($LiveAI){$args+='--live-ai'}
& docker @args
Write-Host 'The report distinguishes PASS/FAIL/NOTRUN. Original model/OCR/WeKnora success requires actual host verification.'
