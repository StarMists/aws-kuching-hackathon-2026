#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
STACK="${1:-}"; if [ -z "$STACK" ]; then read -r -p 'Existing Docker-Deployment checkout: ' STACK; fi
STACK="$(cd "$STACK" && pwd)"; test -f "$STACK/compose.yaml" || { echo 'Original compose.yaml missing; no replacement will be created.' >&2; exit 1; }
PROJECT="${2:-$(sed -nE 's/^name:[[:space:]]*([a-zA-Z0-9_-]+).*/\1/p' "$STACK/compose.yaml" | head -1)}"
mapfile -t IDS < <(docker ps --filter "label=com.docker.compose.project=$PROJECT" --format '{{.ID}}')
[ "${#IDS[@]}" -gt 0 ] || { echo 'Original project is not running; start it using its existing instructions.' >&2; exit 1; }
mapfile -t NETWORKS < <(for ID in "${IDS[@]}"; do docker inspect --format '{{range $k,$v := .NetworkSettings.Networks}}{{$k}}{{println}}{{end}}' "$ID"; done | sort -u)
if [ "${#NETWORKS[@]}" -eq 1 ]; then NETWORK="${NETWORKS[0]}"; else printf '%s\n' "${NETWORKS[@]}"; read -r -p 'Verified existing network: ' NETWORK; fi
printf '%s\n' "${NETWORKS[@]}" | grep -Fxq "$NETWORK" || exit 1
mkdir -p "$ROOT/.taotern-install"
F="$ROOT/.taotern-install/compose.local.yaml"
{
printf 'name: taotern-ui\nservices:\n  taotern_ui:\n    build:\n      context: "%s"\n      dockerfile: local-runtime/Dockerfile\n    restart: unless-stopped\n    ports: ["127.0.0.1:8788:8788"]\n    env_file:\n' "$ROOT"
for E in "$STACK/aitlau_supabase/.env" "$STACK/.env" "$ROOT/local.env"; do [ ! -f "$E" ] || printf '      - "%s"\n' "$E"; done
cat <<YAML
    environment:
      AI_ENABLED: "true"
      AI_PROVIDER: owner
      MODEL_PROXY_ENABLED: "true"
      MODEL_PROXY_PRIVATE_DOCKER: "true"
      MODEL_PROXY_UPSTREAM_URL: http://aitlau_model_proxy:8110/v1
      MODEL_PROXY_DIALECT: openai_compatible
      MODEL_PROXY_GENERATION_MODEL: model-proxy-managed
      AITLAU_SUPABASE_URL: http://api-gw:8000
      AITLAU_OCR_BASE_URL: http://aitlau_ocr:8000
      WEKNORA_BASE_URL: http://weknora_app:8080
      RETRIEVAL_BACKEND: weknora
    volumes: ["taotern_state:/data"]
    networks: [original]
networks:
  original:
    external: true
    name: "$NETWORK"
volumes:
  taotern_state:
    name: taotern-new-ui-state
YAML
} > "$F"
docker compose -f "$F" up -d --no-deps --build taotern_ui
printf '\nTaotern: http://127.0.0.1:8788\nOriginal services and data were not rebuilt or removed.\n'
