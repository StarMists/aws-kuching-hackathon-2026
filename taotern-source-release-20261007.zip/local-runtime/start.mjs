import {Miniflare} from 'miniflare';
import {createServer} from 'node:http';
import {readFile,readdir,mkdir} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {Readable} from 'node:stream';
import {randomUUID} from 'node:crypto';
import {handleOriginalOCR} from './original-ocr-gateway.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const state=path.resolve(process.env.TAOTERN_STATE_DIR||path.join(root,'taotern-state'));
const bootId=randomUUID();
const port=Number(process.env.TAOTERN_PORT||8788),owner=process.env.TAOTERN_LOCAL_OWNER_ID||'local-taotern-owner';
const client=path.join(root,'dist/client');
const allowed=/^(AI_|GEMINI_|GROQ_|MODEL_PROXY_|WEKNORA_|RETRIEVAL_BACKEND$|AITLAU_|LOCAL_)/;
const bindings=Object.fromEntries(Object.entries(process.env).filter(([key])=>allowed.test(key)));
bindings.QA_ALLOWED_OWNER_ID=owner;bindings.AI_VISITOR_ENABLED='false';bindings.AITLAU_LOCAL_BRIDGE_TOKEN=randomUUID();bindings.AITLAU_LOCAL_BRIDGE_URL=`http://127.0.0.1:${port}`;bindings.AITLAU_OCR_BACKEND=process.env.AITLAU_OCR_BACKEND||'original';process.env.AITLAU_LOCAL_BRIDGE_TOKEN=bindings.AITLAU_LOCAL_BRIDGE_TOKEN;
await mkdir(state,{recursive:true});
const mime={'.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.woff2':'font/woff2','.bcmap':'application/octet-stream'};
async function modulesIn(directory){const items=[];for(const entry of await readdir(directory,{withFileTypes:true})){const p=path.join(directory,entry.name);if(entry.isDirectory())items.push(...await modulesIn(p));else if(/\.m?js$/.test(p))items.push({type:'ESModule',path:p});}return items;}
const entry=path.join(root,'dist/server/index.js');const modules=await modulesIn(path.join(root,'dist/server'));modules.sort((a,b)=>(a.path===entry?-1:b.path===entry?1:0));
const mf=new Miniflare({modules,modulesRoot:root,compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],bindings,d1Databases:{DB:'taotern-local'},d1Persist:path.join(state,'d1'),r2Buckets:{BUCKET:'taotern-sources'},r2Persist:path.join(state,'r2'),serviceBindings:{ASSETS:async request=>{const name=decodeURIComponent(new URL(request.url).pathname);const target=path.resolve(client,'.'+name);if(!target.startsWith(client+path.sep))return new Response('Not found',{status:404});try{return new Response(await readFile(target),{headers:{'content-type':mime[path.extname(target)]||'application/octet-stream'}});}catch{return new Response('Not found',{status:404});}}}});
const db=await mf.getD1Database('DB');
await db.exec('CREATE TABLE IF NOT EXISTS taotern_local_migrations(name TEXT PRIMARY KEY,applied_at TEXT NOT NULL)');
for(const name of (await readdir(path.join(root,'drizzle'))).filter(x=>/^\d.*\.sql$/.test(x)).sort()){
 if(await db.prepare('SELECT name FROM taotern_local_migrations WHERE name=?').bind(name).first())continue;
 const sql=await readFile(path.join(root,'drizzle',name),'utf8');
 for(const statement of sql.split('--> statement-breakpoint').map(x=>x.trim()).filter(Boolean))await db.prepare(statement).run();
 await db.prepare('INSERT INTO taotern_local_migrations VALUES (?,?)').bind(name,new Date().toISOString()).run();
}
const server=createServer(async(req,res)=>{try{
 if(req.url==='/local-health'){res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify({status:'ready',boot_id:bootId,runtime:'Miniflare',storage:'isolated-local-D1-R2',authentication:'single-owner-loopback',no_original_data_migration:true}));return;}
 const headers=new Headers(req.headers);headers.set('oai-authenticated-user-id',owner);headers.set('oai-authenticated-user-email','local-owner@taotern.invalid');
 const method=req.method||'GET';let body; if(!['GET','HEAD'].includes(method)){const parts=[];let bytes=0;for await(const chunk of req){bytes+=chunk.length;if(bytes>48*1024*1024)throw new Error('Local request limit');parts.push(chunk);}body=Buffer.concat(parts);}const init={method,headers,...(body?{body}:{})};
 const url=`http://${req.headers.host||'127.0.0.1:'+port}${req.url}`;const original=req.url.startsWith('/internal/ocr/')?await handleOriginalOCR(new Request(url,init),process.env):null;const response=original||await mf.dispatchFetch(url,init);
 res.writeHead(response.status,Object.fromEntries(response.headers));if(response.body)Readable.fromWeb(response.body).pipe(res);else res.end();
}catch{res.writeHead(500,{'content-type':'application/json'});res.end(JSON.stringify({error:{code:'LOCAL_RUNTIME_FAILED',message:'Local runtime failed. Check the redacted verification report.'}}));}});
server.listen(port,process.env.TAOTERN_BIND_HOST||'127.0.0.1',()=>console.log(`Taotern local ready: http://127.0.0.1:${port} (isolated state; original services untouched)`));
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{server.close();void mf.dispose().then(()=>process.exit(0));});
