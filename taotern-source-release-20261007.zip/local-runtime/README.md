# Taotern portable local handoff

This release preserves the Taotern GUI and runs its compiled Worker in Miniflare with NEW isolated D1/R2 state. It attaches only a new loopback GUI adapter to an already-running original Docker-Deployment network. It does not rebuild, migrate, stop or delete the original Supabase, OCR, WeKnora, model proxy or their volumes.

Windows: run the repository's root Start.ps1. Linux: run local-runtime/install.sh /absolute/path/to/existing/Docker-Deployment [actual-compose-project]. The original checkout and running network are explicitly selected and checked, not guessed. The original pinned compose service names are reused for internal endpoints.

Optional configuration belongs in an untracked local.env: existing AITLAU_OWNER_ID (Supabase Auth UUID), WEKNORA_KNOWLEDGE_BASE_ID and existing WEKNORA_API_KEY if not already present. Existing backend env files are loaded by Docker locally; no secret is copied into source or a report. Never create a replacement user/tenant/key merely to pass a check.

Open http://127.0.0.1:8788. Only this loopback port is published. Authentication is a private single-owner local gateway, not public multi-user ChatGPT auth. The state volume taotern-new-ui-state is separate from the original application data. Stop only the new UI adapter with docker compose -f .taotern-install/compose.local.yaml stop taotern_ui. Do not use down -v, reset, or delete original volumes.

The existing model proxy controls the true model, credentials and cost. This GUI never copies its upstream key. Run the fixed model check and actual synthetic host verification; configuration alone is not a successful model/OCR/retrieval test. Missing original owner/service configuration is an explicit NOTRUN/blocker. Host Docker/Supabase/OCR/WeKnora validation must be performed on the teammate's already-ready machine; cloud tests do not certify that host.
