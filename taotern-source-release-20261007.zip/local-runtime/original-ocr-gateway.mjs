/** Thin adapter to the EXISTING AITLAU Supabase queue and aitlau-ocr container.
 * No new OCR engine, model server, schema or queue is created. */
import {createHash} from 'node:crypto';
const uuid=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const statuses=new Set(['idle','queued','processing','completed','failed','stopped']);
const json=(data,status=200)=>Response.json(data,{status,headers:{'cache-control':'no-store'}});
class GatewayError extends Error {constructor(status,code,message){super(message);this.status=status;this.code=code;}}
function config(env){
 const owner=env.AITLAU_OWNER_ID,base=(env.AITLAU_SUPABASE_URL||env.SUPABASE_URL||'').replace(/\/+$/,'');
 const key=env.AITLAU_SUPABASE_SERVICE_ROLE_KEY||env.SERVICE_ROLE_KEY||env.SUPABASE_SERVICE_ROLE_KEY;
 if(!uuid.test(owner||'')||!base||!key)throw new GatewayError(503,'ORIGINAL_OCR_NOT_CONFIGURED','Configure the existing Supabase URL, service-role environment and original owner UUID.');
 const url=new URL(base);if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.search||url.hash)throw new GatewayError(503,'ORIGINAL_OCR_CONFIG_INVALID','The existing Supabase URL is invalid.');
 return {owner,base,key,container:env.AITLAU_OCR_CONTAINER||'aitlau-ocr'};
}
async function upstream(c,path,init={}){
 const headers=new Headers(init.headers);headers.set('apikey',c.key);headers.set('authorization','Bearer '+c.key);
 const response=await fetch(c.base+path,{...init,headers,redirect:'error',signal:AbortSignal.timeout(12000)});
 if(!response.ok)throw new GatewayError(response.status===401||response.status===403?503:502,'ORIGINAL_OCR_SERVICE_ERROR',`Existing Supabase returned HTTP ${response.status}.`);
 const text=await response.text();if(text.length>8_000_000)throw new GatewayError(502,'ORIGINAL_OCR_RESPONSE_LIMIT','The original OCR response exceeded the bounded size.');return text?JSON.parse(text):null;
}
const rpc=(c,name,body)=>upstream(c,'/rest/v1/rpc/'+name,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});
const rows=(c,table,query)=>upstream(c,'/rest/v1/'+table+'?'+query);
const write=(c,table,body,method='POST',query='')=>upstream(c,'/rest/v1/'+table+query,{method,headers:{'content-type':'application/json',prefer:'return=representation'},body:JSON.stringify(body)});
async function owned(c,id){const result=await rows(c,'tasks',`id=eq.${id}&owner_id=eq.${c.owner}&select=*`);if(!result?.[0])throw new GatewayError(404,'ORIGINAL_OCR_TASK_NOT_FOUND','The original queue task was not found for this configured owner.');return result[0];}
/** Lossless JPEG container wrapping only. OCR remains the original Python graph. */
export function jpegPagesToPDF(images){
 const objects=[],pageIds=[];const add=bytes=>{objects.push(Buffer.isBuffer(bytes)?bytes:Buffer.from(bytes));return objects.length;};
 add('<< /Type /Catalog /Pages 2 0 R >>');add('');
 for(const image of images){
  const bytes=Buffer.from(image.base64||'','base64');let offset=2,width=0,height=0,colors=0;
  if(bytes[0]!==255||bytes[1]!==216)throw new GatewayError(400,'ORIGINAL_OCR_JPEG_REQUIRED','Prepare exact-page JPEG images with the upload dialog.');
  while(offset+4<bytes.length){if(bytes[offset]!==255){offset++;continue;}while(bytes[offset]===255)offset++;const marker=bytes[offset++];if(marker===217||marker===218)break;if(marker>=208&&marker<=215)continue;const length=bytes.readUInt16BE(offset);if(length<2||offset+length>bytes.length)break;if([192,193,194].includes(marker)){height=bytes.readUInt16BE(offset+3);width=bytes.readUInt16BE(offset+5);colors=bytes[offset+7];break;}offset+=length;}
  if(!width||!height||width*height>12000000||![1,3].includes(colors)||bytes.length>4194304)throw new GatewayError(400,'ORIGINAL_OCR_JPEG_INVALID','The exact-page JPEG dimensions or color format are unsupported.');
  const imageId=add(Buffer.concat([Buffer.from(`<< /Type /XObject /Subtype /Image /Width ${width} /Height ${height} /ColorSpace /${colors===1?'DeviceGray':'DeviceRGB'} /BitsPerComponent 8 /Filter /DCTDecode /Length ${bytes.length} >>\nstream\n`),bytes,Buffer.from('\nendstream')]));
  // Set a300-DPI physical page size; the original400-DPI renderer stays bounded.
  const widthPt=width*72/300,heightPt=height*72/300;
  const content=`q ${widthPt} 0 0 ${heightPt} 0 0 cm /Im0 Do Q`;
  const contentId=add(`<< /Length ${Buffer.byteLength(content)} >>\nstream\n${content}\nendstream`);
  pageIds.push(add(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${widthPt} ${heightPt}] /Resources << /XObject << /Im0 ${imageId} 0 R >> >> /Contents ${contentId} 0 R >>`));
 }
 objects[1]=Buffer.from(`<< /Type /Pages /Count ${pageIds.length} /Kids [${pageIds.map(id=>id+' 0 R').join(' ')}] >>`);
 const parts=[Buffer.from('%PDF-1.7\n%Taotern-JPEG-wrapper\n')],offsets=[0];let size=parts[0].length;
 objects.forEach((object,index)=>{offsets.push(size);const block=Buffer.concat([Buffer.from(`${index+1} 0 obj\n`),object,Buffer.from('\nendobj\n')]);parts.push(block);size+=block.length;});
 const xref=size;parts.push(Buffer.from(`xref\n0 ${objects.length+1}\n0000000000 65535 f \n${offsets.slice(1).map(offset=>String(offset).padStart(10,'0')+' 00000 n \n').join('')}trailer\n<< /Size ${objects.length+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`));return Buffer.concat(parts);
}
export async function handleOriginalOCR(request,env=process.env){
 const url=new URL(request.url),match=/^\/internal\/ocr\/jobs\/([a-f0-9-]{36})(?:\/(stop|retry))?$/.exec(url.pathname);if(!match)return null;
 if(!env.AITLAU_LOCAL_BRIDGE_TOKEN||request.headers.get('authorization')!=='Bearer '+env.AITLAU_LOCAL_BRIDGE_TOKEN)return json({error:{code:'LOCAL_BRIDGE_UNAUTHORIZED',message:'Local bridge authorization is required.'}},401);
 try{
 const c=config(env),id=match[1];if(!uuid.test(id))throw new GatewayError(400,'INVALID_TASK_ID','Use a valid task UUID.');
 if(request.method==='POST'&&!match[2]){
 const raw=await request.text();if(raw.length>65_000_000)throw new GatewayError(413,'ORIGINAL_OCR_SOURCE_LIMIT','The original source is too large.');const body=JSON.parse(raw);
 if(!body.public_data_acknowledged)throw new GatewayError(400,'PUBLIC_DATA_ACK_REQUIRED','Confirm provider processing of this source before queueing OCR.');
 const bytes=Buffer.from(body.source_base64||'','base64'),hash=createHash('sha256').update(bytes).digest('hex');
 const pages=body.source_pages;if(!bytes.length||bytes.length>20*1024*1024||hash!==body.source_sha256||!uuid.test(body.document_id||'')||!Array.isArray(pages)||!pages.length||pages.length>20||pages.some(n=>!Number.isSafeInteger(n)||n<1||n>80)||new Set(pages).size!==pages.length||!['application/pdf','image/jpeg','image/png','image/webp'].includes(body.content_type))throw new GatewayError(400,'ORIGINAL_OCR_SOURCE_INVALID','The retained original, hash or page mapping is invalid.');
 const existing=await rows(c,'tasks',`id=eq.${id}&select=*`);
 if(existing?.length){if(existing[0].owner_id!==c.owner||existing[0].metadata?.taotern_source_sha256!==hash)throw new GatewayError(409,'ORIGINAL_OCR_SOURCE_CONFLICT','This task ID is already associated with another original source.');return json({task:existing[0],source_pages:existing[0].metadata.taotern_source_pages});}
 if(!Array.isArray(body.page_images)||body.page_images.length!==pages.length||body.page_images.some((image,index)=>image.page_number!==pages[index]||image.content_type!=='image/jpeg'))throw new GatewayError(400,'ORIGINAL_OCR_JPEG_REQUIRED','Prepare exact scanned-page JPEGs using the upload dialog.');
 const pdf=jpegPagesToPDF(body.page_images),storagePath=`${c.owner}/taotern/${id}/${hash}.pdf`;
 await upstream(c,'/storage/v1/object/task-pdfs/'+storagePath,{method:'POST',headers:{'content-type':'application/pdf','x-upsert':'true'},body:pdf});
 const priorPdf=await rows(c,'pdf_files',`id=eq.${body.document_id}&select=id,storage_path`);
 if(priorPdf?.length&&priorPdf[0].storage_path!==storagePath)throw new GatewayError(409,'ORIGINAL_OCR_SOURCE_CONFLICT','The PDF ID belongs to another retained source.');
 if(!priorPdf?.length)await write(c,'pdf_files',{id:body.document_id,bucket_id:'task-pdfs',storage_path:storagePath,file_name:`${body.filename||'source'}.ocr.pdf`,mime_type:'application/pdf',size_bytes:pdf.length,page_count:pages.length,metadata:{taotern_source_sha256:hash,taotern_source_pages:pages,derived_pdf_sha256:createHash('sha256').update(pdf).digest('hex')}});
 await write(c,'tasks',{id,owner_id:c.owner,pdf_file_id:body.document_id,name:String(body.title||'Taotern source').slice(0,80),description:'Original AITLAU full-engine OCR via Taotern local adapter.',effort:'medium',status:'idle',metadata:{taotern_source_sha256:hash,taotern_source_document_id:body.document_id,taotern_source_pages:pages,original_engine:true}});
 await rpc(c,'enqueue_task',{p_task_id:id,p_queue_position:null});return json({task:await owned(c,id),source_pages:pages},202);
 }
 const task=await owned(c,id);
 if(request.method==='POST'&&match[2]==='stop'){
 if(task.status==='completed')throw new GatewayError(409,'TASK_COMPLETED','Completed original queue tasks cannot be stopped.');
 if(task.status==='queued')await rpc(c,'dequeue_task',{p_task_id:id});
 await write(c,'tasks',{status:'stopped',queue_position:null,claim_id:null,claimed_at:null},'PATCH',`?id=eq.${id}&owner_id=eq.${c.owner}&status=neq.completed`);return json({task:await owned(c,id)});
 }
 if(request.method==='POST'&&match[2]==='retry'){
 if(['failed','stopped'].includes(task.status))await write(c,'tasks',{status:'idle',queue_position:null,claim_id:null,claimed_at:null,completed_at:null},'PATCH',`?id=eq.${id}&owner_id=eq.${c.owner}&status=in.(failed,stopped)`);
 else if(task.status!=='idle')return json({task});
 await rpc(c,'enqueue_task',{p_task_id:id,p_queue_position:null});return json({task:await owned(c,id)});
 }
 if(request.method!=='GET')throw new GatewayError(405,'METHOD_NOT_ALLOWED','Use submit, poll, stop or retry.');
 if(!statuses.has(task.status))throw new GatewayError(502,'ORIGINAL_OCR_STATUS_INVALID','The original queue returned an unsupported status.');
 const documents=task.status==='completed'?await rows(c,'documents',`task_id=eq.${id}&creator_id=eq.${c.owner}&select=*`):[];
 const document=documents?.[0]||null,pages=document?await rows(c,'document_pages',`document_id=eq.${document.id}&order=page_number.asc&select=id,document_id,page_number,markdown_content,ocr_metadata`):[];
 return json({task,document,pages,source_pages:task.metadata?.taotern_source_pages||[],source_sha256:task.metadata?.taotern_source_sha256,engine:'original-taotern-ocr-full-graph',artifacts_retained_in_existing_worker:true});
 }catch(error){return json({error:{code:error instanceof GatewayError?error.code:'ORIGINAL_OCR_GATEWAY_FAILED',message:error instanceof GatewayError?error.message:'The original OCR gateway could not complete this request.'}},error instanceof GatewayError?error.status:503);}
}
