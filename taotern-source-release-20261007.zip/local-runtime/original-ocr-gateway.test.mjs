import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {handleOriginalOCR,jpegPagesToPDF} from './original-ocr-gateway.mjs';
const owner='c319686b-cc9d-442c-8cc4-d75e1d5f388b',id='a319686b-cc9d-442c-8cc4-d75e1d5f388b',doc='b319686b-cc9d-442c-8cc4-d75e1d5f388b';
const env={AITLAU_LOCAL_BRIDGE_TOKEN:'synthetic-mock-token',AITLAU_OWNER_ID:owner,AITLAU_SUPABASE_URL:'http://existing-supabase.invalid',SERVICE_ROLE_KEY:'synthetic-mock-key'};
const req=(suffix='',method='GET',body)=>new Request('http://127.0.0.1:8788/internal/ocr/jobs/'+id+suffix,{method,headers:{authorization:'Bearer '+env.AITLAU_LOCAL_BRIDGE_TOKEN},...(body?{body:JSON.stringify(body)}:{})});
test('actual original JPEG is embedded without lossy re-encoding',async()=>{const jpg=await readFile(new URL('../tests/fixtures/synthetic-civic/field-slip-photo.jpg',import.meta.url));const pdf=jpegPagesToPDF([{base64:jpg.toString('base64')}]);assert.ok(pdf.includes(jpg));assert.ok(pdf.toString('latin1').includes('/DCTDecode'));assert.throws(()=>jpegPagesToPDF([{base64:'bad'}]),/JPEG/);});
test('unauthorized gateway access never touches the original service',async()=>{const response=await handleOriginalOCR(new Request('http://127.0.0.1:8788/internal/ocr/jobs/'+id),env);assert.equal(response.status,401);});
test('MOCK ONLY submit and poll reuse original Supabase tables/RPC and exact source mapping',async()=>{
 const old=globalThis.fetch,calls=[];let task=null;const jpg=await readFile(new URL('../tests/fixtures/synthetic-civic/field-slip-photo.jpg',import.meta.url));const hash=createHash('sha256').update(jpg).digest('hex');
 globalThis.fetch=async(url,init={})=>{const u=new URL(url);calls.push({path:u.pathname,method:init.method||'GET'});let value=[];
 if(u.pathname==='/rest/v1/tasks'&&init.method==='POST'){task=JSON.parse(init.body);value=[task];}
 else if(u.pathname==='/rest/v1/tasks')value=task?[task]:[];
 else if(u.pathname==='/rest/v1/rpc/enqueue_task'){assert.equal(JSON.parse(init.body).p_task_id,id);task.status='queued';value=[{enqueued_task_id:id}];}
 else if(u.pathname==='/storage/v1/object/task-pdfs/'+owner+'/taotern/'+id+'/'+hash+'.pdf'){assert.ok(Buffer.from(init.body).includes(jpg));value={Key:'retained-pdf'};}
 else if(u.pathname==='/rest/v1/pdf_files'&&init.method==='POST'){const row=JSON.parse(init.body);assert.equal(row.page_count,1);assert.equal(row.id,doc);value=[row];}
 return Response.json(value);};
 try{const response=await handleOriginalOCR(req('','POST',{source_base64:jpg.toString('base64'),source_sha256:hash,document_id:doc,title:'Synthetic fixture',filename:'photo.jpg',content_type:'image/jpeg',source_pages:[5],page_images:[{page_number:5,content_type:'image/jpeg',base64:jpg.toString('base64')}],public_data_acknowledged:true}),env);assert.equal(response.status,202);assert.equal(task.owner_id,owner);assert.deepEqual(task.metadata.taotern_source_pages,[5]);assert.ok(calls.some(x=>x.path.endsWith('/rpc/enqueue_task')));
 const before=calls.filter(x=>x.method==='POST').length;const repeated=await handleOriginalOCR(req('','POST',{source_base64:jpg.toString('base64'),source_sha256:hash,document_id:doc,content_type:'image/jpeg',source_pages:[5],public_data_acknowledged:true}),env);assert.equal(repeated.status,200);assert.equal(calls.filter(x=>x.method==='POST').length,before);const polled=await handleOriginalOCR(req(),env);assert.equal(polled.status,200);assert.equal((await polled.json()).task.status,'queued');
 }finally{globalThis.fetch=old;}
});
