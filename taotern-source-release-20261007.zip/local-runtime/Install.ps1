param([string]$ExistingStack,[string]$Project,[int]$Port=8788)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
if(-not $ExistingStack){$ExistingStack=Read-Host 'Path to the EXISTING Docker-Deployment checkout (original data will not be changed)'}
$ExistingStack=(Resolve-Path $ExistingStack).Path
if(-not(Test-Path "$ExistingStack/compose.yaml")){throw 'Existing compose.yaml was not found. Do not initialize a replacement stack.'}
if(-not $Project){$line=Get-Content "$ExistingStack/compose.yaml" | Select-String '^name:\s*([A-Za-z0-9_-]+)' | Select-Object -First 1;$default=if($line){$line.Matches[0].Groups[1].Value}else{'aitlau'};$answer=Read-Host "Existing running Compose project [$default]";$Project=if($answer){$answer}else{$default}}
$ids=@(& docker ps --filter "label=com.docker.compose.project=$Project" --format '{{.ID}}')
if(-not $ids.Count){throw 'No running containers for that original project. Start the existing stack with its original instructions; this installer will not rebuild it.'}
$networks=@();foreach($id in $ids){$item=(& docker inspect --format '{{json .NetworkSettings.Networks}}' $id|ConvertFrom-Json);$networks+=$item.PSObject.Properties.Name}
$networks=@($networks|Select-Object -Unique);$network=if($networks.Count -eq 1){$networks[0]}else{Read-Host "Existing Docker network ($($networks -join ', '))"}
if($network -notin $networks){throw 'Choose a network verified on the existing containers.'}
$envFiles=@();foreach($p in @("$ExistingStack/aitlau_supabase/.env","$ExistingStack/.env","$root/local.env")){if(Test-Path $p){$envFiles+=$p}}
$envLines=($envFiles|ForEach-Object{'      - '+($_|ConvertTo-Json -Compress)}) -join "`n"
$context=$root|ConvertTo-Json -Compress;$networkJson=$network|ConvertTo-Json -Compress
$overlay=@"
name: taotern-ui
services:
  taotern_ui:
    build:
      context: $context
      dockerfile: local-runtime/Dockerfile
    restart: unless-stopped
    ports: ["127.0.0.1:${Port}:8788"]
    env_file:
$envLines
    environment:
      AI_ENABLED: "true"
      AI_PROVIDER: owner
      MODEL_PROXY_ENABLED: "true"
      MODEL_PROXY_PRIVATE_DOCKER: "true"
      MODEL_PROXY_UPSTREAM_URL: http://aitlau_model_proxy:8110/v1
      MODEL_PROXY_DIALECT: openai_compatible
      MODEL_PROXY_GENERATION_MODEL: model-proxy-managed
      AITLAU_SUPABASE_URL: http://api-gw:8000
      AITLAU_OCR_BASE_URL: http://aitlau_ocr:8000
      WEKNORA_BASE_URL: http://weknora_app:8080
      RETRIEVAL_BACKEND: weknora
    volumes: ["taotern_state:/data"]
    networks: [original]
networks:
  original:
    external: true
    name: $networkJson
volumes:
  taotern_state:
    name: taotern-new-ui-state
"@
$folder=Join-Path $root '.taotern-install';New-Item -ItemType Directory -Force $folder|Out-Null
$file=Join-Path $folder 'compose.local.yaml';Set-Content -Path $file -Value $overlay -Encoding utf8
& docker compose -f $file up -d --no-deps --build taotern_ui
if($LASTEXITCODE -ne 0){throw 'Only the new UI adapter failed to start. Original services/data were not rebuilt or removed.'}
Write-Host "Taotern: http://127.0.0.1:$Port"
Write-Host 'Next: run local-runtime/Check.ps1. Backend configuration remains private; no env/credential report is produced.'
