CREATE TABLE `weknora_documents` (
	`owner_id` text NOT NULL,
	`document_id` text NOT NULL,
	`source_sha256` text NOT NULL,
	`version` text NOT NULL,
	`knowledge_base_id` text NOT NULL,
	`knowledge_id` text NOT NULL,
	`status` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`document_id`) REFERENCES `documents`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `weknora_document_identity` ON `weknora_documents` (`owner_id`,`document_id`,`source_sha256`,`version`);